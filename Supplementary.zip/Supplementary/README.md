# Supplementary Code

This package contains the code for the ICLR 2026 submission
"MetaGround: Physics-Grounded Conditional Diffusion for Metamaterial Inverse Design".

It builds on the open-source implementation of Liu et al. (2025)
[arXiv:2504.01195](https://arxiv.org/abs/2504.01195), whose model definitions,
data pipeline, and NOT checkpoint are retained here for reproducibility.

## 1. Prerequisites

1. The SDF dataset and the released NOT checkpoint are available on
   [Zenodo](https://doi.org/10.5281/zenodo.15121966).
2. Install the dependencies listed below (PyTorch, scikit-image, etc.).

## 2. Directory layout

```
.
├── train_diffusion.py                  # unified training entry (ours)
├── eval_inv_design.py                  # inverse-design evaluation (ours, extended)
├── geometry_metrics.py                 # geometric metrics (ours)
├── adaptive_constraint_eval.py         # adaptive proxy evaluation (ours)
├── adaptive_proxy_backend.py           # NOT proxy adaptation backend (ours)
├── local_risk_proxy.py                 # local risk proxy (ours)
├── models/
│   ├── NOT_SS.py                       # [orig] NOT forward model
│   ├── inverse_diffusion_from_sdf.py   # [orig] inverse diffusion
│   ├── configs.py                      # [orig] model configs
│   ├── notss_factory.py               # [orig] NOT factory
│   └── modules/
│       ├── UNets.py                    # [orig] U-Net backbone
│       ├── diffusion.py                 # [orig] Gaussian diffusion
│       ├── uvit.py, uvit_adaln.py      # [orig] U-ViT variants
│       ├── transformer.py               # [orig] transformer block
│       ├── point_position_embedding.py  # [orig] position encoding
│       ├── unet_crossattn.py            # [ours] B1: plain concat + cross-attn
│       ├── unet_crossattn_film.py       # [ours] B2: cross-attn + FiLM (best)
│       ├── unet_film_only.py            # [ours] B3: SS concat + FiLM-only
│       ├── a3_lvf_loss.py               # [ours] VF auxiliary loss (B1-VFLOSS)
│       ├── vf_consistency_loss.py       # [ours] VF consistency regularizer
│       └── constraint_policy.py         # [ours] residual-guided selection
├── utils/
│   ├── run_abaqus.py                   # [orig] Abaqus runner
│   ├── sdf2geo.py                      # [orig] SDF→geo conversion
│   └── abaqus_script_sim.py            # [orig] Abaqus script
└── jobs/
    ├── analyze_v2_style_stats.py        # per-case / pass@4 analysis (ours)
    ├── build_fem_packages.py            # FEM package builder: top1 / top4 / rank2_4 (merged)
    ├── build_original_protocol_package.py
    ├── fem_proxy_revalidation.py
    ├── render_fem_sdf_gallery.py
    ├── run_adapter_al.py               # S2 residual-guided loop (ours)
    ├── run_inference.py                # B0-B3 inference entry (merged)
    └── summarize_adapter.py            # S2 run summary: matrix / trajectory (merged)
```

`[orig]` = Liu et al. (2025); `[ours]` = contributions of this submission.

## 3. What is ours

- **Conditioning-injection variants** B1 / B2 / B3 (`unet_crossattn*.py`,
  `unet_film_only.py`).
- **VF auxiliary losses** (`a3_lvf_loss.py`, `vf_consistency_loss.py`).
- **Residual-guided proxy adaptation** S2 (`run_adapter_al.py`,
  `adaptive_proxy_backend.py`, `summarize_adapter.py`).
- **VF extrapolation protocol** and **per-case / pass@4 analysis**
  (`analyze_v2_style_stats.py`).

## 4. Quick start

```bash
# Train a B2 (cross-attention + FiLM) variant
python train_diffusion.py --backbone uvit_crossattn_film --epochs 300

# Evaluate a checkpoint
python eval_inv_design.py --run_tag b2 --n_samples 500 --n_test 18

# Per-case / pass@4 analysis (Table 1 / Table 8 / Table 10)
python jobs/analyze_v2_style_stats.py --csv <fem_result.csv>
```

## 5. Citation

```bibtex
@article{liu2025sdf,
  title   = {Towards Signed Distance Function based Metamaterial Design:
             Neural Operator Transformer for Forward Prediction and
             Diffusion Model for Inverse Design},
  author  = {Liu, Qibang and Koric, Seid and Abueidda, Diab and
             Meidani, Hadi and Geubelle, Philippe},
  journal = {arXiv preprint arXiv:2504.01195},
  year    = {2025}
}
```
