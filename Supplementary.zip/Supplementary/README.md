# Supplementary Code

This package contains the code for the ICLR 2026 submission

"MetaGround: Physics-Grounded Conditional Diffusion for Metamaterial Inverse Design".

It builds on the open-source implementation of Liu et al. (2025)

[arXiv:2504.01195](https://arxiv.org/abs/2504.01195), whose model definitions,

data pipeline, and NOT checkpoint are retained here for reproducibility.

## 1. Prerequisites



1. The SDF dataset and the released NOT checkpoint are available on

   [Zenodo](https://doi.org/10.5281/zenodo.15121966).

2. Install the dependencies listed below (PyTorch, scikit-image, etc.).

## 2. Directory layout



```
.

├── train\_diffusion.py                  # unified training entry (ours)

├── eval\_inv\_design.py                  # inverse-design evaluation (ours, extended)

├── geometry\_metrics.py                 # geometric metrics (ours)

├── adaptive\_constraint\_eval.py         # adaptive proxy evaluation (ours)

├── adaptive\_proxy\_backend.py           # NOT proxy adaptation backend (ours)

├── local\_risk\_proxy.py                 # local risk proxy (ours)

├── models/

│   ├── NOT\_SS.py                       # \[orig] NOT forward model

│   ├── inverse\_diffusion\_from\_sdf.py   # \[orig] inverse diffusion

│   ├── configs.py                      # \[orig] model configs

│   ├── notss\_factory.py               # \[orig] NOT factory

│   └── modules/

│       ├── UNets.py                    # \[orig] U-Net backbone

│       ├── diffusion.py                 # \[orig] Gaussian diffusion

│       ├── uvit.py, uvit\_adaln.py      # \[orig] U-ViT variants

│       ├── transformer.py               # \[orig] transformer block

│       ├── point\_position\_embedding.py  # \[orig] position encoding

│       ├── unet\_crossattn.py            # \[ours] B1: plain concat + cross-attn

│       ├── unet\_crossattn\_film.py       # \[ours] B2: cross-attn + FiLM (best)

│       ├── unet\_film\_only.py            # \[ours] B3: SS concat + FiLM-only

│       ├── a3\_lvf\_loss.py               # \[ours] VF auxiliary loss (B1-VFLOSS)

│       ├── vf\_consistency\_loss.py       # \[ours] VF consistency regularizer

│       └── constraint\_policy.py         # \[ours] residual-guided selection

├── utils/

│   ├── run\_abaqus.py                   # \[orig] Abaqus runner

│   ├── sdf2geo.py                      # \[orig] SDF→geo conversion

│   └── abaqus\_script\_sim.py            # \[orig] Abaqus script

└── jobs/

&#x20;   ├── analyze\_v2\_style\_stats.py        # per-case / pass@4 analysis (ours)

&#x20;   ├── build\_fem\_packages.py            # FEM package builder: top1 / top4 / rank2\_4 (merged)

&#x20;   ├── build\_original\_protocol\_package.py

&#x20;   ├── fem\_proxy\_revalidation.py

&#x20;   ├── render\_fem\_sdf\_gallery.py

&#x20;   ├── run\_adapter\_al.py               # S2 residual-guided loop (ours)

&#x20;   ├── run\_inference.py                # B0-B3 inference entry (merged)

&#x20;   └── summarize\_adapter.py            # S2 run summary: matrix / trajectory (merged)
```

`[orig]` = Liu et al. (2025); `[ours]` = contributions of this submission.

## 3. What is ours



* **Conditioning-injection variants** B1 / B2 / B3 (`unet_crossattn*.py`,

  `unet_film_only.py`).

* **VF auxiliary losses** (`a3_lvf_loss.py`, `vf_consistency_loss.py`).

* **Residual-guided proxy adaptation** S2 (`run_adapter_al.py`,

  `adaptive_proxy_backend.py`, `summarize_adapter.py`).

* **VF extrapolation protocol** and **per-case / pass@4 analysis**

  (`analyze_v2_style_stats.py`).

## 4. Quick start



```
\# Train a B2 (cross-attention + FiLM) variant

python train\_diffusion.py --backbone uvit\_crossattn\_film --epochs 300

\# Evaluate a checkpoint

python eval\_inv\_design.py --run\_tag b2 --n\_samples 500 --n\_test 18

\# Per-case / pass@4 analysis (Table 1 / Table 8 / Table 10)

python jobs/analyze\_v2\_style\_stats.py --csv \<fem\_result.csv>
```

## 5. Citation



```
@article{liu2025sdf,

&#x20; title   = {Towards Signed Distance Function based Metamaterial Design:

&#x20;            Neural Operator Transformer for Forward Prediction and

&#x20;            Diffusion Model for Inverse Design},

&#x20; author  = {Liu, Qibang and Koric, Seid and Abueidda, Diab and

&#x20;            Meidani, Hadi and Geubelle, Philippe},

&#x20; journal = {arXiv preprint arXiv:2504.01195},

&#x20; year    = {2025}

}
```