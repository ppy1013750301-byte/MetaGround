# Supplementary Code

This package contains the core code for the ICLR 2027 submission

**"MetaGround: Physics-Grounded Conditional Diffusion for Metamaterial Inverse Design"**.

It builds on the open-source implementation of Liu et al. (2025)
[arXiv:2504.01195](https://arxiv.org/abs/2504.01195), whose U-Net backbone,
Gaussian diffusion process, NOT forward surrogate, and data utilities are
retained here. Files marked `[orig]` are derived from that release; files marked
`[ours]` are contributions of this submission.

## 1. Prerequisites

1. The SDF dataset and the released NOT checkpoint are available on
   [Zenodo](https://doi.org/10.5281/zenodo.15121966).
2. Python dependencies: `torch`, `numpy`, `scipy`, `scikit-learn`,
   `scikit-image`, `matplotlib`, `tqdm`, `shapely`.
3. The FEM data pipeline under `utils/` additionally requires Abaqus Python
   (the `odbAccess`, `part`, `material`, `section`, `assembly`, `step`,
   `interaction`, `load`, `mesh`, `job`, `sketch`, and `optimization` modules).

## 2. Directory layout

```
.
├── train_diffusion.py                  [ours] unified training entry
├── models/
│   ├── configs.py                      [orig] dataset / configuration definitions
│   ├── diffusion_builder.py            [orig, extended] backbone registry + diffusion builder
│   ├── not_forward_proxy.py            [orig] NOT forward surrogate
│   ├── trainer/
│   │   └── torch_trainer.py            [orig] generic torch training loop
│   └── modules/
│       ├── unet_blocks.py              [orig] U-Net backbone
│       ├── gaussian_diffusion.py       [orig] Gaussian diffusion
│       ├── transformer_blocks.py       [orig] transformer block
│       ├── pos_encoding.py             [orig] position encoding
│       ├── unet_crossattn.py           [ours] B1: SS tokens + cross-attention
│       ├── unet_crossattn_film.py      [ours] B2: cross-attention + FiLM (best)
│       ├── unet_film_only.py           [ours] B3: SS concat + FiLM-only
│       ├── a3_lvf_loss.py              [ours] VF auxiliary loss (B1-VFLOSS)
│       ├── vf_consistency_loss.py      [ours] VF consistency regularizer
│       └── constraint_policy.py        [ours] residual-guided candidate selection
├── utils/
│   ├── geometry_metrics.py             [ours] geometric metrics
│   ├── sdf_geometry.py                 [orig] SDF-to-geometry conversion
│   ├── run_fem.py                      [orig] Abaqus runner
│   └── fem_sim_script.py               [orig] Abaqus simulation script
└── jobs/
    └── analyze_v2_style_stats.py       [ours] per-case / pass@4 analysis
```

## 3. What is ours

* **Conditioning-injection variants** B1 / B2 / B3, which control how the target
  stress-strain curve and the volume fraction are injected into the denoiser:
  `unet_crossattn.py`, `unet_crossattn_film.py`, `unet_film_only.py`.
* **Volume-fraction objectives**: the auxiliary VF loss used by B1-VFLOSS
  (`a3_lvf_loss.py`) and the VF consistency regularizer
  (`vf_consistency_loss.py`).
* **Residual-guided candidate selection**: the ranking policy applied to the
  surrogate's residual within the DBTL loop (`constraint_policy.py`).
* **Training entry** covering the SS/VF injection backbones (`train_diffusion.py`).
* **Per-case / pass@4 analysis** of the FEM-validated candidates
  (`jobs/analyze_v2_style_stats.py`).

## 4. Quick start

```bash
# Train the B2 variant (cross-attention + FiLM)
python train_diffusion.py --backbone unet_film --epochs 300

# Train the B1 variant (SS tokens + cross-attention)
python train_diffusion.py --backbone unet_crossattn --epochs 300

# Per-case / pass@4 analysis over an FEM result table
python jobs/analyze_v2_style_stats.py --csv <fem_result.csv>
```

The `--backbone` argument accepts `unet`, `unet_crossattn`, `unet_film`, and
`unet_film_only`; it is inferred from `--ss_inj` / `--vf_inj` when left unset.

## 5. Citation

```bibtex
@article{liu2025sdf,
  title   = {Towards Signed Distance Function based Metamaterial Design:
             Neural Operator Transformer for Forward Prediction and
             Diffusion Model for Inverse Design},
  author  = {Liu, Qibang and Koric, Seid and Abueidda, Diab and
             Meidani, Hadi and Geubelle, Philippe},
  journal = {arXiv preprint arXiv:2504.01195},
  year    = {2025}
}
```
