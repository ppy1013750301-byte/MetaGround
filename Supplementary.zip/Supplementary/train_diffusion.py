"""扩散逆向模型训练入口（单卡 / 多卡 DDP）"""

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, TensorDataset, Subset
from torch.utils.data.distributed import DistributedSampler

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS_DIR)

from models import configs as cfg_module
from models.diffusion_builder import DiffusionInverseModelDefinition
from models.modules.vf_consistency_loss import (
    VFConsistencyLoss,
    VFConsistencyLossConfig,
)


def _make_run_tag(args, world_size: int) -> str:
    if getattr(args, "run_id", None):
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", args.run_id):
            raise ValueError("--run_id 只能包含字母、数字、点、下划线和连字符")
        return args.run_id

    ts  = datetime.now().strftime("%Y%m%d-%H%M%S")
    eff_bs = args.batch_size * world_size * getattr(args, "grad_accum_steps", 1)
    lr_str = f"{args.learning_rate:.0e}".replace("e-0", "e-").replace("e+0", "e+")
    cond   = getattr(args, "cond_type", "ss")
    ss_enc = getattr(args, "ss_enc", "raw") or "raw"
    ss_inj = getattr(args, "ss_inj", "concat") or "concat"
    vf_inj = getattr(args, "vf_inj", "concat") or "concat"
    arch = f"unet_{ss_enc}_{ss_inj}_{vf_inj}"
    _vf = args.vf_repeat if args.vf_repeat > 0 else 8
    vf_str = f"_vf{_vf}_pct{int(100*_vf/(51+_vf))}"
    res_str = f"_sdf{getattr(args,'resolution',120) or 120}"
    clip  = f"_clip{args.clip_grad:.0f}" if getattr(args, "clip_grad", 0.0) > 0 else ""
    dropout_tag = (
        f"_drop{args.dropout:g}"
        if getattr(args, "dropout", None) is not None else ""
    )
    sched = "_cos" if getattr(args, "scheduler", "plateau") == "cosine" else ""
    amp_s = f"_{args.amp}" if getattr(args, "amp", "bf16") != "off" else ""
    user_tag = f"_{args.tag}" if getattr(args, "tag", "") else ""
    pp_tag = "_ppdrop" if getattr(args, "per_physics_dropout", False) else ""
    split_tag = "_splitgroup" if getattr(args, "split_mode", "sample") == "group" else ""
    tag = (f"{arch}{res_str}{vf_str}_{cond}_bs{eff_bs}_lr{lr_str}_ep{args.epochs}"
           f"_seed{args.data_seed}{clip}{dropout_tag}{sched}{amp_s}"
           f"{user_tag}{pp_tag}{split_tag}_{ts}")
    return tag


def set_seed(seed: int):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def is_dist() -> bool:
    return "LOCAL_RANK" in os.environ


def get_rank() -> int:
    return int(os.environ.get("RANK", 0))


def get_local_rank() -> int:
    return int(os.environ.get("LOCAL_RANK", 0))


def get_world_size() -> int:
    return int(os.environ.get("WORLD_SIZE", 1))


def is_master() -> bool:
    return get_rank() == 0


def build_loaders(args, rank, world_size, load_data_fn=None):
    if load_data_fn is None:
        load_data_fn = lambda seed: cfg_module.LoadDataInv(
            seed=seed, split_mode=args.split_mode
        )
    train_ds, test_ds, sdf_inv, stress_inv = load_data_fn(seed=args.data_seed)

    if args.max_samples is not None:
        n_tr = min(args.max_samples, len(train_ds))
        n_te = min(max(args.max_samples // 5, 200), len(test_ds))
        if isinstance(train_ds, TensorDataset) and isinstance(test_ds, TensorDataset):
            sdf_tr, ss_tr = train_ds.tensors
            sdf_te, ss_te = test_ds.tensors
            train_ds = TensorDataset(sdf_tr[:n_tr], ss_tr[:n_tr])
            test_ds  = TensorDataset(sdf_te[:n_te], ss_te[:n_te])
        else:
            train_ds = Subset(train_ds, range(n_tr))
            test_ds = Subset(test_ds, range(n_te))
        if is_master():
            print(f"[smoke test] 截断：train={n_tr}  test={n_te}")

    if world_size > 1:
        train_sampler = DistributedSampler(
            train_ds, num_replicas=world_size, rank=rank, shuffle=True, drop_last=True)
        test_sampler = DistributedSampler(
            test_ds,  num_replicas=world_size, rank=rank, shuffle=False, drop_last=False)
    else:
        train_sampler = None
        test_sampler  = None

    import os as _os
    try:
        n_cpu = len(_os.sched_getaffinity(0))
    except (AttributeError, OSError):
        n_cpu = _os.cpu_count() or 4
    workers_per_rank = max(0, n_cpu // max(world_size, 1) - 1)
    nw_cap  = getattr(args, "num_workers", 0)
    if nw_cap <= 0:
        nw_train = min(8, workers_per_rank)
    else:
        nw_train = min(nw_cap, workers_per_rank)
    nw_val = nw_train // 2
    if is_master():
        print(
            f"[DataLoader CPU] affinity={n_cpu}, world={world_size}, "
            f"requested={nw_cap}, train_workers/rank={nw_train}, "
            f"val_workers/rank={nw_val}"
        )

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size,
        sampler=train_sampler, shuffle=(train_sampler is None),
        num_workers=nw_train, pin_memory=True, drop_last=True,
        persistent_workers=(nw_train > 0))
    test_loader = DataLoader(
        test_ds, batch_size=args.batch_size * 2,
        sampler=test_sampler, shuffle=False,
        num_workers=nw_val, pin_memory=True,
        persistent_workers=(nw_val > 0))

    return train_loader, test_loader, sdf_inv, stress_inv


def run_training(args, inv_cfg):
    rank       = get_rank()
    local_rank = get_local_rank()
    world_size = get_world_size()
    device     = torch.device(f"cuda:{local_rank}")
    torch.cuda.set_device(device)

    set_seed(args.data_seed + rank)

    model_args = inv_cfg["model_args"]
    total_T    = model_args.get("total_timesteps", 500)

    base_weights = os.path.join(THIS_DIR, "models", "saved_weights")
    if args.train_flag == "start":
        run_state = [None, None]
        if is_master():
            run_tag = _make_run_tag(args, world_size)
            filebase = os.path.join(base_weights, run_tag)
            try:
                os.makedirs(filebase, exist_ok=False)
            except FileExistsError:
                run_state = [run_tag, (
                    f"run_id 已存在，拒绝覆盖: {run_tag}；"
                    "续训请使用 --train_flag continue --run_name")]
            else:
                run_state = [run_tag, None]
        if world_size > 1:
            dist.broadcast_object_list(run_state, src=0, device=device)
        run_tag, create_error = run_state
        if create_error is not None:
            raise FileExistsError(create_error)
        filebase = os.path.join(base_weights, run_tag)
        inv_cfg["run_tag"] = os.path.basename(filebase)
    else:
        run_name = getattr(args, "run_name", None)
        if run_name:
            filebase = os.path.join(base_weights, run_name)
        else:
            prefix_map = {"unet": "unet_ss", "unet_crossattn": "unet_crossattn",
                           "unet_film": "unet_film", "unet_film_only": "unet_film_only"}
            prefix = prefix_map.get(args.backbone, "unet_ss")
            tag_key = getattr(args, "tag", "")
            if tag_key:
                cands = sorted(
                    [d for d in os.listdir(base_weights)
                     if tag_key in d and os.path.exists(os.path.join(base_weights, d, "model.ckpt"))],
                    reverse=True)
            else:
                cands = sorted(
                    [d for d in os.listdir(base_weights)
                     if d.startswith(prefix) and
                     os.path.exists(os.path.join(base_weights, d, "model.ckpt"))],
                    reverse=True)
            if not cands:
                raise FileNotFoundError(
                    "continue 模式找不到已有 checkpoint，请用 --run_name 指定目录名")
            filebase = os.path.join(base_weights, cands[0])
            print(f"[continue] 自动选择最新目录: {cands[0]}")
        inv_cfg["run_tag"] = os.path.basename(filebase)

    if is_master():
        if args.train_flag != "start":
            os.makedirs(filebase, exist_ok=True)
        metadata = {
            "schema_version": 1,
            "run_id": inv_cfg.get("run_tag", ""),
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "train_args": vars(args),
            "eval_config": {
                **model_args,
                "cond_type": getattr(args, "cond_type", "ss"),
                "resolution": int(getattr(args, "resolution", 120)),
            },
        }
        with open(os.path.join(filebase, "run_config.json"), "w") as f:
            json.dump(metadata, f, indent=2)
        print("=" * 60)
        print(f"  run_tag      : {inv_cfg.get('run_tag','')}")
        print(f"  backbone     : {args.backbone}")
        print(f"  cond_type    : {getattr(args,'cond_type','ss')}")
        print(f"  train_flag   : {args.train_flag}")
        print(f"  epochs       : {args.epochs}")
        print(f"  lr           : {args.learning_rate}")
        print(f"  scheduler    : {args.scheduler}")
        print(f"  clip_grad    : {args.clip_grad if args.clip_grad > 0 else 'off'}")
        print(f"  dropout      : {args.dropout if args.dropout is not None else 'off'}")
        print(f"  warmup_ep    : {args.warmup_epochs}")
        print(f"  batch/GPU    : {args.batch_size}")
        print(f"  GPUs         : {world_size}")
        print(f"  grad accum   : {args.grad_accum_steps}")
        print(f"  effective bs : {args.batch_size * world_size * args.grad_accum_steps}")
        print(f"  max_samples  : {args.max_samples}")
        print(f"  split_mode   : {args.split_mode}")
        print(f"  device       : {device}")
        print(f"  weights →    : {filebase}")
        print("=" * 60)
    if world_size > 1:
        dist.barrier()

    noise_est, gauss_diff = DiffusionInverseModelDefinition(**model_args)
    noise_est = noise_est.to(device)
    if world_size > 1:
        noise_est = DDP(noise_est, device_ids=[local_rank], find_unused_parameters=False)

    raw_model = noise_est.module if world_size > 1 else noise_est

    amp_mode    = getattr(args, "amp", "bf16")
    amp_enabled = (amp_mode != "off") and torch.cuda.is_available()
    amp_dtype   = torch.bfloat16 if amp_mode == "bf16" else torch.float16
    scaler      = torch.cuda.amp.GradScaler() if (amp_enabled and amp_mode == "fp16") else None
    if is_master():
        print(f"  AMP          : {amp_mode}  (scaler: {'on' if scaler else 'off'})")

    optimizer = torch.optim.Adam(noise_est.parameters(), lr=args.learning_rate)

    if args.scheduler == "cosine":
        lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=args.epochs, eta_min=1e-6)
        use_plateau = False
    else:
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, factor=0.7, patience=20, min_lr=1e-6)
        use_plateau = True

    logs = {
        "loss": [], "val_loss": [], "lr": [],
        "grad_norm_max": [], "clipped_steps": [],
    }
    start_epoch = 0
    best_val    = float("inf")
    ckpt_path   = os.path.join(filebase, "model.ckpt")

    if args.train_flag == "continue" and os.path.exists(ckpt_path):
        map_loc = {"cuda:0": f"cuda:{local_rank}"}
        latest_path = os.path.join(filebase, "latest.ckpt")
        load_path = latest_path if os.path.exists(latest_path) else ckpt_path
        try:
            state = torch.load(load_path, map_location=map_loc, weights_only=True)
            raw_model.load_state_dict(state)
        except Exception as e:
            if load_path == latest_path and os.path.exists(ckpt_path):
                if is_master():
                    print(f"[resume] latest.ckpt 损坏({e})，回退 model.ckpt")
                load_path = ckpt_path
                state = torch.load(load_path, map_location=map_loc, weights_only=True)
                raw_model.load_state_dict(state)
            else:
                raise
        logs_path = os.path.join(filebase, "logs.json")
        if os.path.exists(logs_path):
            try:
                with open(logs_path) as f:
                    logs = json.load(f)
                logs.setdefault("grad_norm_max", [])
                logs.setdefault("clipped_steps", [])
                start_epoch = len(logs["loss"])
                best_val    = min(logs["val_loss"]) if logs["val_loss"] else float("inf")
            except Exception:
                pass
        if is_master():
            print(f"[resume] loaded {os.path.basename(load_path)}, start_epoch={start_epoch}, best_val={best_val:.4e}")

    load_fn = inv_cfg.get("load_data_fn", cfg_module.LoadDataInv)
    train_loader, test_loader, sdf_inverse, stress_inverse = build_loaders(
        args, rank, world_size, load_data_fn=load_fn
    )

    vf_consistency_loss_module = None
    if getattr(args, "vf_consistency_loss", False):
        if args.cond_type != "ss_vf":
            raise ValueError("--vf_consistency_loss 要求 --cond_type ss_vf")
        vf_consistency_loss_module = VFConsistencyLoss(
            sdf_inverse=sdf_inverse,
            config=VFConsistencyLossConfig(
                lambda_vf=args.lambda_vf,
                tau_vf=args.tau_vf_consistency,
                regularize_t_max=args.vf_loss_t_max,
            ),
            total_timesteps=total_T,
        ).to(device)
        if is_master():
            print(
                f"[VF-consistency] lambda_vf={args.lambda_vf} "
                f"tau_vf={args.tau_vf_consistency} "
                f"regularize_t_max={args.vf_loss_t_max}"
            )

    physics_slices = inv_cfg.get("physics_slices")
    do_pp_drop = (getattr(args, "per_physics_dropout", False) and physics_slices is not None
                  and len(physics_slices) > 1)
    if is_master() and do_pp_drop:
        print(f"[per-physics dropout] physics={list(physics_slices.keys())} "
              f"p_uncond={args.p_uncond} p_drop={args.p_drop}")

    for epoch in range(start_epoch, start_epoch + args.epochs):
        if hasattr(train_loader.sampler, "set_epoch"):
            train_loader.sampler.set_epoch(epoch)

        noise_est.train()
        t0 = time.time()
        train_loss_sum, n_train = 0.0, 0
        grad_norm_max, clipped_steps = 0.0, 0
        optimizer.zero_grad(set_to_none=True)
        available_batches = len(train_loader)
        n_batches = (available_batches // args.grad_accum_steps) * args.grad_accum_steps
        if n_batches == 0:
            raise ValueError(
                f"训练 batch 数 {available_batches} 小于 grad_accum_steps="
                f"{args.grad_accum_steps}；请增大数据量或减小梯度累积步数")
        if is_master() and epoch == start_epoch and n_batches != available_batches:
            print(f"  [grad accum] 每轮忽略尾部 "
                  f"{available_batches - n_batches} 个不完整 micro-batch，"
                  f"保留 {n_batches // args.grad_accum_steps} 个完整 optimizer step")
        for batch_idx, data in enumerate(train_loader):
            if batch_idx >= n_batches:
                break
            labels = data[1].to(device)
            sdf    = data[0].to(device)
            if args.resolution != 120:
                sdf = torch.nn.functional.interpolate(sdf, size=args.resolution, mode='bilinear', align_corners=True)
            B      = sdf.shape[0]

            if do_pp_drop:
                full_unc = torch.rand(B, device=device) < args.p_uncond
                batch_mask = (~full_unc).int()
                labels_pp = labels.clone()
                for pname, (ps, pe) in physics_slices.items():
                    drop_p = torch.rand(B, device=device) < args.p_drop
                    zero_this = drop_p & (~full_unc)
                    labels_pp[zero_this, ps:pe] = 0.0
                labels_use = labels_pp
            else:
                z_unc      = torch.rand(B)
                batch_mask = (z_unc > 0.1).int().to(device)
                labels_use = labels

            t_idx = torch.randint(0, total_T, (B,), device=device).long()

            window_size = args.grad_accum_steps
            should_step = ((batch_idx + 1) % args.grad_accum_steps == 0)
            with torch.amp.autocast("cuda", dtype=amp_dtype, enabled=amp_enabled):
                if vf_consistency_loss_module is not None:
                    loss_result = vf_consistency_loss_module(
                        gauss_diff, noise_est, sdf, t_idx,
                        labels_use, batch_mask,
                    )
                    loss = loss_result["total"]
                else:
                    loss = gauss_diff.train_losses(
                        noise_est, sdf, t_idx, labels_use, batch_mask
                    )
                backward_loss = loss / window_size
            if scaler is not None:
                scaler.scale(backward_loss).backward()
                if should_step:
                    if args.clip_grad > 0:
                        scaler.unscale_(optimizer)
                        grad_norm = torch.nn.utils.clip_grad_norm_(
                            noise_est.parameters(), args.clip_grad,
                            error_if_nonfinite=True,
                        )
                        grad_norm_value = float(grad_norm.detach())
                        grad_norm_max = max(grad_norm_max, grad_norm_value)
                        clipped_steps += int(grad_norm_value > args.clip_grad)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
            else:
                backward_loss.backward()
                if should_step:
                    if args.clip_grad > 0:
                        grad_norm = torch.nn.utils.clip_grad_norm_(
                            noise_est.parameters(), args.clip_grad,
                            error_if_nonfinite=True,
                        )
                        grad_norm_value = float(grad_norm.detach())
                        grad_norm_max = max(grad_norm_max, grad_norm_value)
                        clipped_steps += int(grad_norm_value > args.clip_grad)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)

            train_loss_sum += loss.item() * B
            n_train        += B

        train_tensor = torch.tensor([train_loss_sum, float(n_train)], device=device)
        if world_size > 1:
            dist.all_reduce(train_tensor, op=dist.ReduceOp.SUM)
        train_loss = (train_tensor[0] / train_tensor[1]).item()

        noise_est.eval()
        val_loss_sum, n_val = 0.0, 0
        with torch.no_grad():
            for data in test_loader:
                labels = data[1].to(device)
                sdf    = data[0].to(device)
                if args.resolution != 120:
                    sdf = torch.nn.functional.interpolate(
                        sdf, size=args.resolution, mode='bilinear', align_corners=True)
                B      = sdf.shape[0]
                batch_mask = torch.ones(B, dtype=torch.int32, device=device)
                t_idx  = torch.randint(0, total_T, (B,), device=device).long()
                if vf_consistency_loss_module is not None:
                    loss = vf_consistency_loss_module(
                        gauss_diff, noise_est, sdf, t_idx,
                        labels, batch_mask,
                    )["total"]
                else:
                    loss = gauss_diff.train_losses(
                        noise_est, sdf, t_idx, labels, batch_mask
                    )
                val_loss_sum += loss.item() * B
                n_val        += B

        val_tensor = torch.tensor([val_loss_sum, float(n_val)], device=device)
        if world_size > 1:
            dist.all_reduce(val_tensor, op=dist.ReduceOp.SUM)
        val_loss = (val_tensor[0] / val_tensor[1]).item()

        if args.clip_grad > 0 and world_size > 1:
            grad_diag = torch.tensor(
                [grad_norm_max, float(clipped_steps)], device=device
            )
            dist.all_reduce(grad_diag, op=dist.ReduceOp.MAX)
            grad_norm_max = float(grad_diag[0].item())
            clipped_steps = int(grad_diag[1].item())

        global_ep = epoch - start_epoch
        if global_ep < args.warmup_epochs and args.warmup_epochs > 0:
            warmup_lr = args.learning_rate * (global_ep + 1) / args.warmup_epochs
            for pg in optimizer.param_groups:
                pg["lr"] = warmup_lr
        else:
            if use_plateau:
                lr_scheduler.step(val_loss)
            else:
                lr_scheduler.step()
        cur_lr = optimizer.param_groups[0]["lr"]

        if is_master():
            logs["loss"].append(train_loss)
            logs["val_loss"].append(val_loss)
            logs["lr"].append(cur_lr)
            logs["grad_norm_max"].append(
                grad_norm_max if args.clip_grad > 0 else None
            )
            logs["clipped_steps"].append(
                clipped_steps if args.clip_grad > 0 else 0
            )

            if val_loss < best_val:
                best_val = val_loss
                _tmp = ckpt_path + ".tmp"
                torch.save(raw_model.state_dict(), _tmp)
                os.replace(_tmp, ckpt_path)
            latest_path = os.path.join(filebase, "latest.ckpt")
            if (epoch + 1) % 5 == 0:
                _tmp = latest_path + ".tmp"
                torch.save(raw_model.state_dict(), _tmp)
                os.replace(_tmp, latest_path)
                with open(os.path.join(filebase, "logs.json"), "w") as f:
                    json.dump(logs, f)

            elapsed = time.time() - t0
            grad_text = ""
            if args.clip_grad > 0:
                grad_text = (
                    f", grad_max: {grad_norm_max:.3e}, "
                    f"clipped_steps: {clipped_steps}"
                )
            print(f"Epoch {epoch+1:3d} took {elapsed:.1f}s, "
                  f"lr: {cur_lr:.4e}, loss: {train_loss:.4e}, "
                  f"val_loss: {val_loss:.4e}{grad_text}")

            if (epoch + 1) % 10 == 0:
                with open(os.path.join(filebase, "logs.json"), "w") as f:
                    json.dump(logs, f)

    if is_master():
        with open(os.path.join(filebase, "logs.json"), "w") as f:
            json.dump(logs, f)
        print(f"\n训练完成。最终 train loss: {logs['loss'][-1]:.4e}  "
              f"val loss: {logs['val_loss'][-1]:.4e}")
        print(f"最优 val loss: {best_val:.4e}  权重: {ckpt_path}")


def main():
    parser = argparse.ArgumentParser(description="扩散逆向模型训练")
    parser.add_argument("--ss_enc", type=str, default="raw", choices=["raw","nerf"],
                        help="SS编码: raw | nerf")
    parser.add_argument("--ss_inj", type=str, default="concat", choices=["concat","crossattn"],
                        help="SS注入: concat | crossattn")
    parser.add_argument("--vf_inj", type=str, default="concat", choices=["concat","film"],
                        help="VF注入: concat | film")
    parser.add_argument("--backbone", type=str, default=None,
                        choices=["unet","unet_crossattn","unet_film","unet_film_only"],
                        help="模型骨架，留空则由 ss_inj/vf_inj 自动推断")
    parser.add_argument("--train_flag",    type=str,   default="start",
                        choices=["start", "continue"])
    parser.add_argument("--epochs",        type=int,   default=300)
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--batch_size",    type=int,   default=64,
                        help="每张 GPU 的 batch size")
    parser.add_argument("--grad_accum_steps", type=int, default=1,
                        help="梯度累积步数")
    parser.add_argument("--max_samples",   type=int,   default=None,
                        help="截断数据集用于 smoke test")
    parser.add_argument("--amp",           type=str,   default="bf16",
                        choices=["off", "bf16", "fp16"],
                        help="混合精度模式")
    parser.add_argument("--num_workers",   type=int,   default=0,
                        help="DataLoader num_workers")
    parser.add_argument("--clip_grad",     type=float, default=0.0,
                        help="梯度裁剪 max_norm")
    parser.add_argument("--dropout",       type=float, default=None,
                        help="U-Net feature dropout")
    parser.add_argument("--scheduler",     type=str,   default="plateau",
                        choices=["plateau", "cosine"],
                        help="LR 调度策略")
    parser.add_argument("--warmup_epochs", type=int,   default=0,
                        help="线性 warmup epoch 数")
    parser.add_argument("--vf_repeat", type=int, default=8,
                        help="VF 重复倍数")
    parser.add_argument("--resolution", type=int, default=120,
                        choices=[64, 120, 256],
                        help="SDF 分辨率")
    parser.add_argument("--data_seed", type=int, default=420,
                        help="数据划分随机种子")
    parser.add_argument("--split_mode", choices=["sample", "group"], default="sample",
                        help="sample=随机切分；group=按结构ID切分")
    parser.add_argument("--cond_type", type=str, default="ss",
                        choices=["ss", "ss_vf"],
                        help="ss：仅曲线条件；ss_vf：曲线+VF条件")
    parser.add_argument("--tag", type=str, default="",
                        help="自定义实验标识")
    parser.add_argument("--run_id", type=str, default=None,
                        help="精确运行 ID")
    parser.add_argument("--per_physics_dropout", action="store_true",
                        help="训练时每物理独立随机丢弃")
    parser.add_argument("--p_uncond", type=float, default=0.1,
                        help="整体无条件概率")
    parser.add_argument("--p_drop", type=float, default=0.3,
                        help="每物理独立丢弃概率")
    parser.add_argument("--vf_consistency_loss", action="store_true",
                        help="VF一致性辅助损失")
    parser.add_argument("--lambda_vf", type=float, default=1.0e-2,
                        help="VF一致性损失权重")
    parser.add_argument("--tau_vf_consistency", type=float, default=0.005,
                        help="soft-VF sigmoid温度")
    parser.add_argument("--vf_loss_t_max", type=int, default=100,
                        help="辅助项启用的最大 timestep")
    parser.add_argument("--run_name", type=str, default=None,
                        help="continue 模式时指定已有权重目录名")
    args = parser.parse_args()
    if args.grad_accum_steps < 1:
        parser.error("--grad_accum_steps 必须 >= 1")
    if args.dropout is not None and not (0.0 <= args.dropout < 1.0):
        parser.error("--dropout 必须在 [0, 1) 内；关闭请省略该参数")

    if args.train_flag == "continue" and args.run_name:
        metadata_path = os.path.join(
            THIS_DIR, "models", "saved_weights", args.run_name, "run_config.json")
        if os.path.isfile(metadata_path):
            with open(metadata_path) as f:
                stored_args = json.load(f).get("train_args", {})
            structural_keys = (
                "backbone", "ss_enc", "ss_inj", "vf_inj", "cond_type",
                "vf_repeat", "resolution", "data_seed",
                "per_physics_dropout", "p_uncond", "p_drop", "dropout",
                "split_mode",
            )
            for key in structural_keys:
                if key in stored_args:
                    setattr(args, key, stored_args[key])
            print(f"[resume] 已从 {metadata_path} 恢复模型结构参数")

    if args.backbone is None:
        _bmap = {("concat","concat"): "unet",
                 ("crossattn","concat"): "unet_crossattn",
                 ("crossattn","film"): "unet_film",
                 ("concat","film"): "unet_film_only"}
        args.backbone = _bmap.get((args.ss_inj, args.vf_inj), "unet")
    if args.ss_enc == "nerf" and args.backbone != "unet":
        parser.error("--ss_enc nerf 仅适用于 plain U-Net concat 条件")

    if is_dist():
        dist.init_process_group(backend="nccl")

    _vf_rep = args.vf_repeat if args.vf_repeat > 0 else 8
    _label_map = {"ss": 51, "ss_vf": 51 + _vf_rep}
    label_dim = _label_map[args.cond_type]

    if args.backbone == "unet":
        inv_cfg = cfg_module.INV_configs()
        inv_cfg["model_args"]["backbone"]  = "unet"
        inv_cfg["model_args"]["label_dim"] = label_dim
        inv_cfg["model_args"]["ss_encoding"] = args.ss_enc
    elif args.backbone == "unet_crossattn":
        inv_cfg = cfg_module.INV_configs()
        inv_cfg["model_args"]["backbone"]  = "unet_crossattn"
        inv_cfg["model_args"]["label_dim"] = label_dim
    elif args.backbone == "unet_film":
        inv_cfg = cfg_module.INV_configs()
        inv_cfg["model_args"]["backbone"]  = "unet_film"
        inv_cfg["model_args"]["label_dim"] = label_dim
    elif args.backbone == "unet_film_only":
        inv_cfg = cfg_module.INV_configs()
        inv_cfg["model_args"]["backbone"]  = "unet_film_only"
        inv_cfg["model_args"]["label_dim"] = label_dim

    inv_cfg["model_args"]["dropout"] = args.dropout

    if args.resolution != 120:
        inv_cfg["model_args"]["img_shape"] = (1, args.resolution, args.resolution)
        print(f"  [resolution] SDF 插值到 {args.resolution}×{args.resolution}")

    if args.cond_type == "ss_vf":
        inv_cfg["cond_type"] = args.cond_type
        _vr = args.vf_repeat if args.vf_repeat > 0 else 8
        inv_cfg["load_data_fn"] = lambda seed=args.data_seed, _vr=_vr: cfg_module.LoadDataInvMulti(
            seed=args.data_seed, cond_type=args.cond_type, vf_repeat=_vr,
            split_mode=args.split_mode, lazy_sdf=True)
    else:
        inv_cfg["load_data_fn"] = lambda seed=args.data_seed: cfg_module.LoadDataInv(
            seed=args.data_seed, split_mode=args.split_mode)

    _slices = {
        "ss":       {"ss": (0, 51)},
        "ss_vf":    {"ss": (0, 51), "vf": (51, 51 + _vf_rep)},
    }
    inv_cfg["physics_slices"] = _slices.get(args.cond_type)

    run_training(args, inv_cfg)

    if is_dist():
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
