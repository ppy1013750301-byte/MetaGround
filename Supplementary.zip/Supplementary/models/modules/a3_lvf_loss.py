"""Low-VF auxiliary objective for the A3 conditional diffusion model."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F


@dataclass(frozen=True)
class A3LVFLossConfig:
    delta_vf: float = 0.05
    lambda_vf: float = 1.0e-2
    tau_vf: float = 0.005
    regularize_t_max: int = 100

    def validate(self, total_timesteps: int) -> None:
        if not 0.0 < self.delta_vf < 1.0:
            raise ValueError("delta_vf must be in (0, 1)")
        if self.lambda_vf < 0.0:
            raise ValueError("lambda_vf must be non-negative")
        if self.tau_vf <= 0.0:
            raise ValueError("tau_vf must be positive")
        if not 0 <= self.regularize_t_max < total_timesteps:
            raise ValueError(
                f"regularize_t_max must be in [0, {total_timesteps - 1}]"
            )


class A3LVFLoss(nn.Module):
    """Noise MSE plus a low-noise target-VF consistency term.

    The source VF is measured from the real training SDF.  The auxiliary
    target is a counterfactual ``source_vf - delta_vf`` target; it is not a
    substitute for a real low-VF FEM label.
    """

    def __init__(self, sdf_inverse, config: A3LVFLossConfig, total_timesteps: int):
        super().__init__()
        config.validate(total_timesteps)
        self.sdf_inverse = sdf_inverse
        self.config = config

    def forward(
        self,
        diffusion,
        model: nn.Module,
        x_start: torch.Tensor,
        timesteps: torch.Tensor,
        condition: torch.Tensor,
        condition_mask: torch.Tensor,
        auxiliary_scale: float = 1.0,
    ):
        noise = torch.randn_like(x_start)
        x_t = diffusion.q_sample(x_start, timesteps, noise=noise)
        predicted_noise = model(x_t, timesteps, condition, condition_mask)
        eps_loss = F.mse_loss(predicted_noise, noise)
        zero = predicted_noise.sum() * 0.0

        active = (
            (timesteps <= int(self.config.regularize_t_max))
            & condition_mask.to(torch.bool)
        )
        if auxiliary_scale <= 0.0 or not bool(active.any()):
            return {
                "total": eps_loss,
                "eps": eps_loss,
                "vf": zero,
                "soft_vf": zero,
                "target_vf": zero,
                "active_fraction": active.float().mean(),
            }

        with torch.enable_grad():
            x0_prediction = diffusion.predict_start_from_noise(
                x_t[active], timesteps[active], predicted_noise[active]
            )
            source_sdf = self.sdf_inverse(x_start[active].float())
            predicted_sdf = self.sdf_inverse(x0_prediction.float())

            reduce_dims = tuple(range(1, source_sdf.ndim))
            source_vf = (source_sdf < 0).to(source_sdf.dtype).mean(dim=reduce_dims)
            target_vf = torch.clamp(
                source_vf - float(self.config.delta_vf), min=0.0, max=1.0
            )
            solid_probability = torch.sigmoid(
                -predicted_sdf / float(self.config.tau_vf)
            )
            soft_vf = solid_probability.mean(dim=reduce_dims)
            vf_loss = F.mse_loss(soft_vf, target_vf)

        total = eps_loss + float(auxiliary_scale) * float(self.config.lambda_vf) * vf_loss
        return {
            "total": total,
            "eps": eps_loss,
            "vf": vf_loss,
            "soft_vf": soft_vf.mean(),
            "target_vf": target_vf.mean(),
            "active_fraction": active.float().mean(),
        }
