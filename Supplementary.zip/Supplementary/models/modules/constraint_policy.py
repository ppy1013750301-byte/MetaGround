"""Scenario specifications and feedback policy for multi-objective inference.

This module is deliberately independent of a particular diffusion sampler.  It
turns physical requirements into dimensionless violations and adaptive
multipliers; samplers may then map those multipliers to per-physics CFG or UG
weights.  The separation keeps the engineering specification auditable.
"""

from dataclasses import asdict, dataclass
from typing import Dict, Mapping, Sequence

import numpy as np


CONSTRAINT_KINDS = {"equality", "upper_bound", "lower_bound", "objective"}
OBJECTIVE_SENSES = {"minimize", "maximize"}


@dataclass(frozen=True)
class ConstraintSpec:
    name: str
    kind: str
    target: float
    tolerance: float
    priority: int = 0
    objective_sense: str = "minimize"

    def __post_init__(self):
        if self.kind not in CONSTRAINT_KINDS:
            raise ValueError(f"unsupported constraint kind: {self.kind}")
        if self.tolerance <= 0:
            raise ValueError("tolerance must be positive")
        if self.objective_sense not in OBJECTIVE_SENSES:
            raise ValueError(
                f"unsupported objective sense: {self.objective_sense}"
            )

    def violation(self, value) -> np.ndarray:
        """Return non-negative, dimensionless violation values."""
        value = np.asarray(value, dtype=np.float64)
        if self.kind == "equality":
            return np.maximum(np.abs(value - self.target) / self.tolerance - 1.0, 0.0)
        if self.kind == "upper_bound":
            return np.maximum((value - self.target) / self.tolerance, 0.0)
        if self.kind == "lower_bound":
            return np.maximum((self.target - value) / self.tolerance, 0.0)
        return np.zeros_like(value)  # an objective is ranked inside the feasible set

    def satisfied(self, value) -> np.ndarray:
        return self.violation(value) == 0.0

    def objective_score(self, value) -> np.ndarray:
        """Return a dimensionless score where a smaller value is better."""
        if self.kind != "objective":
            raise ValueError(f"{self.name} is not an objective")
        value = np.asarray(value, dtype=np.float64) / self.tolerance
        if self.objective_sense == "maximize":
            value = -value
        return value


@dataclass(frozen=True)
class CandidateRanking:
    """Auditable feasible-first ordering of a candidate batch."""

    order: np.ndarray
    feasible_mask: np.ndarray
    violation_score: np.ndarray
    hard_failure_score: np.ndarray


class AdaptiveConstraintController:
    """Batch-feedback update for constraint guidance multipliers.

    ``update`` consumes realized physical measurements from a pilot batch.  A
    violated constraint gains weight; a satisfied constraint decays gently so
    it is not pushed indefinitely.  The controller does not assume that SS or
    VF is permanently primary: priority belongs to each scenario spec.
    """

    def __init__(
        self,
        specs,
        eta=1.0,
        lambda_max=30.0,
        satisfied_decay=0.9,
        violation_quantile=0.2,
        priority_gain=0.25,
        max_update=5.0,
        initial_multipliers=None,
    ):
        specs = list(specs)
        self.specs = {spec.name: spec for spec in specs}
        if len(self.specs) != len(specs):
            raise ValueError("constraint names must be unique")
        self.eta = float(eta)
        self.lambda_max = float(lambda_max)
        self.satisfied_decay = float(satisfied_decay)
        self.violation_quantile = float(violation_quantile)
        self.priority_gain = float(priority_gain)
        self.max_update = float(max_update)
        if not 0.0 <= self.violation_quantile <= 1.0:
            raise ValueError("violation_quantile must be in [0, 1]")
        if not 0.0 <= self.satisfied_decay <= 1.0:
            raise ValueError("satisfied_decay must be in [0, 1]")
        if (self.eta < 0 or self.lambda_max <= 0 or self.priority_gain < 0
                or self.max_update <= 0):
            raise ValueError(
                "eta/priority_gain must be non-negative; lambda_max/max_update positive"
            )
        initial_multipliers = dict(initial_multipliers or {})
        unknown = set(initial_multipliers) - set(self.specs)
        if unknown:
            raise KeyError(f"unknown initial multipliers: {sorted(unknown)}")
        self.multipliers: Dict[str, float] = {
            name: float(initial_multipliers.get(name, 0.0))
            for name, spec in self.specs.items()
            if spec.kind != "objective"
        }
        if any(value < 0 or value > self.lambda_max for value in self.multipliers.values()):
            raise ValueError("initial multipliers must be within [0, lambda_max]")
        self.round_index = 0
        self.history = []

    def update(self, measurements: Mapping[str, np.ndarray]) -> Dict[str, float]:
        missing = set(self.multipliers) - set(measurements)
        if missing:
            raise KeyError(f"missing measurements for constraints: {sorted(missing)}")

        round_record = {"round": self.round_index, "constraints": {}}
        for name in sorted(
            self.multipliers,
            key=lambda item: self.specs[item].priority,
            reverse=True,
        ):
            values = np.asarray(measurements[name], dtype=np.float64)
            if values.size == 0:
                raise ValueError(f"empty measurements for constraint: {name}")
            violations = self.specs[name].violation(values)
            violation = float(np.quantile(violations, self.violation_quantile))
            before = self.multipliers[name]
            raw_update = 0.0
            applied_update = 0.0
            if violation > 0:
                priority_scale = 1.0 + self.priority_gain * max(
                    self.specs[name].priority, 0
                )
                raw_update = self.eta * priority_scale * violation
                applied_update = min(raw_update, self.max_update)
                updated = before + applied_update
            else:
                updated = before * self.satisfied_decay
            self.multipliers[name] = float(np.clip(updated, 0.0, self.lambda_max))
            round_record["constraints"][name] = {
                "violation_quantile": violation,
                "batch_satisfied_rate": float(np.mean(violations == 0.0)),
                "before": before,
                "after": self.multipliers[name],
                "raw_update": raw_update,
                "applied_update": applied_update,
            }
        self.history.append(round_record)
        self.round_index += 1
        return dict(self.multipliers)

    def state_dict(self) -> dict:
        return {
            "schema_version": 1,
            "specs": [asdict(spec) for spec in self.specs.values()],
            "eta": self.eta,
            "lambda_max": self.lambda_max,
            "satisfied_decay": self.satisfied_decay,
            "violation_quantile": self.violation_quantile,
            "priority_gain": self.priority_gain,
            "max_update": self.max_update,
            "multipliers": dict(self.multipliers),
            "round_index": self.round_index,
            "history": list(self.history),
        }

    def load_state_dict(self, state: Mapping) -> None:
        if int(state.get("schema_version", -1)) != 1:
            raise ValueError("unsupported controller state schema")
        state_names = {item["name"] for item in state.get("specs", [])}
        if state_names != set(self.specs):
            raise ValueError("controller state constraints do not match")
        multipliers = dict(state.get("multipliers", {}))
        if set(multipliers) != set(self.multipliers):
            raise ValueError("controller state multiplier names do not match")
        state_lambda_max = float(state.get("lambda_max", self.lambda_max))
        if any(float(value) < 0 or float(value) > state_lambda_max
               for value in multipliers.values()):
            raise ValueError("controller state multiplier out of range")
        for name in (
            "eta", "lambda_max", "satisfied_decay",
            "violation_quantile", "priority_gain",
            "max_update",
        ):
            if name in state:
                setattr(self, name, float(state[name]))
        self.multipliers = {name: float(value) for name, value in multipliers.items()}
        self.round_index = int(state.get("round_index", 0))
        self.history = list(state.get("history", []))


def rank_candidates(
    specs: Sequence[ConstraintSpec],
    measurements: Mapping[str, np.ndarray],
    hard_filters: Mapping[str, np.ndarray] | None = None,
) -> CandidateRanking:
    """Rank candidates by feasibility, objective, then weighted violation.

    All hard/equality constraints must pass before an objective can improve a
    candidate's rank.  If no feasible design exists, the least normalized,
    priority-weighted violation is returned first.  This prevents a very good
    objective value from hiding an engineering constraint failure.
    """
    specs = list(specs)
    required = {spec.name for spec in specs}
    missing = required - set(measurements)
    if missing:
        raise KeyError(f"missing candidate measurements: {sorted(missing)}")
    lengths = {len(np.asarray(measurements[name])) for name in required}
    if len(lengths) != 1:
        raise ValueError("candidate measurements must have equal lengths")
    count = lengths.pop() if lengths else 0
    feasible = np.ones(count, dtype=bool)
    violation_score = np.zeros(count, dtype=np.float64)
    hard_failure_score = np.zeros(count, dtype=np.float64)

    constraints = [spec for spec in specs if spec.kind != "objective"]
    for spec in constraints:
        violation = spec.violation(measurements[spec.name])
        violation = np.where(np.isfinite(violation), violation, np.inf)
        feasible &= violation == 0.0
        violation_score += (1.0 + max(spec.priority, 0)) * violation

    for name, values in (hard_filters or {}).items():
        mask = np.asarray(values, dtype=bool)
        if len(mask) != count:
            raise ValueError(f"hard filter length mismatch: {name}")
        feasible &= mask
        hard_failure_score += (~mask).astype(np.float64) * (
            1.0 + max([spec.priority for spec in constraints], default=0)
        )

    feasible_idx = np.flatnonzero(feasible)
    infeasible_idx = np.flatnonzero(~feasible)
    objectives = sorted(
        (spec for spec in specs if spec.kind == "objective"),
        key=lambda spec: spec.priority,
        reverse=True,
    )
    if len(feasible_idx) and objectives:
        objective_keys = [
            np.where(
                np.isfinite(spec.objective_score(measurements[spec.name])),
                spec.objective_score(measurements[spec.name]),
                np.inf,
            )[feasible_idx]
            for spec in objectives
        ]
        feasible_idx = feasible_idx[
            np.lexsort(tuple(reversed(objective_keys)))
        ]
    if len(infeasible_idx):
        infeasible_idx = infeasible_idx[np.lexsort((
            violation_score[infeasible_idx],
            hard_failure_score[infeasible_idx],
        ))]
    return CandidateRanking(
        order=np.concatenate([feasible_idx, infeasible_idx]),
        feasible_mask=feasible,
        violation_score=violation_score,
        hard_failure_score=hard_failure_score,
    )


def route_guidance(ccs_residual: float, has_hard_inequality: bool = False,
                   moderate_residual: float = 0.02,
                   strong_residual: float = 0.05) -> str:
    """Route a scenario to ``cfg``, ``pp_cfg``, or ``ug``.

    Thresholds are policy defaults to be calibrated by the counterfactual
    residual sweep; they are not claimed as material constants.
    """
    residual = abs(float(ccs_residual))
    if has_hard_inequality or residual >= strong_residual:
        return "ug"
    if residual >= moderate_residual:
        return "pp_cfg"
    return "cfg"
