"""CrossAttn + FiLM 变体：SS 走 cross-attn（序列），VF 走 FiLM（标量调制）

完全模态分离：
- SS（51点序列）→ SS_TokenEncoder → 51 tokens → cross-attention
- VF（8维标量）→ FiLM encoder → (scale, shift) 调制每层 GroupNorm
- Time → sinusoidal → MLP
- 三者正交注入，互不干扰

对比 unet_crossattn（VF 仍走 label_emb channel-concat），本变体让 VF 独立于 SS 调制。
"""
import torch
import torch.nn as nn
from .UNets import (ResidualBlockConvTimeStep, MultiAttentionBlock,
                    DownSample, UpSample, norm_layer, timestep_embedding)
from .unet_crossattn import CrossAttentionBlock, SS_TokenEncoder


class FiLMModulation(nn.Module):
    """FiLM: VF scalar → (scale, shift) per channel, modulates GroupNorm output.

    h_modulated = (1 + scale) * GroupNorm(h) + shift
    scale, shift initialized to 0 → starts as identity (DiT adaLN-zero principle)
    """
    def __init__(self, vf_dim, channels):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(vf_dim, channels), nn.SiLU(),
            nn.Linear(channels, 2 * channels),  # scale + shift
        )
        # zero-init: starts as identity
        nn.init.zeros_(self.proj[-1].weight)
        nn.init.zeros_(self.proj[-1].bias)

    def forward(self, h, vf_emb):
        """h: (B,C,H,W), vf_emb: (B, vf_dim) → scale, shift: (B, 2C)"""
        params = self.proj(vf_emb)  # (B, 2C)
        scale, shift = params.chunk(2, dim=-1)  # each (B, C)
        return h * (1 + scale[:, :, None, None]) + shift[:, :, None, None]


class FiLMResidualBlock(nn.Module):
    """ResBlock with time (channel-concat) + VF FiLM modulation.

    Time: channel-concat (same as original ResidualBlockConvTimeStep)
    VF: FiLM modulation after first conv (separate path, orthogonal to time)
    """
    def __init__(self, channel_in, channel_out, time_channels, vf_dim,
                 groups=8, activation_fn=nn.SiLU(), dropout=None):
        super().__init__()
        # conv1 + GroupNorm
        lay1 = [norm_layer(channel_in, groups), activation_fn]
        if dropout is not None:
            lay1.append(nn.Dropout(dropout))
        lay1.append(nn.Conv2d(channel_in, channel_out, 3, padding="same"))
        self.conv1 = nn.Sequential(*lay1)

        # time embedding
        self.time_emb = nn.Sequential(activation_fn, nn.Linear(time_channels, channel_out))

        # VF FiLM (after conv1, before conv2)
        self.film = FiLMModulation(vf_dim, channel_out)

        # conv2 + GroupNorm
        lay2 = [norm_layer(channel_out, groups), activation_fn]
        if dropout is not None:
            lay2.append(nn.Dropout(dropout))
        lay2.append(nn.Conv2d(channel_out, channel_out, 3, padding="same"))
        self.conv2 = nn.Sequential(*lay2)

        # shortcut
        if channel_in != channel_out:
            self.shortcut = nn.Conv2d(channel_in, channel_out, 1)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x, t_emb, vf_emb, mask):
        """x: (B,C,H,W), t_emb: (B, time_channels), vf_emb: (B, vf_dim), mask: (B,)"""
        h = self.conv1(x)
        # time: channel-concat (broadcast)
        t = self.time_emb(t_emb)  # (B, channel_out)
        h = h + t[:, :, None, None]
        # VF: FiLM modulation (mask=0 → vf_emb zeroed externally → FiLM=identity due to zero-init)
        h = self.film(h, vf_emb * mask[:, None])
        # conv2
        h = self.conv2(h)
        return h + self.shortcut(x)


class UNetCrossAttnFiLM(nn.Module):
    """SS cross-attention + VF FiLM — 完全模态分离。

    SS（序列）→ cross-attention；VF（标量）→ FiLM 调制；Time → channel-concat。
    兼容 forward(x, timesteps, c, mask) 接口。
    c = [SS(51) | VF×N | ...]，前51维为SS，随后 ``vf_dim`` 维为VF。
    """

    def __init__(self, img_shape, label_dim, one_hot,
                 first_conv_channels, channel_mutipliers, has_attention,
                 num_heads=4, num_res_blocks=1, norm_groups=None,
                 interpolation="nearest", activation_fn=nn.SiLU(), dropout=None,
                 cross_attn_embed=64, vf_dim=8, **kwargs):
        super().__init__()
        channel_in, img_size = img_shape[0], img_shape[1]
        channel_list = [first_conv_channels * m for m in channel_mutipliers]
        if has_attention is None:
            has_attention = [False] * len(channel_list)

        self.ss_dim = 51
        self.vf_dim = vf_dim
        self.ss_encoder = SS_TokenEncoder(ss_dim=self.ss_dim, embed_dim=cross_attn_embed)

        self.first_conv_channels = first_conv_channels
        time_emb_dim = first_conv_channels * 4
        self.time_emb = nn.Sequential(
            nn.Linear(first_conv_channels, time_emb_dim), nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim))

        # VF FiLM encoder: VF×N → vf_emb (for FiLM modulation)
        self.vf_encoder = nn.Sequential(
            nn.Linear(vf_dim, first_conv_channels), nn.SiLU(),
            nn.Linear(first_conv_channels, first_conv_channels))

        self.first_conv = nn.Conv2d(channel_in, first_conv_channels, 3, padding=1)

        # encoder
        self.encoder = nn.ModuleList()
        self.skip_channels = []
        encoder_skip_idx = []
        for i in range(len(channel_list)):
            in_ch = first_conv_channels if i == 0 else channel_list[i - 1]
            self.encoder.append(FiLMResidualBlock(
                in_ch, channel_list[i], time_emb_dim, first_conv_channels,
                groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            self.skip_channels.append(channel_list[i])
            encoder_skip_idx.append(len(self.encoder) - 1)
            for _ in range(1, num_res_blocks):
                self.encoder.append(FiLMResidualBlock(
                    channel_list[i], channel_list[i], time_emb_dim, first_conv_channels,
                    groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                self.skip_channels.append(channel_list[i])
                encoder_skip_idx.append(len(self.encoder) - 1)
            if i != len(channel_list) - 1:
                self.encoder.append(DownSample(channel_list[i]))
        self.encoder_skip = torch.zeros(len(self.encoder), dtype=bool)
        self.encoder_skip[encoder_skip_idx] = True

        # bottleneck + cross-attn
        self.bottleneck = nn.ModuleList([
            FiLMResidualBlock(channel_list[-1], channel_list[-1], time_emb_dim,
                              first_conv_channels, groups=norm_groups,
                              activation_fn=activation_fn, dropout=dropout),
            MultiAttentionBlock(channel_list[-1], num_heads=num_heads, groups=norm_groups),
            CrossAttentionBlock(channel_list[-1], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                                 num_heads=num_heads, groups=norm_groups),
            FiLMResidualBlock(channel_list[-1], channel_list[-1], time_emb_dim,
                              first_conv_channels, groups=norm_groups,
                              activation_fn=activation_fn, dropout=dropout),
        ])

        # decoder
        self.decoder = nn.ModuleList()
        decoder_skip_idx = []
        for i in reversed(range(len(channel_list))):
            in_ch = channel_list[-1] + self.skip_channels.pop() if i == len(channel_list) - 1 \
                    else channel_list[i + 1] + self.skip_channels.pop()
            self.decoder.append(FiLMResidualBlock(
                in_ch, channel_list[i], time_emb_dim, first_conv_channels,
                groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            decoder_skip_idx.append(len(self.decoder) - 1)
            if has_attention[i]:
                self.decoder.append(MultiAttentionBlock(channel_list[i], num_heads=num_heads, groups=norm_groups))
                self.decoder.append(CrossAttentionBlock(
                    channel_list[i], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                    num_heads=num_heads, groups=norm_groups))
            for _ in range(1, num_res_blocks):
                in_ch = channel_list[i] + self.skip_channels.pop()
                self.decoder.append(FiLMResidualBlock(
                    in_ch, channel_list[i], time_emb_dim, first_conv_channels,
                    groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                decoder_skip_idx.append(len(self.decoder) - 1)
                if has_attention[i]:
                    self.decoder.append(MultiAttentionBlock(channel_list[i], num_heads=num_heads, groups=norm_groups))
                    self.decoder.append(CrossAttentionBlock(
                        channel_list[i], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                        num_heads=num_heads, groups=norm_groups))
            if i != 0:
                self.decoder.append(UpSample(channel_list[i], interpolation=interpolation))
        self.decoder_skip = torch.zeros(len(self.decoder), dtype=bool)
        self.decoder_skip[decoder_skip_idx] = True

        self.out = nn.Sequential(
            norm_layer(channel_list[0], norm_groups), nn.SiLU(),
            nn.Conv2d(channel_list[0], channel_in, 3, padding=1))

    def forward(self, x, timesteps, c, mask):
        B = x.shape[0]
        # SS tokens (cross-attention path)
        ss_curve = c[:, :self.ss_dim]
        ss_tokens = self.ss_encoder(ss_curve) * mask[:, None, None]

        # VF embedding (FiLM path)
        vf_raw = c[:, self.ss_dim:self.ss_dim + self.vf_dim]  # (B, vf_dim)
        vf_emb = self.vf_encoder(vf_raw)  # (B, first_conv_channels)

        skips = []
        x = self.first_conv(x)
        t_emb = self.time_emb(timestep_embedding(timesteps, embed_dim=self.first_conv_channels))

        for eskip, layer in zip(self.encoder_skip, self.encoder):
            if isinstance(layer, FiLMResidualBlock):
                x = layer(x, t_emb, vf_emb, mask)
            else:
                x = layer(x)
            if eskip:
                skips.append(x)

        for layer in self.bottleneck:
            if isinstance(layer, FiLMResidualBlock):
                x = layer(x, t_emb, vf_emb, mask)
            elif isinstance(layer, CrossAttentionBlock):
                x = layer(x, ss_tokens)
            else:
                x = layer(x)

        for dskip, layer in zip(self.decoder_skip, self.decoder):
            if dskip:
                x = torch.cat([x, skips.pop()], dim=1)
            if isinstance(layer, FiLMResidualBlock):
                x = layer(x, t_emb, vf_emb, mask)
            elif isinstance(layer, CrossAttentionBlock):
                x = layer(x, ss_tokens)
            else:
                x = layer(x)

        return self.out(x)
