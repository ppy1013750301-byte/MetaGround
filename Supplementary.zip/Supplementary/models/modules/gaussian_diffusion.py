# %%
import torch
import torch.nn as nn
import torch.nn.functional as nnF
import math
import numpy as np
from tqdm import tqdm

# %%
"""Classifier free guidance Diffusion Model"""


def guidance_result_to_loss(result):
    """Normalize old equality guidance and new direct-loss callbacks.

    Legacy callbacks return ``(prediction, target)`` and retain their two-sided
    MSE semantics.  A callback may now instead return a differentiable tensor
    containing its own loss.  This is required for genuine one-sided upper and
    lower engineering constraints.
    """
    if isinstance(result, (tuple, list)):
        if len(result) != 2:
            raise ValueError("guidance callback tuple must contain (prediction, target)")
        prediction, target = result
        return ((prediction - target) ** 2).mean()
    if not torch.is_tensor(result):
        raise TypeError("guidance callback must return a tensor or (prediction, target)")
    return result.mean()


def constraint_guidance_loss(prediction, kind, target, tolerance):
    """Differentiable dimensionless loss matching ``ConstraintSpec`` semantics."""
    if tolerance <= 0:
        raise ValueError("constraint guidance tolerance must be positive")
    target = torch.as_tensor(target, dtype=prediction.dtype, device=prediction.device)
    if kind == "equality":
        residual = torch.relu(torch.abs(prediction - target) - tolerance)
    elif kind == "upper_bound":
        residual = torch.relu(prediction - target)
    elif kind == "lower_bound":
        residual = torch.relu(target - prediction)
    else:
        raise ValueError(f"unsupported guided constraint kind: {kind}")
    return (residual / tolerance) ** 2


def objective_guidance_loss(prediction, sense, scale):
    """Differentiable scalar objective with an auditable physical scale."""
    if scale <= 0:
        raise ValueError("objective guidance scale must be positive")
    if sense == "minimize":
        sign = 1.0
    elif sense == "maximize":
        sign = -1.0
    else:
        raise ValueError(f"unsupported objective sense: {sense}")
    return sign * prediction / scale


def beta_scheduler(tot_timesteps, type="linear", s=0.008):
    if type == "linear":
        scale = 1000 / tot_timesteps
        beta_start = scale * 0.0001
        beta_end = scale * 0.02
        return torch.linspace(beta_start, beta_end, tot_timesteps)
    elif type == "sigmoid":
        betas = torch.linspace(-6, 6, tot_timesteps)
        betas = (
            torch.sigmoid(betas)
            / (betas.max() - betas.min())
            * (0.02 - betas.min())
            / 10
        )
        return betas
    elif type == "cosine":
        """
        cosine schedule
        as proposed in https://arxiv.org/abs/2102.09672
        """
        steps = tot_timesteps + 1
        x = torch.linspace(0, tot_timesteps, steps, dtype=torch.float64)
        alphas_cumprod = (
            torch.cos(((x / tot_timesteps) + s) / (1 + s) * math.pi * 0.5) ** 2
        )
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clip(betas, 0, 0.999)
    else:
        raise ValueError(f"unknown beta scheduler {type}")


class GaussianDiffusion:
    def __init__(self, img_shape, timesteps=1000, beta_schedule="linear"):
        self.img_shape = img_shape
        self.timesteps = timesteps

        self.betas = beta_scheduler(timesteps, type=beta_schedule)

        self.alphas = 1.0 - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, axis=0)
        self.alphas_cumprod_prev = nnF.pad(
            self.alphas_cumprod[:-1], (1, 0), value=1.0)

        # calculations for diffusion q(x_t | x_{t-1}) and others
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(
            1.0 - self.alphas_cumprod)
        self.log_one_minus_alphas_cumprod = torch.log(
            1.0 - self.alphas_cumprod)
        self.sqrt_recip_alphas_cumprod = torch.sqrt(1.0 / self.alphas_cumprod)
        self.sqrt_recipm1_alphas_cumprod = torch.sqrt(
            1.0 / self.alphas_cumprod - 1)

        # calculations for posterior q(x_{t-1} | x_t, x_0)
        self.posterior_variance = (
            self.betas * (1.0 - self.alphas_cumprod_prev) /
            (1.0 - self.alphas_cumprod)
        )
        # below: log calculation clipped because the posterior variance is 0 at the beginning
        # of the diffusion chain
        # self.posterior_log_variance_clipped = torch.log(self.posterior_variance.clamp(min =1e-20))
        self.posterior_log_variance_clipped = torch.log(
            torch.cat([self.posterior_variance[1:2],
                      self.posterior_variance[1:]])
        )

        self.posterior_mean_coef1 = (
            self.betas
            * torch.sqrt(self.alphas_cumprod_prev)
            / (1.0 - self.alphas_cumprod)
        )
        self.posterior_mean_coef2 = (
            (1.0 - self.alphas_cumprod_prev)
            * torch.sqrt(self.alphas)
            / (1.0 - self.alphas_cumprod)
        )

    # get the param of given timestep t
    def _extract(self, a, t, x_shape):
        """
        t is time step in [0, total_time_step], shape: (batch_size, )
        take the value of a at t
        """
        batch_size = t.shape[0]
        out = a.to(t.device).gather(0, t).float()
        out = out.reshape(batch_size, *((1,) * (len(x_shape) - 1)))
        return out

    def q_sample(self, x_start, t, noise=None):
        """
        forward diffusion (using the nice property): q(x_t | x_0)
        x_t= sqrt(\bar{alpha_t}) * x_0 + sqrt(1 - \bar{alpha_t}) * noise
        t: (batch_size, )
        """
        if noise is None:
            noise = torch.randn_like(x_start)
        # (total_timesteps), (nb, ) -> (nb, 1,...)
        sqrt_alphas_cumprod_t = self._extract(
            self.sqrt_alphas_cumprod, t, x_start.shape
        )
        sqrt_one_minus_alphas_cumprod_t = self._extract(
            self.sqrt_one_minus_alphas_cumprod, t, x_start.shape
        )

        return sqrt_alphas_cumprod_t * x_start + sqrt_one_minus_alphas_cumprod_t * noise

    def q_mean_variance(self, x_start, t):
        """
        q(x_t | x_0);
        x_t= sqrt(\bar{alpha_t}) * x_0 + sqrt(1 - \bar{alpha_t}) * noise;
        mu=sqrt(\bar{alpha_t}) * x_0;
        sigma^2=1-\bar{alpha_t};
        """
        mean = self._extract(self.sqrt_alphas_cumprod,
                             t, x_start.shape) * x_start
        variance = self._extract(1.0 - self.alphas_cumprod, t, x_start.shape)
        log_variance = self._extract(
            self.log_one_minus_alphas_cumprod, t, x_start.shape
        )
        return mean, variance, log_variance

    def q_posterior_mean_variance(self, x_start, x_t, t):
        """
        diffusion posterior: q(x_{t-1} | x_t, x_0)
        mu=coe1 * x_0 + coe2 * x_t;
        coe1=beta_t * sqrt(\bar{\alpha_{t-1}}) / (1 - \bar{\alpha_t});
        coe2=(1 - \bar{\alpha_{t-1}}) * sqrt(\bar{\alpha_t}) / (1 - \bar{\alpha_t});
        """
        posterior_mean = (
            self._extract(self.posterior_mean_coef1, t, x_t.shape) * x_start
            + self._extract(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_variance = self._extract(
            self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = self._extract(
            self.posterior_log_variance_clipped, t, x_t.shape
        )
        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    #
    def predict_start_from_noise(self, x_t, t, noise):
        """
        compute x_0 from x_t and noise
        reverse of `q_sample`:
        x_t= sqrt(\bar{alpha_t}) * x_0 + sqrt(1 - \bar{alpha_t}) * noise
        """
        return (
            self._extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t
            - self._extract(self.sqrt_recipm1_alphas_cumprod,
                            t, x_t.shape) * noise
        )

    #
    def p_mean_variance(
        self, model, x_t, t, c, w, clip_denoised=True
    ):
        """
        compute predicted mean and variance of p(x_{t-1} | x_t)

        noise is from the model

        x0 is from the inverse of the q_sample, q(x_t | x_0) -->x0,
        x_t= sqrt(\bar{alpha_t}) * x_0 + sqrt(1 - \bar{alpha_t}) * noise


        then diffusion posterior: q(x_{t-1} | x_t, x_0) to get the mean and variance

        """
        device = next(model.parameters()).device
        batch_size = x_t.shape[0]
        # predict noise using model

        if w == -1:
            pred_noise_none = model(
            x_t, t, c, torch.zeros(batch_size).int().to(device))
            pred_noise = pred_noise_none
        elif w == 0:
            pred_noise_c = model(x_t, t, c, torch.ones(
                batch_size).int().to(device))
            pred_noise = pred_noise_c
        else:
            pred_noise_none = model(
                x_t, t, c, torch.zeros(batch_size).int().to(device))
            pred_noise_c = model(x_t, t, c, torch.ones(
                batch_size).int().to(device))
            pred_noise = (1 + w) * pred_noise_c - w * pred_noise_none

        # get the predicted x_0: different from the algorithm2 in the paper
        x_recon = self.predict_start_from_noise(x_t, t, pred_noise)
        if clip_denoised:
            x_recon = torch.clamp(x_recon, min=-1.0, max=1.0)
        model_mean, posterior_variance, posterior_log_variance = (
            self.q_posterior_mean_variance(x_recon, x_t, t)
        )
        return model_mean, posterior_variance, posterior_log_variance

    @torch.no_grad()
    def p_sample(self, model, x_t, t, c, w, clip_denoised=True):
        """
        denoise_step: sample x_{t-1} from x_t and pred_noise:
        1. compute predicted mean and variance of p(x_{t-1} | x_t):
            a. noise is from the model
            b. x0 is from the inverse of the q_sample, q(x_t | x_0) -->x0,
               x_t= sqrt(\bar{alpha_t}) * x_0 + sqrt(1 - \bar{alpha_t}) * noise
            c. then diffusion posterior: q(x_{t-1} | x_t, x_0) to get the mean and variance
        2. sample x_{t-1} from the predicted mean and variance
        """
        # predict mean and variance
        model_mean, _, model_log_variance = self.p_mean_variance(
            model, x_t, t, c, w, clip_denoised=clip_denoised
        )
        noise = torch.randn_like(x_t)
        # no noise when t == 0 QB: to be look into???
        nonzero_mask = (t != 0).float().view(-1, *([1] * (len(x_t.shape) - 1)))
        # compute x_{t-1}
        pred_img = model_mean + nonzero_mask * \
            (0.5 * model_log_variance).exp() * noise
        return pred_img

    # denoise: reverse diffusion
    @torch.no_grad()
    def p_sample_loop(
        self,
        model,
        image_shape,
        labels,
        w=2,
        clip_denoised=True,
        timesteps=None,
        all_timesteps=False,
    ):
        if timesteps is None:
            timesteps = self.timesteps

        batch_size = labels.shape[0]
        device = next(model.parameters()).device
        labels = labels.to(device)
        # start from pure noise (for each example in the batch)
        img = torch.randn((batch_size, *image_shape), device=device)
        imgs = []
        for i in tqdm(
            reversed(range(0, timesteps)),
            desc="sampling loop time step",
            total=timesteps,
        ):
            img = self.p_sample(
                model,
                img,
                torch.full((batch_size,), i, device=device, dtype=torch.long),
                labels,
                w,
                clip_denoised
            )
            if all_timesteps:
                imgs.append(img.cpu().numpy())

        if all_timesteps:
            return np.array(imgs)
        else:
            return img.cpu().numpy()

    def ancestral_sample_universal_guidance(
        self, model, labels,
        forward_fns,
        lambdas,
        image_shape=None,
        w_base=1.0,
        clip_denoised=False,
        guidance_eta=0.1,
        deconflict="priority",
        grad_schedule="late",
    ):
        """Full ancestral reverse diffusion with optional proxy gradients.

        This is the ancestral counterpart of ``ddim_sample_universal_guidance``.
        The reverse chain uses every diffusion timestep; proxy gradients are
        applied to the predicted ``x_{t-1}`` mean before ancestral noise is
        added.  Keeping this in the diffusion module lets CFG, fixed-UG,
        adaptive-UG and router share exactly the same outer sampler.
        """
        if len(forward_fns) != len(lambdas):
            raise ValueError("forward_fns and lambdas must have the same length")
        if any(float(value) < 0 for value in lambdas):
            raise ValueError("universal-guidance weights must be non-negative")
        if image_shape is None:
            image_shape = self.img_shape
        device = next(model.parameters()).device
        labels = labels.to(device)
        batch_size = labels.shape[0]
        sample_img = torch.randn((batch_size, *image_shape), device=device)
        ones = torch.ones(batch_size, dtype=torch.int32, device=device)
        zeros = torch.zeros(batch_size, dtype=torch.int32, device=device)
        self._deconflict_mode = deconflict

        for step in reversed(range(self.timesteps)):
            t = torch.full((batch_size,), step, device=device, dtype=torch.long)
            alpha_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            x_t = sample_img.detach().clone().requires_grad_(True)

            eps_c = model(x_t, t, labels, ones)
            if w_base > 0:
                eps_u = model(x_t, t, labels, zeros)
                eps = (1.0 + w_base) * eps_c - w_base * eps_u
            else:
                eps = eps_c
            x0_pred = self.predict_start_from_noise(x_t, t, eps)
            if clip_denoised:
                x0_pred = torch.clamp(x0_pred, -1.0, 1.0)

            progress = (self.timesteps - 1 - step) / max(self.timesteps - 1, 1)
            if grad_schedule == "none":
                ts_scale = 1.0
            elif grad_schedule == "linear":
                ts_scale = progress
            elif grad_schedule == "late":
                ts_scale = max(0.0, (progress - 0.5) * 2.0)
            else:
                raise ValueError(f"unsupported grad_schedule: {grad_schedule}")

            raw_grads = []
            if ts_scale > 0:
                for (name, fn), lam in zip(forward_fns, lambdas):
                    if float(lam) <= 0:
                        continue
                    loss = guidance_result_to_loss(fn(x0_pred))
                    if not loss.requires_grad:
                        continue
                    grad = torch.autograd.grad(
                        loss, x_t, retain_graph=True, allow_unused=True
                    )[0]
                    if grad is not None:
                        raw_grads.append((name, grad, float(lam)))

            orthogonal = []
            for name, grad, lam in raw_grads:
                current = grad.clone()
                if deconflict in ("priority", "pcgrad"):
                    for _, high, _ in orthogonal:
                        denom = high.flatten(1).pow(2).sum(dim=1, keepdim=True).clamp(min=1e-12)
                        coeff = (current.flatten(1) * high.flatten(1)).sum(
                            dim=1, keepdim=True
                        ) / denom
                        current = current - coeff.view(-1, 1, 1, 1) * high
                orthogonal.append((name, current, lam))

            grad_total = torch.zeros_like(sample_img)
            for _, grad, lam in orthogonal:
                norm = grad.flatten(1).norm(dim=1).mean().clamp(min=1e-8)
                grad_total = grad_total + lam * grad / norm

            with torch.no_grad():
                x0_detached = x0_pred.detach()
                mean, variance, log_variance = self.q_posterior_mean_variance(
                    x0_detached, sample_img, t
                )
                noise = torch.randn_like(sample_img)
                nonzero = (t != 0).float().view(-1, 1, 1, 1)
                sample_img = mean + nonzero * torch.exp(0.5 * log_variance) * noise
                if orthogonal:
                    sample_img = sample_img - float(guidance_eta) * ts_scale * grad_total.detach()

        return sample_img.detach().cpu().numpy()

    # sample new images

    @torch.no_grad()
    def sample(
        self,
        model,
        labels,
        w=2,
        image_shape=None,
        clip_denoised=True,
        timesteps=None,
        all_timesteps=False,
        seed=None
    ):
        if seed is not None:
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed(seed)
        if image_shape is None:
            image_shape = self.img_shape
        return self.p_sample_loop(
            model,
            image_shape,
            labels,
            w,
            clip_denoised,
            timesteps=timesteps,
            all_timesteps=all_timesteps
        )

    # use ddim to sample
    @torch.no_grad()
    def ddim_sample(
        self,
        model,
        labels,
        image_shape=None,
        ddim_timesteps=50,
        w=2,
        ddim_discr_method="uniform",
        ddim_eta=0.0,
        clip_denoised=True,
    ):
        if image_shape is None:
            image_shape = self.img_shape
        # make ddim timestep sequence
        if ddim_discr_method == "uniform":
            c = self.timesteps // ddim_timesteps
            ddim_timestep_seq = np.asarray(list(range(0, self.timesteps, c)))
        elif ddim_discr_method == "quad":
            ddim_timestep_seq = (
                (np.linspace(0, np.sqrt(self.timesteps * 0.8), ddim_timesteps)) ** 2
            ).astype(int)
        else:
            raise NotImplementedError(
                f'There is no ddim discretization method called "{ddim_discr_method}"'
            )
        # add one to get the final alpha values right (the ones from first scale to data during sampling)
        ddim_timestep_seq = ddim_timestep_seq + 1
        # previous sequence
        ddim_timestep_prev_seq = np.append(
            np.array([0]), ddim_timestep_seq[:-1])

        device = next(model.parameters()).device

        labels = labels.to(device)
        batch_size = labels.shape[0]
        # start from pure noise (for each example in the batch)
        sample_img = torch.randn((batch_size, *image_shape), device=device)
        seq_img = [sample_img.cpu().numpy()]

        for i in tqdm(
            reversed(range(0, ddim_timesteps)),
            desc="sampling loop time step",
            total=ddim_timesteps,
        ):
            t = torch.full(
                (batch_size,
                 ), ddim_timestep_seq[i], device=device, dtype=torch.long
            )
            prev_t = torch.full(
                (batch_size,),
                ddim_timestep_prev_seq[i],
                device=device,
                dtype=torch.long,
            )

            # 1. get current and previous alpha_cumprod
            alpha_cumprod_t = self._extract(
                self.alphas_cumprod, t, sample_img.shape)
            alpha_cumprod_t_prev = self._extract(
                self.alphas_cumprod, prev_t, sample_img.shape
            )

            # 2. predict noise using model
            if w == -1:
                pred_noise_none = model(
                    sample_img, t, labels, torch.zeros(
                        batch_size, dtype=torch.int32).to(device))
                pred_noise = pred_noise_none
            elif w == 0:
                pred_noise_c = model(
                    sample_img, t, labels, torch.ones(
                        batch_size, dtype=torch.int32).to(device)
                )
                pred_noise = pred_noise_c
            else:
                pred_noise_none = model(
                    sample_img, t, labels, torch.zeros(
                        batch_size, dtype=torch.int32).to(device))
                pred_noise_c = model(
                    sample_img, t, labels, torch.ones(
                        batch_size, dtype=torch.int32).to(device)
                )
                pred_noise = (1 + w) * pred_noise_c - w * pred_noise_none
            # 3. get the predicted x_0
            pred_x0 = (
                sample_img - torch.sqrt((1.0 - alpha_cumprod_t)) * pred_noise
            ) / torch.sqrt(alpha_cumprod_t)
            if clip_denoised:
                pred_x0 = torch.clamp(pred_x0, min=-1.0, max=1.0)

            # 4. compute variance: "sigma_t(η)" -> see formula (16)
            # σ_t = sqrt((1 − α_t−1)/(1 − α_t)) * sqrt(1 − α_t/α_t−1)
            sigmas_t = ddim_eta * torch.sqrt(
                (1 - alpha_cumprod_t_prev)
                / (1 - alpha_cumprod_t)
                * (1 - alpha_cumprod_t / alpha_cumprod_t_prev)
            )

            # 5. compute "direction pointing to x_t" of formula (12)
            pred_dir_xt = (
                torch.sqrt(1 - alpha_cumprod_t_prev - sigmas_t**2) * pred_noise
            )

            # 6. compute x_{t-1} of formula (12)
            x_prev = (
                torch.sqrt(alpha_cumprod_t_prev) * pred_x0
                + pred_dir_xt
                + sigmas_t * torch.randn_like(sample_img)
            )

            sample_img = x_prev

        return sample_img.cpu().numpy()

    # ── CCG (Correlation-Compensated Guidance) ─────────────────────────────
    # 自适应引导：引导强度随条件相关性 r 增大而增强
    # ε̂_CCG = ε̂_CFG + Σᵢ γᵢ/√(1-rᵢ²) · ĝᵢ⊥
    # 其中 ĝᵢ⊥ 为 Gram-Schmidt 去冲突后的梯度
    # γᵢ 为基础引导强度，1/√(1-r²) 补偿独立可控空间缩减
    def ddim_sample_ccg(
        self, model, labels,
        physics_slices,
        forward_fns,            # [(name, fn), ...] fn(x0_pred)->(pred, target)
        correlations,           # dict {name: r} 条件相关系数（与主条件 SS 的 r）
        gamma=1.0,              # 基础引导强度
        w_base=6.0,             # 基础 CFG
        image_shape=None,
        ddim_timesteps=50,
        clip_denoised=True,
        grad_schedule="late",
    ):
        self._deconflict_mode = "priority"
        if image_shape is None:
            image_shape = self.img_shape
        c = self.timesteps // ddim_timesteps
        ddim_ts = np.asarray(list(range(0, self.timesteps, c))) + 1
        ddim_ts_prev = np.append(np.array([0]), ddim_ts[:-1])
        device = next(model.parameters()).device
        labels = labels.to(device)
        B = labels.shape[0]
        sample_img = torch.randn((B, *image_shape), device=device)
        ones = torch.ones(B, dtype=torch.int32, device=device)
        zeros = torch.zeros(B, dtype=torch.int32, device=device)

        # 预构造 no-VF 条件（用于 per-physics CFG 部分）
        c_no_vf = labels.clone()
        vf_slice = physics_slices.get("vf")
        if vf_slice:
            c_no_vf[:, vf_slice[0]:vf_slice[1]] = 0.0

        for i in tqdm(reversed(range(ddim_timesteps)), desc="CCG", total=ddim_timesteps):
            t = torch.full((B,), ddim_ts[i], device=device, dtype=torch.long)
            pt = torch.full((B,), ddim_ts_prev[i], device=device, dtype=torch.long)
            a_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            a_t_prev = self._extract(self.alphas_cumprod, pt, sample_img.shape)

            # 时间步缩放
            progress = (ddim_timesteps - 1 - i) / max(ddim_timesteps - 1, 1)
            ts_scale = {"none":1.0, "linear":progress,
                        "late":max(0.0,(progress-0.5)*2)}[grad_schedule]

            # ── 梯度路径（需 grad）──
            raw_grads = []
            if ts_scale > 0:
                x_t = sample_img.detach().clone().requires_grad_(True)
                eps_g = model(x_t, t, labels, ones)
                x0_g = (x_t - torch.sqrt(1-a_t)*eps_g) / torch.sqrt(a_t)
                if clip_denoised: x0_g = torch.clamp(x0_g, -1, 1)

                for (cname, fn), lam in zip(forward_fns, [gamma]*len(forward_fns)):
                    pred_val, target_val = fn(x0_g)
                    loss = ((pred_val - target_val) ** 2).mean()
                    if loss.requires_grad:
                        g = torch.autograd.grad(loss, x_t, retain_graph=True,
                                                allow_unused=True)[0]
                        if g is not None:
                            raw_grads.append((cname, g, lam))

                # Gram-Schmidt 去冲突
                ortho_grads = []
                for cname, g, lam in raw_grads:
                    g_orth = g.clone()
                    for _, g_high, _ in ortho_grads:
                        if g_high.flatten().norm() > 1e-8:
                            proj = (g_orth.flatten() * g_high.flatten()).sum() / \
                                   (g_high.flatten().norm() ** 2)
                            g_orth = g_orth - proj * g_high
                    # CCG 核心：自适应补偿 1/√(1-r²)
                    r_i = correlations.get(cname, 0.0)
                    compensation = 1.0 / (max(1 - r_i**2, 0.01)**0.5)  # 防除零
                    g_orth = g_orth / (g_orth.flatten(1).norm(dim=1).mean().clamp(min=1e-8)+1e-8)
                    ortho_grads.append((cname, g_orth * compensation, lam))

                grad_total = sum(lam * g for _, g, lam in ortho_grads)
            else:
                grad_total = torch.zeros_like(sample_img)

            # ── CFG + CCG 梯度 ──
            with torch.no_grad():
                eps_full = model(sample_img, t, labels, ones)
                if w_base > 0:
                    eps_uncond = model(sample_img, t, labels, zeros)
                    eps = (1+w_base)*eps_full - w_base*eps_uncond
                else:
                    eps = eps_full
                pred_x0 = (sample_img - torch.sqrt(1-a_t)*eps) / torch.sqrt(a_t)
                if clip_denoised: pred_x0 = torch.clamp(pred_x0, -1, 1)
                x_prev = torch.sqrt(a_t_prev)*pred_x0 + torch.sqrt(1-a_t_prev)*eps
                x_prev = x_prev - gamma * ts_scale * grad_total.detach()
            sample_img = x_prev

        return sample_img.detach().cpu().numpy()

    # ── Compositional CFG (Liu et al. 2022) ────────────────────────────────
    # 外部基线：每条件独立引导，求和
    # ε̂ = ε∅ + Σᵢ sᵢ·(ε_{cᵢ} − ε∅)
    # 需要每条件独立评分（用 PP-drop 训练的模型支持条件部分置零）
    @torch.no_grad()
    def ddim_sample_compositional_cfg(
        self, model, labels,
        physics_slices,          # dict {name: (start, end)}
        scales=None,             # dict {name: s_i} per-condition guidance scale
        image_shape=None,
        ddim_timesteps=50,
        clip_denoised=True,
    ):
        """Compositional CFG (Liu et al. 2022) — external baseline.

        ε̂ = ε∅ + Σᵢ sᵢ·(ε_{cᵢ} − ε∅)

        每条件独立评分：将其他条件置零，只保留条件 i。
        需要 PP-drop 训练的模型（支持部分条件置零）。
        """
        if scales is None:
            scales = {name: 6.0 for name in physics_slices}
        if image_shape is None:
            image_shape = self.img_shape
        c = self.timesteps // ddim_timesteps
        ddim_ts = np.asarray(list(range(0, self.timesteps, c))) + 1
        ddim_ts_prev = np.append(np.array([0]), ddim_ts[:-1])
        device = next(model.parameters()).device
        labels = labels.to(device)
        B = labels.shape[0]
        sample_img = torch.randn((B, *image_shape), device=device)
        ones = torch.ones(B, dtype=torch.int32, device=device)
        zeros = torch.zeros(B, dtype=torch.int32, device=device)

        # 预构造每条件"只保留该条件"的版本
        cond_only = {}
        for name, (ps, pe) in physics_slices.items():
            c_only = torch.zeros_like(labels)
            c_only[:, ps:pe] = labels[:, ps:pe]
            cond_only[name] = c_only

        for i in tqdm(reversed(range(ddim_timesteps)),
                      desc="compositional CFG", total=ddim_timesteps):
            t = torch.full((B,), ddim_ts[i], device=device, dtype=torch.long)
            pt = torch.full((B,), ddim_ts_prev[i], device=device, dtype=torch.long)
            a_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            a_t_prev = self._extract(self.alphas_cumprod, pt, sample_img.shape)

            # ε∅ (unconditional)
            eps_uncond = model(sample_img, t, labels, zeros)
            # Σᵢ sᵢ·(ε_{cᵢ} − ε∅)
            eps_guided = eps_uncond.clone()
            for name, s in scales.items():
                eps_ci = model(sample_img, t, cond_only[name], ones)
                eps_guided = eps_guided + s * (eps_ci - eps_uncond)

            # DDIM 更新
            pred_x0 = (sample_img - torch.sqrt(1 - a_t) * eps_guided) / torch.sqrt(a_t)
            if clip_denoised:
                pred_x0 = torch.clamp(pred_x0, -1.0, 1.0)
            x_prev = (torch.sqrt(a_t_prev) * pred_x0
                      + torch.sqrt(1 - a_t_prev) * eps_guided)
            sample_img = x_prev

        return sample_img.cpu().numpy()

    # ── Per-physics CFG DDIM ────────────────────────────────────────────────
    @torch.no_grad()
    def ddim_sample_per_physics(
        self, model, labels,
        physics_slices,          # dict {name: (start, end)} condition 维度切片
        w_base=6.0,              # 基础 CFG 权重（作用在整体条件上）
        w_physics=None,         # dict {name: extra_weight}，每物理额外引导
        image_shape=None,
        ddim_timesteps=50,
        ddim_discr_method="uniform",
        ddim_eta=0.0,
        clip_denoised=True,
    ):
        """Per-physics classifier-free guidance DDIM.

        标准 CFG:  ε = (1+w_base)·ε_full − w_base·ε_uncond
        每物理额外引导：  + Σ_p w_p · (ε_full − ε_{no_p})
        其中 ε_{no_p} = 完整条件中物理 p 部分置零后的预测。
        w_p=0 → 不额外引导；w_p>0 → 放大物理 p 的影响。

        这样 SS 仍为主导（ε_full 里包含），VF/EA 可单独加权强化。
        """
        if w_physics is None:
            w_physics = {}
        if image_shape is None:
            image_shape = self.img_shape

        if ddim_discr_method == "uniform":
            c = self.timesteps // ddim_timesteps
            ddim_timestep_seq = np.asarray(list(range(0, self.timesteps, c)))
        else:
            raise NotImplementedError
        ddim_timestep_seq = ddim_timestep_seq + 1
        ddim_timestep_prev_seq = np.append(np.array([0]), ddim_timestep_seq[:-1])

        device = next(model.parameters()).device
        labels = labels.to(device)
        B = labels.shape[0]
        sample_img = torch.randn((B, *image_shape), device=device)

        # 预构造 "no_p" 条件（物理 p 置零）
        conds_no_p = {}
        for pname, (ps, pe) in physics_slices.items():
            if w_physics.get(pname, 0.0) == 0.0:
                continue   # 跳过 w=0 的物理，省一次前向
            c_no = labels.clone()
            c_no[:, ps:pe] = 0.0
            conds_no_p[pname] = c_no

        for i in tqdm(reversed(range(0, ddim_timesteps)),
                      desc="per-physics sampling", total=ddim_timesteps):
            t = torch.full((B,), ddim_timestep_seq[i], device=device, dtype=torch.long)
            prev_t = torch.full((B,), ddim_timestep_prev_seq[i], device=device, dtype=torch.long)

            alpha_cumprod_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            alpha_cumprod_t_prev = self._extract(self.alphas_cumprod, prev_t, sample_img.shape)

            ones = torch.ones(B, dtype=torch.int32, device=device)
            zeros = torch.zeros(B, dtype=torch.int32, device=device)

            # ε_full (full condition)
            eps_full = model(sample_img, t, labels, ones)

            # 基础 CFG + 每物理额外引导
            if w_base > 0:
                eps_uncond = model(sample_img, t, labels, zeros)
                pred_noise = (1 + w_base) * eps_full - w_base * eps_uncond
            else:
                pred_noise = eps_full

            for pname, c_no in conds_no_p.items():
                eps_no_p = model(sample_img, t, c_no, ones)
                pred_noise = pred_noise + w_physics[pname] * (eps_full - eps_no_p)

            # DDIM 更新
            pred_x0 = (sample_img - torch.sqrt(1.0 - alpha_cumprod_t) * pred_noise) / torch.sqrt(alpha_cumprod_t)
            if clip_denoised:
                pred_x0 = torch.clamp(pred_x0, min=-1.0, max=1.0)
            sigmas_t = ddim_eta * torch.sqrt(
                (1 - alpha_cumprod_t_prev) / (1 - alpha_cumprod_t)
                * (1 - alpha_cumprod_t / alpha_cumprod_t_prev))
            pred_dir_xt = torch.sqrt(1 - alpha_cumprod_t_prev - sigmas_t**2) * pred_noise
            sample_img = (torch.sqrt(alpha_cumprod_t_prev) * pred_x0 + pred_dir_xt
                          + sigmas_t * torch.randn_like(sample_img))

        return sample_img.cpu().numpy()

    # ── Universal Guidance DDIM（梯度引导，无需重训）──────────────────────
    # Bansal et al. 2023 (arXiv:2302.05059)
    # 每步去噪时，对每个条件算可微损失梯度，注入采样方向
    # 注意：不能用 @torch.no_grad()，否则梯度路径被禁用
    def ddim_sample_universal_guidance(
        self, model, labels,
        forward_fns,            # fn(x0)->(pred,target) or differentiable scalar loss
        lambdas,                # list of weights per condition
        image_shape=None,
        ddim_timesteps=50,
        w_base=6.0,             # 基础 CFG（0=纯梯度引导）
        clip_denoised=True,
        guidance_eta=1.0,       # 梯度引导强度
        deconflict="priority",  # "none" | "priority"(Gram-Schmidt按优先级) | "pcgrad"
        grad_schedule="late",   # "none"=全程 | "linear"=线性递增 | "late"=后半段
    ):
        self._deconflict_mode = deconflict  # 供内部去冲突逻辑读取
        if len(forward_fns) != len(lambdas):
            raise ValueError("forward_fns and lambdas must have the same length")
        if any(float(value) < 0 for value in lambdas):
            raise ValueError("universal-guidance weights must be non-negative")
        if image_shape is None:
            image_shape = self.img_shape
        c = self.timesteps // ddim_timesteps
        ddim_timestep_seq = np.asarray(list(range(0, self.timesteps, c))) + 1
        ddim_timestep_prev_seq = np.append(np.array([0]), ddim_timestep_seq[:-1])

        device = next(model.parameters()).device
        labels = labels.to(device)
        B = labels.shape[0]
        sample_img = torch.randn((B, *image_shape), device=device)

        ones = torch.ones(B, dtype=torch.int32, device=device)
        zeros = torch.zeros(B, dtype=torch.int32, device=device)

        for i in tqdm(reversed(range(0, ddim_timesteps)),
                      desc="universal guidance", total=ddim_timesteps):
            t = torch.full((B,), ddim_timestep_seq[i], device=device, dtype=torch.long)
            prev_t = torch.full((B,), ddim_timestep_prev_seq[i], device=device, dtype=torch.long)
            alpha_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            alpha_t_prev = self._extract(self.alphas_cumprod, prev_t, sample_img.shape)

            # ── 时间步缩放：i=ddim-1（最早，高噪声）→ 0；i=0（最晚，低噪声）→ 1
            # 早期 x0_pred 无意义，梯度 disruptive；后期才可信
            progress = (ddim_timesteps - 1 - i) / max(ddim_timesteps - 1, 1)
            if grad_schedule == "none":
                ts_scale = 1.0
            elif grad_schedule == "linear":
                ts_scale = progress
            elif grad_schedule == "late":   # 后半段才启用，前半为0
                ts_scale = max(0.0, (progress - 0.5) * 2.0)
            else:
                ts_scale = 1.0

            # ── 梯度路径：x_t → eps → x0_pred → 条件 loss（需要 grad）──
            x_t = sample_img.detach().clone().requires_grad_(True)
            eps_c = model(x_t, t, labels, ones)
            if w_base > 0:
                eps_un = model(x_t, t, labels, zeros)
                eps = (1 + w_base) * eps_c - w_base * eps_un
            else:
                eps = eps_c
            x0_pred = (x_t - torch.sqrt(1 - alpha_t) * eps) / torch.sqrt(alpha_t)
            if clip_denoised:
                x0_pred = torch.clamp(x0_pred, -1.0, 1.0)

            # ── 计算各条件原始梯度 ────────────────────────────────────
            raw_grads = []   # [(name, grad, lambda)]
            for (cname, fn), lam in zip(forward_fns, lambdas):
                if lam <= 0:
                    continue
                loss = guidance_result_to_loss(fn(x0_pred))
                if loss.requires_grad:
                    g = torch.autograd.grad(loss, x_t, retain_graph=True,
                                            allow_unused=True)[0]
                    if g is not None:
                        raw_grads.append((cname, g, lam))
                    else:
                        print(f"  [warn] {cname} 梯度为 None")
                else:
                    print(f"  [warn] {cname} loss 不需要 grad，梯度路径断裂")

            # ── 去冲突：按优先级 Gram-Schmidt 正交投影 ──────────────────
            # forward_fns 顺序即优先级（首个=最高优先级，梯度完整保留）
            # 后续条件去掉所有更高优先级条件的梯度分量
            deconflict = self._deconflict_mode
            ortho_grads = []   # 已正交化的梯度
            for idx, (cname, g, lam) in enumerate(raw_grads):
                g_orth = g.clone()
                if deconflict in ("priority", "pcgrad"):
                    # 去掉所有更高优先级梯度的分量
                    for _, g_high, _ in ortho_grads:
                        if g_high.flatten().norm() > 1e-8:
                            proj = (g_orth.flatten() * g_high.flatten()).sum() \
                                   / (g_high.flatten().norm() ** 2)
                            g_orth = g_orth - proj * g_high
                ortho_grads.append((cname, g_orth, lam))

            # ── 加权求和（归一化）──────────────────────────────────────
            grad_total = torch.zeros_like(x_t)
            for (cname, g_orth, lam) in ortho_grads:
                g_norm = g_orth / (g_orth.flatten(1).norm(dim=1).mean().clamp(min=1e-8) + 1e-8)
                grad_total = grad_total + lam * g_norm

            # ── DDIM 更新（no_grad，不用梯度）+ 梯度校正 ──
            with torch.no_grad():
                eps_step = model(sample_img, t, labels, ones)
                if w_base > 0:
                    eps_un2 = model(sample_img, t, labels, zeros)
                    eps_step = (1 + w_base) * eps_step - w_base * eps_un2
                pred_x0 = (sample_img - torch.sqrt(1 - alpha_t) * eps_step) / torch.sqrt(alpha_t)
                if clip_denoised:
                    pred_x0 = torch.clamp(pred_x0, -1.0, 1.0)
                x_prev = (torch.sqrt(alpha_t_prev) * pred_x0
                          + torch.sqrt(1 - alpha_t_prev) * eps_step)
                x_prev = x_prev - guidance_eta * ts_scale * grad_total.detach()

            sample_img = x_prev

        return sample_img.detach().cpu().numpy()

    # ── Hybrid CFG+UG DDIM（score-based + gradient-based）──────────────
    # 结合 per-physics CFG（score 引导 SS+VF）和 Universal Guidance（梯度补强 VF）
    # ε = per_physics_CFG + η·grad_vf_deconflicted
    def ddim_sample_hybrid(
        self, model, labels,
        physics_slices,             # {name: (start,end)} for per-physics CFG
        not_ss_fn,                  # 可微前向: not_ss_fn(x0_pred) → SS 预测
        target_vf,                  # 目标 VF（标量）
        target_ss,                  # 目标 SS（tensor, 用于 SS 梯度，可选）
        w_base=6.0, w_vf=6.0,       # per-physics CFG 权重
        lam_vf_grad=1.0,            # UG VF 梯度权重
        lam_ss_grad=0.0,            # UG SS 梯度权重（0=靠CFG管SS）
        guidance_eta=0.1,           # 梯度强度
        image_shape=None,
        ddim_timesteps=50,
        clip_denoised=True,
        grad_schedule="late",
        tau_vf=0.05,
        sdf_inv_fn=None,             # 归一化 SDF -> 物理 SDF（VF 必须在物理域计算）
    ):
        if image_shape is None:
            image_shape = self.img_shape
        c = self.timesteps // ddim_timesteps
        ddim_ts = np.asarray(list(range(0, self.timesteps, c))) + 1
        ddim_ts_prev = np.append(np.array([0]), ddim_ts[:-1])
        device = next(model.parameters()).device
        labels = labels.to(device)
        B = labels.shape[0]
        sample_img = torch.randn((B, *image_shape), device=device)
        ones = torch.ones(B, dtype=torch.int32, device=device)
        zeros = torch.zeros(B, dtype=torch.int32, device=device)

        # 预构造 no_vf 条件
        vf_slice = physics_slices.get("vf")
        c_no_vf = labels.clone()
        if vf_slice:
            c_no_vf[:, vf_slice[0]:vf_slice[1]] = 0.0

        target_vf_t = torch.full((B,), target_vf, device=device, dtype=torch.float32)

        for i in tqdm(reversed(range(ddim_timesteps)), desc="hybrid", total=ddim_timesteps):
            t = torch.full((B,), ddim_ts[i], device=device, dtype=torch.long)
            pt = torch.full((B,), ddim_ts_prev[i], device=device, dtype=torch.long)
            a_t = self._extract(self.alphas_cumprod, t, sample_img.shape)
            a_t_prev = self._extract(self.alphas_cumprod, pt, sample_img.shape)

            # 时间步缩放
            progress = (ddim_timesteps - 1 - i) / max(ddim_timesteps - 1, 1)
            ts_scale = {"none":1.0, "linear":progress,
                        "late":max(0.0,(progress-0.5)*2)}[grad_schedule]

            # ── 梯度路径（需要 grad）──
            if lam_vf_grad > 0 and ts_scale > 0:
                x_t = sample_img.detach().clone().requires_grad_(True)
                eps_g = model(x_t, t, labels, ones)
                x0_g = (x_t - torch.sqrt(1-a_t)*eps_g) / torch.sqrt(a_t)
                if clip_denoised: x0_g = torch.clamp(x0_g, -1, 1)
                # VF 梯度（软可微）
                sdf_for_vf = sdf_inv_fn(x0_g) if sdf_inv_fn is not None else x0_g
                sdf_flat = sdf_for_vf.flatten(1)
                vf_pred = torch.sigmoid(-sdf_flat / tau_vf).mean(dim=1)
                loss_vf = ((vf_pred - target_vf_t) ** 2).mean()
                grad_vf = torch.autograd.grad(loss_vf, x_t, allow_unused=True)[0]
                if grad_vf is not None:
                    grad_vf = grad_vf / (grad_vf.flatten(1).norm(dim=1).mean().clamp(min=1e-8)+1e-8)
                else:
                    grad_vf = torch.zeros_like(x_t)
                # SS 梯度（可选）
                if lam_ss_grad > 0 and target_ss is not None:
                    ss_pred = not_ss_fn(x0_g)
                    loss_ss = ((ss_pred - target_ss) ** 2).mean()
                    grad_ss = torch.autograd.grad(loss_ss, x_t, retain_graph=True, allow_unused=True)[0]
                    if grad_ss is not None:
                        # 去冲突：VF 梯度去掉 SS 分量
                        if grad_ss.flatten().norm() > 1e-8:
                            proj = (grad_vf.flatten() * grad_ss.flatten()).sum() / (grad_ss.flatten().norm()**2)
                            grad_vf = grad_vf - proj * grad_ss
                        grad_ss = grad_ss / (grad_ss.flatten(1).norm(dim=1).mean().clamp(min=1e-8)+1e-8)
                        grad_total = lam_vf_grad * grad_vf + lam_ss_grad * grad_ss
                    else:
                        grad_total = lam_vf_grad * grad_vf
                else:
                    grad_total = lam_vf_grad * grad_vf
            else:
                grad_total = torch.zeros_like(sample_img)

            # ── per-physics CFG（no_grad，score-based）──
            with torch.no_grad():
                eps_full = model(sample_img, t, labels, ones)
                eps_uncond = model(sample_img, t, labels, zeros)
                eps = (1+w_base)*eps_full - w_base*eps_uncond
                if w_vf > 0 and vf_slice:
                    eps_no_vf = model(sample_img, t, c_no_vf, ones)
                    eps = eps + w_vf * (eps_full - eps_no_vf)
                pred_x0 = (sample_img - torch.sqrt(1-a_t)*eps) / torch.sqrt(a_t)
                if clip_denoised: pred_x0 = torch.clamp(pred_x0, -1, 1)
                x_prev = torch.sqrt(a_t_prev)*pred_x0 + torch.sqrt(1-a_t_prev)*eps
                x_prev = x_prev - guidance_eta * ts_scale * grad_total.detach()
            sample_img = x_prev

        return sample_img.detach().cpu().numpy()

    # compute train losses
    def train_losses(self, model, x_start, t, c, mask_c):
        # generate random noise
        noise = torch.randn_like(x_start)
        # get x_t
        x_t = self.q_sample(x_start, t, noise=noise)
        predicted_noise = model(x_t, t, c, mask_c)
        loss = nnF.mse_loss(noise, predicted_noise)
        return loss
