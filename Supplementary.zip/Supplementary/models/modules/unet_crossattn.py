"""Cross-Attention U-Net 变体：SS 曲线作为 token 序列，image 特征做 cross-attention

与原 UNetTimeStep 区别：
- 原版：SS(51) → MLP → label_emb 向量 → 通道拼接注入（每像素同条件）
- 本版：SS(51) → 51 个 token 序列 → decoder cross-attention（image query SS tokens）
  让不同空间位置关注 SS 曲线不同段（孔隙关注大应变，实体关注弹性段）

兼容接口：forward(x, timesteps, c, mask)，mask=0 时 SS tokens 置零（CFG）
"""
import torch
import torch.nn as nn
from .UNets import (UNet, ResidualBlockConvTimeStep, MultiAttentionBlock,
                    DownSample, UpSample, norm_layer, timestep_embedding)


class CrossAttentionBlock(nn.Module):
    """Image features (Q) attend to SS tokens (K, V)."""

    def __init__(self, channels, ss_tokens, num_heads=1, groups=None):
        super().__init__()
        self.num_heads = num_heads
        self.norm = norm_layer(channels, groups)
        self.q = nn.Conv2d(channels, channels, kernel_size=1, bias=False)
        self.norm_kv = nn.LayerNorm(ss_tokens.shape[-1])
        self.k = nn.Linear(ss_tokens.shape[-1], channels)
        self.v = nn.Linear(ss_tokens.shape[-1], channels)
        self.proj = nn.Conv2d(channels, channels, kernel_size=1)

    def forward(self, x, ss_tokens):
        B, C, H, W = x.shape
        q = self.q(self.norm(x))                         # (B, C, H, W)
        # Q from image (HW tokens), K/V from SS (51 tokens)
        q = q.reshape(B, C, H * W).transpose(1, 2)        # (B, HW, C)
        q = q.reshape(B, H * W, self.num_heads, C // self.num_heads).transpose(1, 2)  # (B, heads, HW, C//heads)
        k = self.k(self.norm_kv(ss_tokens))              # (B, 51, C)
        v = self.v(self.norm_kv(ss_tokens))              # (B, 51, C)
        k = k.reshape(B, 51, self.num_heads, C // self.num_heads).transpose(1, 2)  # (B, heads, 51, C//heads)
        v = v.reshape(B, 51, self.num_heads, C // self.num_heads).transpose(1, 2)  # (B, heads, 51, C//heads)
        scale = (C // self.num_heads) ** -0.5
        attn = (q @ k.transpose(-2, -1)) * scale          # (B, heads, HW, 51)
        attn = attn.softmax(dim=-1)
        h = attn @ v                                      # (B, heads, HW, C//heads)
        h = h.transpose(1, 2).reshape(B, H * W, C).transpose(1, 2).reshape(B, C, H, W)
        h = self.proj(h)
        return h + x


class SS_TokenEncoder(nn.Module):
    """SS 曲线 (B, 51) → (B, 51, embed_dim) token 序列。

    编码方式：NeRF 位置编码（min_deg=0, max_deg=15），
    分别对 strain（独立变量）和 stress（因变量）进行多频正弦编码后拼接投影。
    """

    def __init__(self, ss_dim=51, embed_dim=64, min_deg=0, max_deg=15):
        super().__init__()
        # NeRF 位置编码：1D 输入 → (1 + 2*(max_deg-min_deg+1)) 维
        # 例：min=0, max=15 → 1+2*16=33 维
        in_dim = 1 + 2 * (max_deg - min_deg + 1)
        self.strain_enc = nn.Linear(in_dim, embed_dim)   # NeRF 编码后的 strain
        self.stress_enc = nn.Linear(in_dim, embed_dim)  # NeRF 编码后的 stress
        self.combine = nn.Linear(embed_dim * 2, embed_dim)
        # NeRF 频率
        scales = 2 ** torch.arange(min_deg, max_deg + 1, dtype=torch.float32)
        self.register_buffer("scales", scales)  # (16,)
        # strain 轴固定（0~0.2, 51 点）
        strain = torch.linspace(0, 0.2, ss_dim).reshape(-1, 1)  # (51,1)
        self.register_buffer("strain_axis", strain)

    def forward(self, ss):
        # ss: (B, 51)
        B = ss.shape[0]
        # 扩展到 (B, 51, 1)
        strain = self.strain_axis.unsqueeze(0).expand(B, -1, -1)  # (B, 51, 1)
        stress = ss.unsqueeze(-1)                          # (B, 51, 1)
        # NeRF 多频正弦编码
        strain_pe = self._nerf_encode(strain)              # (B, 51, 33)
        stress_pe = self._nerf_encode(stress)              # (B, 51, 33)
        # 分别投影到 embed_dim 后拼接合并
        tok = self.combine(torch.cat([
            self.strain_enc(strain_pe),   # (B, 51, embed_dim)
            self.stress_enc(stress_pe),  # (B, 51, embed_dim)
        ], dim=-1))                                        # → (B, 51, embed_dim)
        return tok

    def _nerf_encode(self, x):
        """NeRF 多频正弦位置编码（Mildenhall et al. 2020）。

        x: (..., 1) → output: (..., 1 + 2*L) where L = max_deg - min_deg + 1
        output = [x, sin(2^0*π*x), cos(2^0*π*x), ..., sin(2^L-1*π*x), cos(2^L-1*π*x)]
        """
        scaled = (2 * torch.pi) * x * self.scales          # (..., L)
        sin_feat = torch.sin(scaled)
        cos_feat = torch.cos(scaled)
        pe = torch.cat([sin_feat, cos_feat], dim=-1)        # (..., 2L)
        return torch.cat([x, pe], dim=-1)                  # (..., 1+2L)


class UNetTimeStepCrossAttn(nn.Module):
    """UNetTimeStep + SS cross-attention（decoder 各层加 cross-attn to SS tokens）。

    兼容 UNetTimeStep 接口：forward(x, timesteps, c, mask)。
    c = [SS(51) | VF×8 | EA×8 | ...]，前 51 维是 SS 曲线。
    """

    def __init__(self, img_shape, label_dim, one_hot,
                 first_conv_channels, channel_mutipliers, has_attention,
                 num_heads=4, num_res_blocks=1, norm_groups=None,
                 interpolation="nearest", activation_fn=nn.SiLU(), dropout=None,
                 cross_attn_embed=64, **kwargs):
        super().__init__()
        channel_in, img_size = img_shape[0], img_shape[1]
        channel_list = [first_conv_channels * m for m in channel_mutipliers]
        if has_attention is None:
            has_attention = [False] * len(channel_list)

        self.ss_dim = 51   # SS 曲线维度（固定，前 label_dim 的前 51 维）
        # SS token encoder
        self.ss_encoder = SS_TokenEncoder(ss_dim=self.ss_dim, embed_dim=cross_attn_embed)

        self.first_conv_channels = first_conv_channels
        time_emb_dim = first_conv_channels * 4
        self.time_emb = nn.Sequential(
            nn.Linear(first_conv_channels, time_emb_dim), nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim))
        label_emb_dim = first_conv_channels
        # label_emb 仍用（处理 VF/EA 等标量 + SS 残余），但 SS 另走 cross-attn
        self.label_emb = nn.Sequential(
            nn.Linear(label_dim, 2 * label_emb_dim), activation_fn,
            nn.Linear(2 * label_emb_dim, 2 * label_emb_dim), activation_fn,
            nn.Linear(2 * label_emb_dim, 2 * label_emb_dim), activation_fn,
            nn.Linear(2 * label_emb_dim, label_emb_dim))
        self.first_conv = nn.Conv2d(channel_in, first_conv_channels, 3, padding=1)

        # encoder（同 UNetTimeStep，但无 attention 在 encoder；attention 移到 cross-attn）
        self.encoder = nn.ModuleList()
        self.skip_channels = []
        encoder_skip_idx = []
        for i in range(len(channel_list)):
            in_ch = first_conv_channels if i == 0 else channel_list[i - 1]
            self.encoder.append(ResidualBlockConvTimeStep(
                in_ch, channel_list[i], time_emb_dim, label_emb_dim,
                groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            self.skip_channels.append(channel_list[i])
            encoder_skip_idx.append(len(self.encoder) - 1)
            for _ in range(1, num_res_blocks):
                self.encoder.append(ResidualBlockConvTimeStep(
                    channel_list[i], channel_list[i], time_emb_dim, label_emb_dim,
                    groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                self.skip_channels.append(channel_list[i])
                encoder_skip_idx.append(len(self.encoder) - 1)
            if i != len(channel_list) - 1:
                self.encoder.append(DownSample(channel_list[i]))
        self.encoder_skip = torch.zeros(len(self.encoder), dtype=bool)
        self.encoder_skip[encoder_skip_idx] = True

        # bottleneck + cross-attn
        self.bottleneck = nn.ModuleList([
            ResidualBlockConvTimeStep(channel_list[-1], channel_list[-1],
                                       time_emb_dim, label_emb_dim,
                                       groups=norm_groups, activation_fn=activation_fn, dropout=dropout),
            MultiAttentionBlock(channel_list[-1], num_heads=num_heads, groups=norm_groups),
            # cross-attn to SS tokens at bottleneck
            CrossAttentionBlock(channel_list[-1], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                                num_heads=num_heads, groups=norm_groups),
            ResidualBlockConvTimeStep(channel_list[-1], channel_list[-1],
                                       time_emb_dim, label_emb_dim,
                                       groups=norm_groups, activation_fn=activation_fn, dropout=dropout),
        ])

        # decoder（同 UNetTimeStep，但每个有 attention 的层加 cross-attn）
        self.decoder = nn.ModuleList()
        decoder_skip_idx = []
        for i in reversed(range(len(channel_list))):
            in_ch = channel_list[-1] + self.skip_channels.pop() if i == len(channel_list) - 1 \
                    else channel_list[i + 1] + self.skip_channels.pop()
            self.decoder.append(ResidualBlockConvTimeStep(
                in_ch, channel_list[i], time_emb_dim, label_emb_dim,
                groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            decoder_skip_idx.append(len(self.decoder) - 1)
            if has_attention[i]:
                self.decoder.append(MultiAttentionBlock(channel_list[i], num_heads=num_heads, groups=norm_groups))
                # 加 cross-attn to SS
                self.decoder.append(CrossAttentionBlock(
                    channel_list[i], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                    num_heads=num_heads, groups=norm_groups))
            for _ in range(1, num_res_blocks):
                in_ch = channel_list[i] + self.skip_channels.pop()
                self.decoder.append(ResidualBlockConvTimeStep(
                    in_ch, channel_list[i], time_emb_dim, label_emb_dim,
                    groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                decoder_skip_idx.append(len(self.decoder) - 1)
                if has_attention[i]:
                    self.decoder.append(MultiAttentionBlock(channel_list[i], num_heads=num_heads, groups=norm_groups))
                    self.decoder.append(CrossAttentionBlock(
                        channel_list[i], ss_tokens=torch.zeros(1, self.ss_dim, cross_attn_embed),
                        num_heads=num_heads, groups=norm_groups))
            if i != 0:
                self.decoder.append(UpSample(channel_list[i], interpolation=interpolation))
        self.decoder_skip = torch.zeros(len(self.decoder), dtype=bool)
        self.decoder_skip[decoder_skip_idx] = True

        self.out = nn.Sequential(
            norm_layer(channel_list[0], norm_groups), nn.SiLU(),
            nn.Conv2d(channel_list[0], channel_in, kernel_size=3, padding=1))

    def forward(self, x, timesteps, c, mask):
        B = x.shape[0]
        # SS tokens（前 51 维），mask=0 时置零（CFG）
        ss_curve = c[:, :self.ss_dim]                       # (B, 51)
        ss_tokens = self.ss_encoder(ss_curve) * mask[:, None, None]  # (B, 51, embed)

        # 关键修复：SS 只走 cross-attn，label_emb 只收 VF/EA（避免双重注入）
        # 将 SS 部分置零，label_emb 只看到 VF/EA 标量条件
        c_no_ss = c.clone()
        c_no_ss[:, :self.ss_dim] = 0.0                      # SS 部分清零

        skips = []
        x = self.first_conv(x)
        t_emb = self.time_emb(timestep_embedding(timesteps, embed_dim=self.first_conv_channels))
        c_emb = self.label_emb(c_no_ss) * mask[:, None]      # 只 VF/EA，mask=0 时全清零

        for eskip, layer in zip(self.encoder_skip, self.encoder):
            x = layer(x, t_emb, c_emb, mask) if isinstance(layer, ResidualBlockConvTimeStep) else layer(x)
            if eskip:
                skips.append(x)

        for layer in self.bottleneck:
            if isinstance(layer, ResidualBlockConvTimeStep):
                x = layer(x, t_emb, c_emb, mask)
            elif isinstance(layer, CrossAttentionBlock):
                x = layer(x, ss_tokens)
            else:
                x = layer(x)

        for dskip, layer in zip(self.decoder_skip, self.decoder):
            if dskip:
                x = torch.cat([x, skips.pop()], dim=1)
            if isinstance(layer, ResidualBlockConvTimeStep):
                x = layer(x, t_emb, c_emb, mask)
            elif isinstance(layer, CrossAttentionBlock):
                x = layer(x, ss_tokens)
            else:
                x = layer(x)

        return self.out(x)
