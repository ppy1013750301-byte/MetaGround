"""UNetTimeStep + VF FiLM（无 crossattn，保持原始 SS 注入方式）。

concat+film：SS 走 label_emb concat（与原 UNetTimeStep 相同），VF 走 FiLM 标量调制。
用于 VF 注入方式消融：与 concat+concat(baseline) 对比，只改 VF 注入方式。
"""
import torch
import torch.nn as nn
from .unet_blocks import (ResidualBlockConvTimeStep, MultiAttentionBlock,
                    DownSample, UpSample, norm_layer, timestep_embedding)


class FiLMModulation(nn.Module):
    """VF → (scale, shift) per channel, modulates after GroupNorm (zero-init)."""
    def __init__(self, channels_in, channels_out):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(channels_in, channels_in), nn.SiLU(),
            nn.Linear(channels_in, 2 * channels_out),  # 2*C = scale + shift
        )
        nn.init.zeros_(self.proj[-1].weight)
        nn.init.zeros_(self.proj[-1].bias)

    def forward(self, h, vf_emb):
        """h: (B,C,H,W)  vf_emb: (B, C_in) → modulated h"""
        params = self.proj(vf_emb)
        scale, shift = params.chunk(2, dim=-1)
        return h * (1 + scale[:, :, None, None]) + shift[:, :, None, None]


class FiLMResBlock(nn.Module):
    """ResBlock with time(channel-concat) + VF(FiLM modulation)."""
    def __init__(self, channel_in, channel_out, time_channels, vf_emb_dim,
                 groups=8, activation_fn=nn.SiLU(), dropout=None):
        super().__init__()
        lay1 = [norm_layer(channel_in, groups), activation_fn]
        if dropout is not None: lay1.append(nn.Dropout(dropout))
        lay1.append(nn.Conv2d(channel_in, channel_out, 3, padding="same"))
        self.conv1 = nn.Sequential(*lay1)
        self.time_emb = nn.Sequential(activation_fn, nn.Linear(time_channels, channel_out))
        self.film = FiLMModulation(vf_emb_dim, channel_out)
        lay2 = [norm_layer(channel_out, groups), activation_fn]
        if dropout is not None: lay2.append(nn.Dropout(dropout))
        lay2.append(nn.Conv2d(channel_out, channel_out, 3, padding="same"))
        self.conv2 = nn.Sequential(*lay2)
        self.shortcut = nn.Conv2d(channel_in, channel_out, 1) if channel_in != channel_out else nn.Identity()

    def forward(self, x, t_emb, vf_emb):
        h = self.conv1(x)
        h = h + self.time_emb(t_emb)[:, :, None, None]
        h = self.film(h, vf_emb)
        return self.conv2(h) + self.shortcut(x)


class UNetTimeStepFiLM(nn.Module):
    """plain U-Net + VF FiLM（SS 走 label_emb，VF 走 FiLM，无 CrossAttn）。"""

    def __init__(self, img_shape, label_dim, one_hot,
                 first_conv_channels, channel_mutipliers, has_attention,
                 num_heads=4, num_res_blocks=1, norm_groups=None,
                 interpolation="nearest", activation_fn=nn.SiLU(), dropout=None,
                 ss_dim=51, vf_dim=8, **kwargs):
        super().__init__()
        self.ss_dim = ss_dim; self.vf_dim = vf_dim
        channels_in, img_size = img_shape[0], img_shape[1]
        clist = [first_conv_channels * m for m in channel_mutipliers]
        if has_attention is None: has_attention = [False] * len(clist)

        self.first_conv_channels = first_conv_channels
        time_emb_dim = first_conv_channels * 4
        self.time_emb = nn.Sequential(
            nn.Linear(first_conv_channels, time_emb_dim), nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim))
        # VF embedder
        self.vf_encoder = nn.Sequential(
            nn.Linear(vf_dim, first_conv_channels), nn.SiLU(),
            nn.Linear(first_conv_channels, first_conv_channels))
        # label_emb for SS only（VF 走 FiLM）
        self.label_emb = nn.Sequential(
            nn.Linear(ss_dim, 2 * first_conv_channels), activation_fn,
            nn.Linear(2 * first_conv_channels, 2 * first_conv_channels), activation_fn,
            nn.Linear(2 * first_conv_channels, 2 * first_conv_channels), activation_fn,
            nn.Linear(2 * first_conv_channels, first_conv_channels))
        self.first_conv = nn.Conv2d(channels_in + first_conv_channels, first_conv_channels, 3, padding=1)

        self.encoder = nn.ModuleList(); self.skip_channels = []
        encoder_skip_idx = []
        for i in range(len(clist)):
            in_ch = first_conv_channels if i == 0 else clist[i - 1]
            self.encoder.append(FiLMResBlock(in_ch, clist[i], time_emb_dim, first_conv_channels,
                                              groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            self.skip_channels.append(clist[i]); encoder_skip_idx.append(len(self.encoder) - 1)
            for _ in range(1, num_res_blocks):
                self.encoder.append(FiLMResBlock(clist[i], clist[i], time_emb_dim, first_conv_channels,
                                                  groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                self.skip_channels.append(clist[i]); encoder_skip_idx.append(len(self.encoder) - 1)
            if i != len(clist) - 1:
                self.encoder.append(DownSample(clist[i]))
        self.encoder_skip = torch.zeros(len(self.encoder), dtype=bool)
        self.encoder_skip[encoder_skip_idx] = True

        self.bottleneck = nn.ModuleList([
            FiLMResBlock(clist[-1], clist[-1], time_emb_dim, first_conv_channels,
                         groups=norm_groups, activation_fn=activation_fn, dropout=dropout),
            MultiAttentionBlock(clist[-1], num_heads=num_heads, groups=norm_groups),
            FiLMResBlock(clist[-1], clist[-1], time_emb_dim, first_conv_channels,
                         groups=norm_groups, activation_fn=activation_fn, dropout=dropout),
        ])

        self.decoder = nn.ModuleList(); decoder_skip_idx = []
        for i in reversed(range(len(clist))):
            in_ch = clist[-1] + self.skip_channels.pop() if i == len(clist) - 1 else clist[i + 1] + self.skip_channels.pop()
            self.decoder.append(FiLMResBlock(in_ch, clist[i], time_emb_dim, first_conv_channels,
                                              groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
            decoder_skip_idx.append(len(self.decoder) - 1)
            if has_attention[i]:
                self.decoder.append(MultiAttentionBlock(clist[i], num_heads=num_heads, groups=norm_groups))
            for _ in range(1, num_res_blocks):
                in_ch = clist[i] + self.skip_channels.pop()
                self.decoder.append(FiLMResBlock(in_ch, clist[i], time_emb_dim, first_conv_channels,
                                                  groups=norm_groups, activation_fn=activation_fn, dropout=dropout))
                decoder_skip_idx.append(len(self.decoder) - 1)
                if has_attention[i]:
                    self.decoder.append(MultiAttentionBlock(clist[i], num_heads=num_heads, groups=norm_groups))
            if i != 0:
                self.decoder.append(UpSample(clist[i], interpolation=interpolation))
        self.decoder_skip = torch.zeros(len(self.decoder), dtype=bool)
        self.decoder_skip[decoder_skip_idx] = True

        self.out = nn.Sequential(norm_layer(clist[0], norm_groups), nn.SiLU(),
                                 nn.Conv2d(clist[0], channels_in, 3, padding=1))

    def forward(self, x, timesteps, c, mask):
        B = x.shape[0]
        ss_curve = c[:, :self.ss_dim]
        vf_raw = c[:, self.ss_dim:self.ss_dim + self.vf_dim]
        vf_emb = self.vf_encoder(vf_raw)
        vf_emb = vf_emb * mask[:, None]  # mask=0 → vf_emb=0 (FiLM identity w/ zero-init)
        label = self.label_emb(ss_curve) * mask[:, None]
        x = torch.cat([x, label[:, :, None, None].expand(-1, -1, *x.shape[2:])], dim=1)
        x = self.first_conv(x)
        t_emb = self.time_emb(timestep_embedding(timesteps, embed_dim=self.first_conv_channels))
        skips = []
        for eskip, layer in zip(self.encoder_skip, self.encoder):
            if isinstance(layer, FiLMResBlock):
                x = layer(x, t_emb, vf_emb)
            else:
                x = layer(x)
            if eskip: skips.append(x)
        for layer in self.bottleneck:
            x = layer(x, t_emb, vf_emb) if isinstance(layer, FiLMResBlock) else layer(x)
        for dskip, layer in zip(self.decoder_skip, self.decoder):
            if dskip: x = torch.cat([x, skips.pop()], dim=1)
            x = layer(x, t_emb, vf_emb) if isinstance(layer, FiLMResBlock) else layer(x)
        return self.out(x)
