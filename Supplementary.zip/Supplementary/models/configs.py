
# %%
import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import TensorDataset, DataLoader, Dataset
from typing import Union
import os
import pickle
import fcntl
import struct
import zipfile
from sklearn.model_selection import train_test_split
import time
# %%

script_path = os.path.dirname(os.path.abspath(__file__))

data_filebase = f"{script_path}/../data/PeriodUnitCell"

PADDING_VALUE = -1000
# %%


def _open_stored_npz_member(npz_path, member_name):
    """Memory-map an uncompressed ``.npy`` member inside an ``.npz`` file.

    ``sdf.npz`` stores its 4 GiB ``sdf.npy`` member with ZIP_STORED.  NumPy's
    normal ``np.load(npz)[name]`` still materializes the entire member in every
    DDP process.  Mapping the member payload directly keeps one shared page
    cache and makes rank startup independent of dataset size.
    """
    with zipfile.ZipFile(npz_path) as archive:
        info = archive.getinfo(member_name)
        if info.compress_type != zipfile.ZIP_STORED:
            raise ValueError(
                f"{member_name} in {npz_path} is compressed and cannot be memory-mapped"
            )
        local_header_offset = info.header_offset

    with open(npz_path, "rb") as handle:
        handle.seek(local_header_offset)
        header = handle.read(30)
        if len(header) != 30:
            raise ValueError(f"truncated ZIP local header: {npz_path}")
        fields = struct.unpack("<IHHHHHIIIHH", header)
        if fields[0] != 0x04034B50:
            raise ValueError(f"invalid ZIP local header: {npz_path}")
        filename_length, extra_length = fields[-2], fields[-1]
        member_offset = local_header_offset + 30 + filename_length + extra_length
        handle.seek(member_offset)
        version = np.lib.format.read_magic(handle)
        if version == (1, 0):
            shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(handle)
        elif version == (2, 0):
            shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(handle)
        else:
            shape, fortran_order, dtype = np.lib.format._read_array_header(
                handle, version
            )
        array_offset = handle.tell()

    return np.memmap(
        npz_path,
        dtype=dtype,
        mode="r",
        offset=array_offset,
        shape=shape,
        order="F" if fortran_order else "C",
    )


def _streaming_mean_std(array, indices=None, chunk_rows=256):
    """Compute scalar mean/std without materializing a multi-GiB subset."""
    count = 0
    mean = 0.0
    m2 = 0.0
    n_rows = len(array) if indices is None else len(indices)
    for start in range(0, n_rows, chunk_rows):
        if indices is None:
            block = np.asarray(array[start:start + chunk_rows], dtype=np.float32)
        else:
            block = np.asarray(
                array[np.asarray(indices[start:start + chunk_rows], dtype=np.int64)],
                dtype=np.float32,
            )
        block_count = block.size
        block_mean = float(block.mean(dtype=np.float64))
        block_var = float(block.var(dtype=np.float64))
        delta = block_mean - mean
        new_count = count + block_count
        mean += delta * block_count / new_count
        m2 += block_var * block_count + delta * delta * count * block_count / new_count
        count = new_count
    if count == 0:
        raise ValueError("cannot compute statistics from an empty array")
    return mean, float(np.sqrt(m2 / count))


def _cache_file_lock(lock_path):
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    handle = open(lock_path, "a+")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
    return handle


def _cached_sdf_stats(sdf, train_ids, split_mode, seed, test_size):
    cache_dir = os.path.join(data_filebase, "cache")
    test_tag = int(round(float(test_size) * 10000))
    cache_path = os.path.join(
        cache_dir, f"sdf_stats__{split_mode}__seed{seed}__test{test_tag}.npz"
    )
    lock = _cache_file_lock(cache_path + ".lock")
    try:
        if os.path.exists(cache_path):
            with np.load(cache_path) as cached:
                return float(cached["mean"]), float(cached["std"])
        stats_indices = train_ids if split_mode == "group" else None
        mean, std = _streaming_mean_std(sdf, stats_indices)
        tmp_path = cache_path + f".{os.getpid()}.tmp.npz"
        np.savez(tmp_path, mean=np.float64(mean), std=np.float64(std))
        os.replace(tmp_path, cache_path)
        return mean, std
    finally:
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        lock.close()


def _cached_volume_fraction(sdf, chunk_rows=256):
    cache_dir = os.path.join(data_filebase, "cache")
    cache_path = os.path.join(cache_dir, "vf_sdf_lt0_schema1.npy")
    lock = _cache_file_lock(cache_path + ".lock")
    try:
        if not os.path.exists(cache_path):
            tmp_path = cache_path + f".{os.getpid()}.tmp.npy"
            output = np.lib.format.open_memmap(
                tmp_path, mode="w+", dtype=np.float32, shape=(len(sdf),)
            )
            reduce_axes = tuple(range(1, sdf.ndim))
            for start in range(0, len(sdf), chunk_rows):
                block = np.asarray(sdf[start:start + chunk_rows])
                output[start:start + len(block)] = np.mean(block < 0, axis=reduce_axes)
            output.flush()
            del output
            os.replace(tmp_path, cache_path)
        return np.load(cache_path, mmap_mode="r")
    finally:
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        lock.close()


class IndexedNormalizedSDFDataset(Dataset):
    """Lazy normalized views over the shared SDF memory map."""

    def __init__(self, sdf, conditions, indices, sdf_shift, sdf_scale):
        self.sdf = sdf
        self.conditions = conditions
        self.indices = np.asarray(indices, dtype=np.int64)
        self.sdf_shift = np.float32(sdf_shift)
        self.sdf_scale = np.float32(sdf_scale)
        spatial_shape = tuple(sdf.shape[1:])
        if len(spatial_shape) == 1:
            side = int(round(np.sqrt(spatial_shape[0])))
            if side * side != spatial_shape[0]:
                raise ValueError(f"cannot infer square SDF shape from {spatial_shape}")
            spatial_shape = (side, side)
        self.spatial_shape = spatial_shape

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, item):
        source_index = int(self.indices[item])
        # The per-sample copy is intentional: training mutability stays local,
        # while the 4 GiB source remains shared by all ranks/workers.
        sdf = np.array(self.sdf[source_index], dtype=np.float32, copy=True)
        sdf = ((sdf - self.sdf_shift) / self.sdf_scale).reshape(
            1, *self.spatial_shape
        )
        condition = np.array(
            self.conditions[source_index], dtype=np.float32, copy=True
        )
        return torch.from_numpy(sdf), torch.from_numpy(condition)


def split_augmented_indices(n_samples, test_size=0.2, seed=420,
                            split_mode="sample", sample_ids=None):
    """Split augmented data either by row or by independent source geometry.

    ``sample`` exactly preserves the historical protocol.  ``group`` keeps all
    periodic translations sharing one ``sample_ids.npy`` source ID on the same
    side and is the required protocol for leakage-free paper results.
    """
    indices = np.arange(n_samples)
    if split_mode == "sample":
        return train_test_split(indices, test_size=test_size, random_state=seed)
    if split_mode != "group":
        raise ValueError("split_mode must be 'sample' or 'group'")

    if sample_ids is None:
        sample_ids_file = f"{data_filebase}/sample_ids.npy"
        sample_ids = np.load(sample_ids_file)
    sample_ids = np.asarray(sample_ids)
    if sample_ids.shape != (n_samples,):
        raise ValueError(
            f"sample_ids must have shape {(n_samples,)}, got {sample_ids.shape}"
        )
    unique_groups = np.unique(sample_ids)
    train_groups, test_groups = train_test_split(
        unique_groups, test_size=test_size, random_state=seed
    )
    train_ids = indices[np.isin(sample_ids, train_groups)]
    test_ids = indices[np.isin(sample_ids, test_groups)]
    if np.intersect1d(sample_ids[train_ids], sample_ids[test_ids]).size:
        raise RuntimeError("group split leaked source geometry IDs")
    return train_ids, test_ids


class ListDataset(Dataset):
    """for list of tensors"""

    def __init__(self, data: Union[list, tuple]):
        """
        args:
            data: list of data, each element is a list of tensors
            e.g. [(pc1, xyt1, S1), (pc2, xyt2, S2), ...]

        """
        self.data = data

    def __len__(self):
        return len(self.data[0])

    def __getitem__(self, idx):
        one_data = [d[idx] for d in self.data]
        return one_data
# %%


def LoadDataSS(test_size=0.2, seed=42, split_mode="sample"):
    SS_curve_file = f"{data_filebase}/SS_curve.npy"
    stress = np.load(SS_curve_file)
    sdf_file = f"{data_filebase}/sdf.npz"
    sdf = np.load(sdf_file)["sdf"]
    train_ids, test_ids = split_augmented_indices(
        len(sdf), test_size=test_size, seed=seed, split_mode=split_mode
    )
    stats_ids = train_ids if split_mode == "group" else slice(None)
    sdf_shift, sdf_scale = np.mean(sdf[stats_ids]), np.std(sdf[stats_ids])
    sdf_norm = (sdf - sdf_shift) / sdf_scale
    sdf_norm = sdf_norm.reshape(-1, 1, 120, 120)
    stress_shift, stress_scale = np.mean(stress[stats_ids]), np.std(stress[stats_ids])
    stress_norm = (stress - stress_shift) / stress_scale

    def s_inv_trans(y):
       return y * stress_scale + stress_shift

    def sdf_inv_trans(x):
        return (x * sdf_scale + sdf_shift)

    sdf_norm = torch.tensor(sdf_norm)
    stress_norm = torch.tensor(stress_norm)
    sdf_train, sdf_test = sdf_norm[train_ids], sdf_norm[test_ids]
    stress_train, stress_test = stress_norm[train_ids], stress_norm[test_ids]
    train_dataset = TensorDataset(
        sdf_train, stress_train)
    test_dataset = TensorDataset(sdf_test, stress_test)
    sdf_inv_scaler = sdf_inv_trans
    stress_inv_scaler = s_inv_trans

    strain = torch.tensor(np.linspace(0, 1, 51), dtype=torch.float32)

    return train_dataset, test_dataset, strain[:, None], sdf_inv_scaler, stress_inv_scaler


def NOTSS_configs():
    file_base = f"{script_path}/saved_weights/NOTSS"
    notss_args = {"img_shape": (1, 120, 120),
                  "channel_mutipliers": [1, 2, 4, 8],
                  "has_attention": [False, False, False, False],
                  "first_conv_channels": 8, "num_res_blocks": 1,
                  "norm_groups": 8, "dropout": None, "embed_dim": 64,
                  "cross_attn_layers": 2, "num_heads": 8, "in_channels": 1, "out_channels": 1,
                  "emd_version": "nerf"}

    args_all = {"model_args": notss_args, "filebase": file_base}
    return args_all


# %%
NUM_FRAMES = 26


def LoadSUScaler():
    scaler_file = f"{data_filebase}/SU_scalers_{NUM_FRAMES}fram.npz"

    scalers = np.load(scaler_file)
    su_shift, su_scaler = scalers["global_shift"], scalers["global_scale"]
    su_shift = torch.tensor(su_shift)[None, :]  # (1, 1,1,3)
    su_scaler = torch.tensor(su_scaler)[None, :]  # (1, 1, 1, 3)

    def SUInverse(x):
        su_sig = su_scaler.to(x.device)
        su_mu = su_shift.to(x.device)
        return x*su_sig+su_mu
    return SUInverse


def LoadDataSU(bs_train=32, bs_test=128, test_size=0.2, seed=42,
               padding_value=PADDING_VALUE, input_T=True, split_mode="sample"):
    start = time.time()

    scaler_file = f"{data_filebase}/SU_scalers_{NUM_FRAMES}fram.npz"
    su_scalers = np.load(scaler_file)
    su_shift, su_scaler = su_scalers["global_shift"], su_scalers["global_scale"]

    SU_file = f"{data_filebase}/mises_disp{NUM_FRAMES}fram.pkl"
    with open(SU_file, "rb") as f:
        SU = pickle.load(f)
    nodes_file = f"{data_filebase}/mesh_coords.pkl"
    with open(nodes_file, "rb") as f:
        nodes = pickle.load(f)

    sdf_file = f"{data_filebase}/sdf.npz"
    sdf = np.load(sdf_file)["sdf"]

    Nt = SU[0].shape[1]
    t = torch.tensor(np.linspace(0, 1, Nt, dtype=np.float32))  # t is strain
    t = t[None, :, None]  # (1, Nt, 1)

    SU = [torch.tensor((su-su_shift)/su_scaler) for su in SU]  # (Nb, N,Nt, 3)

    if input_T:
        xyt = [torch.cat((torch.tensor(x[:, None, :2]).repeat(
            1, Nt, 1), t.repeat(x.shape[0], 1, 1)), dim=-1) for x in nodes]  # (Nb, N, Nt, 3)
    else:
        xyt = [torch.tensor(x[:, :2]) for x in nodes]
    sdf = sdf.reshape(-1, 120 * 120)
    sdf_shift, sdf_scale = np.mean(sdf), np.std(sdf)
    sdf = (sdf - sdf_shift) / sdf_scale
    sdf = sdf.reshape(-1, 1, 120, 120)
    sdf = torch.tensor(sdf)

    train_ids, test_ids = split_augmented_indices(
        len(sdf), test_size=test_size, seed=seed, split_mode=split_mode
    )

    train_xyt = [xyt[i] for i in train_ids]
    test_xyt = [xyt[i] for i in test_ids]
    train_S = [SU[i] for i in train_ids]
    test_S = [SU[i] for i in test_ids]
    train_sdf = sdf[train_ids]
    test_sdf = sdf[test_ids]

    train_dataset = ListDataset(
        (train_sdf, train_xyt, train_S, torch.tensor(train_ids)))
    test_dataset = ListDataset(
        (test_sdf, test_xyt, test_S, torch.tensor(test_ids)))

    def pad_collate_fn(batch):
        # Extract sdf (same-length)
        sdf_batch = torch.stack([item[0] for item in batch])
        xyt_batch = [item[1]
                     for item in batch]  # Extract xyt (variable-length)
        SU = [item[2] for item in batch]  # Extract S (variable-length)
        sample_ids = torch.stack([item[3] for item in batch])
        # y_batch = torch.stack([item[1] for item in batch])  # Extract and stack y (fixed-length)
        # Pad sequences
        xyt_padded = pad_sequence(
            xyt_batch, batch_first=True, padding_value=padding_value)
        SU_padded = pad_sequence(SU, batch_first=True,
                                 padding_value=padding_value)
        return sdf_batch, xyt_padded, SU_padded, sample_ids

    train_dataloader = DataLoader(train_dataset, batch_size=bs_train, shuffle=True,
                                  collate_fn=pad_collate_fn)
    test_dataloader = DataLoader(test_dataset, batch_size=bs_test, shuffle=False,
                                 collate_fn=pad_collate_fn)
    su_shift = torch.tensor(su_shift)[None, :]  # (1, 1,1,3)
    su_scaler = torch.tensor(su_scaler)[None, :]  # (1, 1, 1, 3)

    def SUInverse(x):
        su_sig = su_scaler.to(x.device)
        su_mu = su_shift.to(x.device)
        return x*su_sig+su_mu

    def sdf_inv_trans(x):
        return (x * sdf_scale + sdf_shift)
    sdf_inv_scaler = sdf_inv_trans
    su_inv_scaler = SUInverse

    print(f"Data loading time: {time.time()-start:.2f} s")

    return train_dataloader, test_dataloader, sdf_inv_scaler, su_inv_scaler


def LoadCells():
    mesh_file = f"{data_filebase}/mesh_cells10K.pkl"
    with open(os.path.join(mesh_file), "rb") as f:
        cells = pickle.load(f)
    return cells


def NOTSU_configs(input_T=True):
    if input_T:
        file_base = f"{script_path}/saved_weights/NOTSU_inpT_test"
        notsu_args = {"img_shape": (1, 120, 120),
                      "channel_mutipliers": [1, 2, 4, 8],
                      "has_attention": [False, False, False, False],
                      "first_conv_channels": 8, "num_res_blocks": 1,
                      "norm_groups": 8, "dropout": None, "embed_dim": 64,
                      "cross_attn_layers": 2, "num_heads": 8, "in_channels": 3, "out_channels": 3,
                      "emd_version": "nerf",
                      "padding_value": PADDING_VALUE}
    else:
        # file_base = f"{script_path}/saved_weights/NOTSU_noinpT_frame_scaler_test"
        file_base = f"{script_path}/saved_weights/NOTSU"
        notsu_args = {"img_shape": (1, 120, 120),
                      "channel_mutipliers": [1, 2, 4, 8],
                      "has_attention": [False, False, False, False],
                      "first_conv_channels": 8, "num_res_blocks": 1,
                      "norm_groups": 8, "dropout": None, "embed_dim": 64,
                      "cross_attn_layers": 2, "num_heads": 8, "in_channels": 2, "out_channels": 3,
                      "emd_version": "nerf",
                      "padding_value": PADDING_VALUE, "num_frames": NUM_FRAMES}
    args_all = {"model_args": notsu_args, "filebase": file_base}
    return args_all


# %%


def LoadDataInv(test_size=0.2, seed=420, split_mode="sample"):
    SS_curve_file = f"{data_filebase}/SS_curve.npy"
    stress = np.load(SS_curve_file)
    sdf_file = f"{data_filebase}/sdf.npz"
    sdf = np.load(sdf_file)["sdf"]
    sdf = sdf.reshape(-1, 120 * 120)
    train_ids, test_ids = split_augmented_indices(
        len(sdf), test_size=test_size, seed=seed, split_mode=split_mode
    )
    stats_ids = train_ids if split_mode == "group" else slice(None)
    sdf_shift, sdf_scale = np.mean(sdf[stats_ids]), np.std(sdf[stats_ids])
    sdf_norm = (sdf - sdf_shift) / sdf_scale
    sdf_norm = sdf_norm.reshape(-1, 1, 120, 120)
    stress_shift, stress_scale = np.mean(stress[stats_ids]), np.std(stress[stats_ids])
    stress_norm = (stress - stress_shift) / stress_scale

    def s_inv_trans(y):
       return y * stress_scale + stress_shift

    def sdf_inv_trans(x):
        return (x * sdf_scale + sdf_shift)

    sdf_norm = torch.tensor(sdf_norm)
    stress_norm = torch.tensor(stress_norm)
    sdf_train, sdf_test = sdf_norm[train_ids], sdf_norm[test_ids]
    stress_train, stress_test = stress_norm[train_ids], stress_norm[test_ids]
    train_dataset = TensorDataset(
        sdf_train, stress_train)
    test_dataset = TensorDataset(sdf_test, stress_test)
    sdf_inv_scaler = sdf_inv_trans
    stress_inv_scaler = s_inv_trans

    return train_dataset, test_dataset, sdf_inv_scaler, stress_inv_scaler


_REPEAT = 8  # 标量属性维度增强倍数（SS 曲线每属性~51维，标量仅1维，需平衡）

def _make_features(stress, sdf_flat, physics: list, vf_repeat: int = 8, ea_repeat: int = 8,
                   extra: dict = None, stats_indices=None):
    """构建多物理条件。

    Parameters
    ----------
    stress    (N, 51) 归一化 SS 曲线
    sdf_flat  (N, 14400)  SDF 展开
    physics   ["ss"] | ["ss","vf"] | ["ss","ea"] | ["ss","vf","ea"]
    vf_repeat int     VF 重复次数（默认 8）
    ea_repeat int     EA 重复次数（默认 8）

    Returns
    -------
    cond_norm   (N, dim)  拼接后的条件
    cond_dim    int       总维度
    stats       dict      各属性统计信息
    """
    N = stress.shape[0]
    parts = []; dims = []; stats = {}
    strain = np.linspace(0, 0.2, 51, dtype=np.float32)
    extra = extra or {}
    stats_ref = slice(None) if stats_indices is None else stats_indices

    for prop in physics:
        if prop == "ss":
            parts.append(stress)
            dims.append(51)
            stats["SS"] = {"dim": 51}
        elif prop == "vf":
            if "vf" in extra:
                vf = np.asarray(extra["vf"], dtype=np.float32).reshape(-1, 1)
            else:
                vf = (sdf_flat < 0).astype(np.float32).mean(axis=1, keepdims=True)
            vf_shift, vf_scale = vf[stats_ref].mean(), vf[stats_ref].std()
            vf_norm = (vf - vf_shift) / vf_scale
            vf_rep  = np.repeat(vf_norm, vf_repeat, axis=1)
            parts.append(vf_rep)
            dims.append(vf_repeat)
            stats["VF"] = {"mean": float(vf_shift), "std": float(vf_scale),
                           "min": float(vf.min()), "max": float(vf.max())}
        elif prop == "ea":
            ea = np.trapz(stress, strain, axis=1)
            ea_shift, ea_scale = ea[stats_ref].mean(), ea[stats_ref].std()
            ea_norm = (ea - ea_shift) / ea_scale
            ea_rep  = np.tile(ea_norm[:, None], (1, ea_repeat))
            parts.append(ea_rep)
            dims.append(ea_repeat)
            stats["EA"] = {"mean": float(ea_shift), "std": float(ea_scale),
                           "min": float(ea.min()), "max": float(ea.max())}
        elif prop == "nu":
            # 泊松比 ν：从 poisson.npy 加载（需先跑自由侧面仿真，见 README_poisson_sim.md）
            # nu_vals 由 LoadDataInvMulti 通过 extra["nu"] 传入 _make_features
            nu = extra["nu"].reshape(-1, 1)  # (N, 1)
            nu_shift, nu_scale = nu[stats_ref].mean(), nu[stats_ref].std()
            nu_norm = (nu - nu_shift) / nu_scale
            nu_rep  = np.repeat(nu_norm, vf_repeat, axis=1)  # ×8，与 VF 同处理
            parts.append(nu_rep)
            dims.append(vf_repeat)
            stats["NU"] = {"mean": float(nu_shift), "std": float(nu_scale),
                           "min": float(nu.min()), "max": float(nu.max()),
                           "auxetic_frac": float((nu < 0).mean())}

    cond_norm = np.concatenate(parts, axis=1)
    return cond_norm.astype(np.float32), sum(dims), parts, dims, stats


def LoadDataInvMulti(test_size: float = 0.2, seed: int = 420, cond_type: str = "ss_vf",
                     vf_repeat: int = 8, ea_repeat: int = 8,
                     split_mode: str = "sample", lazy_sdf: bool = False):
    """多物理条件数据加载。

    cond_type   "ss" (SS, 51维) | "ss_vf" (SS+VF, 59维)
    """
    SS_curve_file = f"{data_filebase}/SS_curve.npy"
    sdf_file      = f"{data_filebase}/sdf.npz"

    stress = np.load(SS_curve_file).astype(np.float32)
    if lazy_sdf:
        sdf = _open_stored_npz_member(sdf_file, "sdf.npy")
    else:
        sdf = np.load(sdf_file)["sdf"].astype(np.float32)
    N      = stress.shape[0]
    sdf_flat = sdf.reshape(N, -1)

    train_ids, test_ids = split_augmented_indices(
        N, test_size=test_size, seed=seed, split_mode=split_mode
    )
    stats_ids = train_ids if split_mode == "group" else None
    stats_ref = slice(None) if stats_ids is None else stats_ids

    if lazy_sdf:
        sdf_shift, sdf_scale = _cached_sdf_stats(
            sdf, train_ids, split_mode, seed, test_size
        )
        sdf_norm = None
    else:
        sdf_shift, sdf_scale = sdf_flat[stats_ref].mean(), sdf_flat[stats_ref].std()
        sdf_norm = (sdf_flat - sdf_shift) / sdf_scale
        sdf_norm = sdf_norm.reshape(N, 1, 120, 120)

    stress_shift, stress_scale = stress[stats_ref].mean(), stress[stats_ref].std()
    stress_norm = (stress - stress_shift) / stress_scale

    # 解析 cond_type → 物理属性列表
    phys_list = {"ss": ["ss"], "ss_vf": ["ss","vf"]}
    physics = phys_list.get(cond_type, ["ss","vf"])

    # 若含 nu，加载 poisson.npy（需先跑自由侧面仿真，见 README_poisson_sim.md）
    extra = {}
    if lazy_sdf and "vf" in physics:
        extra["vf"] = _cached_volume_fraction(sdf)
    if "nu" in physics:
        nu_file = f"{data_filebase}/poisson.npy"
        if not os.path.exists(nu_file):
            raise FileNotFoundError(
                f"cond_type={cond_type} 需要泊松比数据 {nu_file}，但文件不存在。\n"
                f"请先按 data_script/abaqus/README_poisson_sim.md 跑自由侧面仿真并提取 ν。")
        nu_vals = np.load(nu_file).astype(np.float32)
        assert nu_vals.shape[0] == N, f"ν 样本数 {nu_vals.shape[0]} != SDF 样本数 {N}"
        extra["nu"] = nu_vals

    cond_norm, label_dim, parts, dims, stats = _make_features(
        stress_norm, sdf_flat, physics, vf_repeat=vf_repeat, ea_repeat=ea_repeat,
        extra=extra, stats_indices=stats_ids
    )

    total_d = sum(dims)
    print(f"[MultiPhysics] cond_type={cond_type}  physics={physics}  → condition: (N={N}, {total_d})")
    for k, v in stats.items():
        if "mean" in v:
            print(f"  {k}: {v}")

    if lazy_sdf:
        train_dataset = IndexedNormalizedSDFDataset(
            sdf, cond_norm, train_ids, sdf_shift, sdf_scale
        )
        test_dataset = IndexedNormalizedSDFDataset(
            sdf, cond_norm, test_ids, sdf_shift, sdf_scale
        )
        print(
            f"[lazy SDF] ZIP_STORED mmap enabled; train={len(train_dataset)}, "
            f"test={len(test_dataset)}"
        )
    else:
        sdf_t  = torch.tensor(sdf_norm)
        cond_t = torch.tensor(cond_norm)

        sdf_train, sdf_test = sdf_t[train_ids], sdf_t[test_ids]
        cond_train, cond_test = cond_t[train_ids], cond_t[test_ids]

        train_dataset = TensorDataset(sdf_train, cond_train)
        test_dataset  = TensorDataset(sdf_test,  cond_test)

    def sdf_inv_trans(x):
        return x * sdf_scale + sdf_shift

    def cond_inv_trans(c):
        offset = 0
        result = {}
        if "ss" in physics:
            result["ss"] = c[..., :51] * stress_scale + stress_shift
            offset += 51
        if "vf" in physics:
            result["vf"] = c[..., offset] * stats["VF"]["std"] + stats["VF"]["mean"]
            offset += vf_repeat
        if "ea" in physics:
            result["ea"] = c[..., offset] * stats["EA"]["std"] + stats["EA"]["mean"]
            offset += ea_repeat
        if "nu" in physics:
            result["nu"] = c[..., offset] * stats["NU"]["std"] + stats["NU"]["mean"]
            offset += vf_repeat
        return result

    if "vf" in physics:
        cond_inv_trans.vf_mean = float(stats["VF"]["mean"])
        cond_inv_trans.vf_std = float(stats["VF"]["std"])

    return train_dataset, test_dataset, sdf_inv_trans, cond_inv_trans


def INV_configs():
    """Inverse diffusion model — original U-Net backbone (author baseline).

    Returns a dict with keys:
      "model_args"  : forwarded to DiffusionInverseModelDefinition
      "filebase"    : directory for saved weights and logs
    The "backbone" key selects the noise-estimator architecture; "unet" loads
    the author-provided weights in saved_weights/inv_diffusion/.
    """
    channel_multpliers = [1, 2, 4, 8]
    fist_conv_channels = 16
    num_heads = 4
    norm_groups = 8
    num_res_blocks = 1
    total_timesteps = 500
    dropout = None

    inv_img_shape = (1, 120, 120)
    has_attention = [False, False, True, True]
    inv_diffusion_filebase = f"{script_path}/saved_weights/inv_diffusion"
    inv_diffusion_model_args = {
        "backbone": "unet",                          # selects UNetTimeStep
        "img_shape": inv_img_shape,
        "channel_multpliers": channel_multpliers,
        "has_attention": has_attention,
        "fist_conv_channels": fist_conv_channels,
        "num_heads": num_heads, "norm_groups": norm_groups,
        "num_res_blocks": num_res_blocks,
        "total_timesteps": total_timesteps, "dropout": dropout,
    }
    inv_diffusion_args = {
        "model_args": inv_diffusion_model_args, "filebase": inv_diffusion_filebase}

    return inv_diffusion_args


