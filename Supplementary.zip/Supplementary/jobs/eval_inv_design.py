"""逆向设计质量评估脚本

对每个已训练的扩散模型：
  1. 从测试集随机取 n_test 条目标 SS 曲线
  2. 用 DDIM（默认 50 步）生成 n_samples 个 SDF 候选
  3. 过滤无效样本（固体区域不连通 / "孤岛"）
  4. 用固定的 NOT-SS（作者权重）预测每个候选的 SS 曲线
  5. 计算 best_L2 / top5_mean_err / mean_L2 / valid_rate / diversity
  6. 计算候选级与 target 级 SS+VF 联合达标率

输出
----
outputs/inv_eval/
  {run_tag}_ns{n_samples}_nt{n_test}_ddim{ddim_steps}_w{w}_{timestamp}.json  # 详细指标
  comparison_ns{n_samples}_nt{n_test}_{timestamp}.png                        # 对比图
  comparison_ns{n_samples}_nt{n_test}_{timestamp}.json                       # 汇总指标

用法
----
# 快速评估（~15 分钟，3 个模型）
CUDA_VISIBLE_DEVICES=3 python eval_inv_design.py --n_test 20 --n_samples 50

# 完整评估（~90 分钟）
CUDA_VISIBLE_DEVICES=3 python eval_inv_design.py --n_test 100 --n_samples 200

# 仅评估指定模型
CUDA_VISIBLE_DEVICES=3 python eval_inv_design.py \\
    --run_tags uvit_d128_L8_ss unet_ss --n_test 20 --n_samples 50
"""

import argparse
import json
import os
import sys
import time
import warnings
from datetime import datetime

import numpy as np
import torch
import torch.nn.functional as F
from skimage import measure

warnings.filterwarnings("ignore")
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS_DIR)

from models.configs import NOTSS_configs, LoadDataInv, LoadDataInvMulti
from utils.geometry_metrics import periodic_wall_thickness
from models.NOT_SS import LoadNOTModel
from models.inverse_diffusion_from_sdf import DiffusionInverseModelDefinition
from models.modules.diffusion import GaussianDiffusion

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

METRICS_SCHEMA_VERSION = 2
# 论文主口径：SS 使用反归一化曲线的相对 L2；VF 使用绝对体积分数误差。
# 5% SS 容差约为 NOT-SS 测试误差（2.62%）的两倍；2 个百分点 VF
# 容差能排除只回归数据均值的弱控制，同时对 120x120 像素离散足够宽松。
DEFAULT_SS_REL_TOL = 0.05
DEFAULT_VF_ABS_TOL = 0.02
LEGACY_VF_ABS_TOL = 0.05
# ── 已知模型目录（前缀匹配）─────────────────────────────────────────────────
WEIGHTS_BASE = os.path.join(THIS_DIR, "models", "saved_weights")


def _load_run_metadata(run_dir: str):
    """读取训练时固化的配置；旧实验没有该文件时返回 None。"""
    path = os.path.join(run_dir, "run_config.json")
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        metadata = json.load(f)
    if metadata.get("schema_version") != 1 or "eval_config" not in metadata:
        raise ValueError(f"不支持的运行元数据: {path}")
    return metadata

# ── 解析目录名→模型配置 ──────────────────────────────────────────────────────

def _resolve_dir(tag: str) -> str:
    """前缀匹配：找 saved_weights/ 下最新的同前缀目录。

    旧 run id 混用了 ``Review``/``review``。优先保持原有的精确、
    大小写敏感语义；只有找不到时才回退到大小写不敏感匹配。
    """
    supplied = os.path.abspath(os.path.expanduser(tag))
    if os.path.isdir(supplied):
        return supplied
    exact = os.path.join(WEIGHTS_BASE, tag)
    if os.path.isdir(exact):
        return exact
    entries = os.listdir(WEIGHTS_BASE)
    cands = sorted([d for d in entries if d.startswith(tag)], reverse=True)
    if cands:
        return os.path.join(WEIGHTS_BASE, cands[0])
    tag_folded = tag.casefold()
    cands = sorted(
        [d for d in entries if d.casefold().startswith(tag_folded)],
        reverse=True,
    )
    if cands:
        return os.path.join(WEIGHTS_BASE, cands[0])
    raise FileNotFoundError(f"找不到以 '{tag}' 开头的权重目录")


def _parse_config_from_tag(run_dir: str) -> dict:
    """从目录名反推模型配置。"""
    metadata = _load_run_metadata(run_dir)
    if metadata is not None:
        cfg = dict(metadata["eval_config"])
        cfg["train_args"] = dict(metadata.get("train_args", {}))
        resolution = int(cfg.get(
            "resolution", cfg.get("img_shape", (1, 120, 120))[1]))
        cfg["resolution"] = resolution
        cfg["img_shape"] = (1, resolution, resolution)
        return cfg

    tag = os.path.basename(run_dir)
    # cond_type 检测（先长后短）+ label_dim 映射
    if   "ss_vf_ea" in tag: cond_type, label_dim = "ss_vf_ea", 67
    elif "ss_vf"    in tag: cond_type, label_dim = "ss_vf",    59
    elif "ss_ea"    in tag: cond_type, label_dim = "ss_ea",    59
    else:                   cond_type, label_dim = "ss",       51
    # VF×N 消融：用正则提取数字，正确支持 VF4/VF8/VF16/VF24/VF32/VF40 等任意值
    # （旧代码 "VF4" in tag 会误匹配 "VF40"）
    if cond_type == "ss_vf":
        import re
        _m = re.search(r'(?:^|_)vf(\d+)(?:_|$)', tag, re.IGNORECASE)
        if _m:
            label_dim = 51 + int(_m.group(1))
    # 分辨率检测：新目录用 sdf{R}，旧目录可能只在 Review_SDF{R} 中记录。
    import re
    _res_match = re.search(r'(?:^|_)sdf(64|120|256)(?:_|$)', tag, re.IGNORECASE)
    resolution = int(_res_match.group(1)) if _res_match else 120

    # backbone 检测（先识别 concat+FiLM，避免旧 J2 被误判成 CrossAttn+FiLM）
    if   tag.startswith("uvit_adaln") or "adaLN" in tag or "SchemeB" in tag:
        backbone = "uvit_adaln"
    elif "raw_concat_film" in tag.lower() or "film_only" in tag.lower():
        backbone = "unet_film_only"
    elif "FiLM" in tag or "film" in tag:
        backbone = "unet_film"
    elif "CrossAttn" in tag or "crossattn" in tag:
        backbone = "unet_crossattn"
    elif tag.startswith("uvit"):
        backbone = "uvit"
    else:
        backbone = "unet"
    cfg = {"label_dim": label_dim, "cond_type": cond_type,
           "backbone": backbone, "total_timesteps": 500,
           "resolution": resolution,
           "img_shape": (1, resolution, resolution)}

    # U-ViT / adaLN 超参
    if backbone in ("uvit", "uvit_adaln"):
        import re
        m = re.search(r"d(\d+)_L(\d+)", tag)
        if m:
            cfg["embed_dim"] = int(m.group(1))
            cfg["depth"]     = int(m.group(2))
        else:
            cfg["embed_dim"], cfg["depth"] = 128, 8
        # Scheme A multi-MLP：目录含 multiMLP 或 SchemeA
        if "multiMLP" in tag or "SchemeA" in tag:
            _mc = {"ss_vf": {"ss":51,"vf":8}, "ss_ea": {"ss":51,"ea":8},
                   "ss_vf_ea": {"ss":51,"vf":8,"ea":8}}
            cfg["multi_cond_dims"] = _mc.get(cond_type)

    # U-Net 超参（从 INV_configs 读）
    else:
        from models.configs import INV_configs
        base = INV_configs()["model_args"]
        cfg.update({k: base[k] for k in
                    ["channel_multpliers","has_attention","fist_conv_channels",
                     "num_heads","norm_groups","num_res_blocks","dropout"]})

    return cfg


def load_diffusion_model(run_dir: str, target_device=None, checkpoint_path=None):
    """加载扩散模型（噪声估计器 + GaussianDiffusion）。"""
    resolved_device = torch.device(target_device) if target_device is not None else device
    cfg = _parse_config_from_tag(run_dir)
    ckpt = checkpoint_path or os.path.join(run_dir, "model.ckpt")
    model_cfg = {k: v for k, v in cfg.items() if k != "train_args"}
    noise_est, gauss_diff = DiffusionInverseModelDefinition(**model_cfg)
    state = torch.load(ckpt, map_location=resolved_device, weights_only=True)
    noise_est.load_state_dict(state)
    noise_est.to(resolved_device).eval()
    print(f"  [loaded] {os.path.basename(run_dir)}")
    return noise_est, gauss_diff, cfg


# ── 有效性过滤（连通性，考虑 x 方向周期性）────────────────────────────────────

def _is_connected_periodic(sdf_2d: np.ndarray, threshold: float = 0.0) -> bool:
    """固体（SDF < threshold）在 x 方向周期拼接后是否只有 1 个连通分量。"""
    solid = (sdf_2d < threshold)
    if not solid.any():
        return False                    # 全空，无效
    # 水平方向拼三份，让周期连通显现
    tiled = np.tile(solid, (1, 3))
    labeled = measure.label(tiled, connectivity=2)
    # 中心拷贝对应列 [W:2W]
    W = solid.shape[1]
    center_labels = set(labeled[:, W:2*W][solid].tolist())
    return len(center_labels) == 1


def filter_valid(sdf_batch_physical: np.ndarray) -> np.ndarray:
    """物理 SDF ``(B,1,H,W)`` → bool mask。

    输入必须已经反归一化，使物理相界面严格对应 ``SDF=0``。旧实现直接
    对归一化 SDF 使用阈值 0，会把本数据集的实体面积平均高估约 8.67 pp。
    """
    mask = np.array([
        _is_connected_periodic(sdf_batch_physical[i, 0], threshold=0.0)
        for i in range(len(sdf_batch_physical))
    ])
    return mask


def compute_vf_batch(sdf_batch_physical: np.ndarray) -> np.ndarray:
    """由物理 SDF ``(B,1,H,W)`` 返回逐候选 VF ``(B,)``。"""
    if sdf_batch_physical.ndim != 4 or sdf_batch_physical.shape[1] != 1:
        raise ValueError(
            f"expected physical SDF shape (B,1,H,W), got {sdf_batch_physical.shape}"
        )
    return (sdf_batch_physical[:, 0] < 0).mean(axis=(1, 2))


# ── DDIM 采样 ──────────────────────────────────────────────────────────────

@torch.no_grad()
def ddim_sample_batch(noise_est, gauss_diff: GaussianDiffusion,
                      labels: torch.Tensor, w: float, ddim_steps: int,
                      chunk: int = 50) -> np.ndarray:
    """分块 DDIM 采样，返回模型原生分辨率的 ``(B,1,H,W)`` numpy。"""
    B = labels.shape[0]
    result = []
    for i in range(0, B, chunk):
        lab = labels[i:i+chunk].to(device)
        sdf = gauss_diff.ddim_sample(noise_est, lab, ddim_timesteps=ddim_steps,
                                     w=w, clip_denoised=False)
        result.append(sdf)
    return np.concatenate(result, axis=0)


def resolve_sample_chunk(resolution: int, requested: int = 0) -> int:
    """Resolve the DDIM micro-batch size for a native SDF resolution.

    ``requested=0`` enables a conservative pixel-count based default.  The
    120x120 baseline keeps the historical chunk of 50, lower resolutions are
    capped at 50, and 256x256 uses 10 to fit commodity 24 GB GPUs.
    """
    resolution = int(resolution)
    requested = int(requested)
    if resolution <= 0:
        raise ValueError("resolution must be positive")
    if requested < 0:
        raise ValueError("sample_chunk must be zero (auto) or a positive integer")
    if requested > 0:
        return requested
    return min(50, max(1, int(50 * (120 / resolution) ** 2)))


def resize_sdf_batch(sdf_batch: np.ndarray, size: int = 120) -> np.ndarray:
    """将原生分辨率 SDF 统一到 NOT-SS 的 120×120 输入口径。"""
    if sdf_batch.shape[-2:] == (size, size):
        return sdf_batch
    sdf_t = torch.as_tensor(sdf_batch, dtype=torch.float32)
    return F.interpolate(
        sdf_t, size=(size, size), mode="bilinear", align_corners=True
    ).cpu().numpy()


# ── NOT-SS 评估 ────────────────────────────────────────────────────────────

@torch.no_grad()
def predict_ss(not_ss, sdf_batch: np.ndarray,
               strain: torch.Tensor, chunk: int = 256) -> np.ndarray:
    """(B,1,120,120) numpy → (B,51) numpy（归一化空间）。"""
    B = sdf_batch.shape[0]
    preds = []
    for i in range(0, B, chunk):
        sdf_t = torch.tensor(sdf_batch[i:i+chunk], dtype=torch.float32).to(device)
        p = not_ss(strain, sdf_t)
        preds.append(p.cpu().numpy())
    return np.concatenate(preds, axis=0)


def compute_metrics(ss_pred_norm: np.ndarray, ss_target_norm: np.ndarray,
                    sdf_batch: np.ndarray,
                    stress_inv, sdf_inv,
                    vf_pred: np.ndarray = None, vf_target: float = None,
                    n_samples_total: int = None,
                    ss_rel_tol: float = DEFAULT_SS_REL_TOL,
                    vf_abs_tol: float = DEFAULT_VF_ABS_TOL):
    """
    ss_pred_norm : (N_valid, 51)
    ss_target_norm: (51,) or (1, 51)
    sdf_batch    : (N_valid, 1, 120, 120)
    Returns dict of scalars.
    """
    # L2 相对误差（反归一化后计算，与论文一致）
    ss_pred = stress_inv(torch.tensor(ss_pred_norm)).numpy()
    ss_targ = stress_inv(torch.tensor(ss_target_norm)).numpy()
    l2_errors = np.linalg.norm(ss_pred - ss_targ, axis=-1) / (np.linalg.norm(ss_targ) + 1e-12)

    # SDF 多样性：生成样本间的平均 pairwise L2（采样最多 20 对避免爆内存）
    N = min(len(sdf_batch), 20)
    sdfs_flat = sdf_inv(torch.tensor(sdf_batch[:N, 0].reshape(N, -1))).numpy()
    if N > 1:
        pairs = [(i, j) for i in range(N) for j in range(i+1, N)]
        pw = [np.linalg.norm(sdfs_flat[i]-sdfs_flat[j]) for i, j in pairs]
        diversity = float(np.mean(pw))
    else:
        diversity = 0.0

    # 每个 target 内按误差升序取前 5 个有效候选，再求均值。若有效候选
    # 少于 5 个则使用全部有效候选；完全无有效候选由调用方记为 1.0。
    top5_count = min(5, len(l2_errors))
    top5_mean_err = float(np.partition(l2_errors, top5_count - 1)[:top5_count].mean())

    m = {
        "best_L2":    float(l2_errors.min()),
        "top5_mean_err": top5_mean_err,
        "mean_L2":    float(l2_errors.mean()),
        "std_L2":     float(l2_errors.std()),
        "pct10_L2":   float(np.percentile(l2_errors, 10)),
        "pct90_L2":   float(np.percentile(l2_errors, 90)),
        "diversity":  diversity,
        "n_valid":    int(len(ss_pred_norm)),
    }

    # 达标率的分母是全部生成候选，因此无效结构自动视为不达标。
    n_total = int(n_samples_total or len(l2_errors))
    ss_ok = l2_errors <= ss_rel_tol
    m["ss_candidate_success_rate"] = float(ss_ok.sum() / n_total)
    m["ss_target_success"] = bool(ss_ok.any())

    # VF 与联合达标指标（仅 ss_vf 模型）。vf_abs_err 采用逐候选 MAE，
    # 避免旧版 abs(mean(VF)-target) 中正负偏差相互抵消。
    if vf_pred is not None and vf_target is not None:
        vf_errors = np.abs(vf_pred - vf_target)
        vf_ok = vf_errors <= vf_abs_tol
        joint_ok = ss_ok & vf_ok
        legacy_joint_ok = ss_ok & (vf_errors <= LEGACY_VF_ABS_TOL)
        m.update({
            "vf_target": float(vf_target),
            "vf_abs_err": float(vf_errors.mean()),
            "vf_bias_abs": float(np.abs(vf_pred.mean() - vf_target)),
            "best_vf_abs_err": float(vf_errors.min()),
            "vf_candidate_success_rate": float(vf_ok.sum() / n_total),
            "vf_target_success": bool(vf_ok.any()),
            "joint_candidate_success_rate": float(joint_ok.sum() / n_total),
            "joint_target_success": bool(joint_ok.any()),
            "joint_candidate_success_rate_legacy_vf5pp":
                float(legacy_joint_ok.sum() / n_total),
            "joint_target_success_legacy_vf5pp": bool(legacy_joint_ok.any()),
            "best_feasible_L2": (
                float(l2_errors[vf_ok].min()) if vf_ok.any() else 1.0
            ),
        })

    return m, l2_errors


def prepare_vf_condition_for_inference(
    test_cond_norm: np.ndarray,
    cfg: dict,
    vf_repeat: int,
    vf_std: float,
) -> np.ndarray:
    """Build the model-specific VF condition without changing target SS.

    Plain A2/A3-ablation receives exact source VF.  The target-only LVF pilot
    receives source VF minus delta.  Source-relative LVF receives source VF
    and delta as two repeated blocks.
    """
    condition = np.asarray(test_cond_norm, dtype=np.float32)
    if condition.ndim != 2 or condition.shape[1] < 51 + vf_repeat:
        raise ValueError(
            f"unexpected SS+VF condition shape {condition.shape}; "
            f"vf_repeat={vf_repeat}"
        )
    train_args = cfg.get("train_args", {}) or {}
    source_relative = bool(
        train_args.get("source_relative_lvf", False)
        or cfg.get("vf_source_relative", False)
    )
    is_lvf = bool(train_args.get("lvf_aux", False)) or source_relative
    if not is_lvf:
        return condition[:, :51 + vf_repeat].copy()

    delta_vf = float(train_args.get("delta_vf", 0.05))
    delta_norm = np.full(
        (condition.shape[0], vf_repeat), delta_vf / float(vf_std),
        dtype=np.float32,
    )
    source_norm = condition[:, 51:51 + vf_repeat]
    if source_relative:
        return np.concatenate(
            [condition[:, :51], source_norm, delta_norm], axis=1
        ).astype(np.float32, copy=False)

    target_norm = source_norm - delta_norm
    result = condition[:, :51 + vf_repeat].copy()
    result[:, 51:51 + vf_repeat] = target_norm
    return result


# ── 主评估流程 ─────────────────────────────────────────────────────────────

def evaluate_one_model(run_dir: str, not_ss, strain,
                       test_ss_norm, test_sdf_norm,
                       stress_inv, sdf_inv,
                       n_samples: int, ddim_steps: int, w: float,
                       test_cond_norm=None,
                       vf_condition_std: float | None = None,
                       sampling_seed: int = 42,
                       target_indices=None,
                       ss_rel_tol: float = DEFAULT_SS_REL_TOL,
                       vf_abs_tol: float = DEFAULT_VF_ABS_TOL,
                       min_wall_fraction: float = 0.0,
                       record_wall_metrics: bool = False,
                       wall_audit_fractions=(4 / 120, 5 / 120, 6 / 120),
                       sample_chunk: int = 0,
                       save_candidate_metrics: bool = True):
    """
    test_ss_norm   : (n_test, 51) 归一化 SS 曲线
    test_sdf_norm  : (n_test, 1,120,120) 对应 SDF（用于计算真实 VF）
    test_cond_norm : (n_test, 52) 仅 ss_vf 模型使用；若 None 则根据 cond_type 构造
    """
    noise_est, gauss_diff, cfg = load_diffusion_model(run_dir)
    cond_type = cfg["cond_type"]
    if cond_type == "ss_vf" and test_cond_norm is not None:
        if vf_condition_std is None:
            raise ValueError("SS+VF inference requires VF normalization std")
        train_args = cfg.get("train_args", {}) or {}
        vf_repeat = int(train_args.get("vf_repeat", (test_cond_norm.shape[1] - 51)))
        test_cond_norm = prepare_vf_condition_for_inference(
            test_cond_norm, cfg, vf_repeat, vf_condition_std
        )
        print(f"   VF inference condition dim: {test_cond_norm.shape[1]}")
    is_lvf = bool((cfg.get("train_args", {}) or {}).get("lvf_aux", False))
    is_source_relative = bool(
        (cfg.get("train_args", {}) or {}).get("source_relative_lvf", False)
        or cfg.get("vf_source_relative", False)
    )
    delta_vf = float((cfg.get("train_args", {}) or {}).get("delta_vf", 0.05))
    generation_resolution = int(cfg.get("resolution", 120))
    resolved_sample_chunk = resolve_sample_chunk(
        generation_resolution, sample_chunk
    )
    print(f"   DDIM sample chunk: {resolved_sample_chunk} "
          f"(resolution={generation_resolution})")

    n_test = len(test_ss_norm)
    all_metrics = []

    ts = time.time()
    for i in range(n_test):
        # ── 构造条件 ──────────────────────────────────────────────────
        if cond_type != "ss" and test_cond_norm is not None:
            cond = test_cond_norm[i:i+1].repeat(n_samples, 0)   # (N, label_dim)
        else:
            cond = test_ss_norm[i:i+1].repeat(n_samples, 0)      # (N, 51)

        labels = torch.tensor(cond, dtype=torch.float32)

        # ── DDIM 采样 ───────────────────────────────────────────────
        sdf_cands = ddim_sample_batch(
            noise_est, gauss_diff, labels, w, ddim_steps,
            chunk=resolved_sample_chunk,
        )

        # ── 有效性过滤 ──────────────────────────────────────────────
        # 扩散模型输出和数据张量均位于归一化 SDF 空间；连通性与 VF 必须
        # 先回到物理 SDF 再以 0 为相界面。
        sdf_cands_physical = sdf_inv(torch.as_tensor(sdf_cands)).cpu().numpy()
        connectivity_mask = filter_valid(sdf_cands_physical)
        wall_min = wall_q05 = wall_median = None
        if record_wall_metrics or min_wall_fraction > 0:
            wall_metrics = [
                periodic_wall_thickness(candidate[0])
                for candidate in sdf_cands_physical
            ]
            wall_min = np.asarray(
                [metrics["min_physical"] for metrics in wall_metrics], dtype=np.float32
            )
            wall_q05 = np.asarray(
                [metrics["q05_physical"] for metrics in wall_metrics], dtype=np.float32
            )
            wall_median = np.asarray(
                [metrics["median_physical"] for metrics in wall_metrics], dtype=np.float32
            )
        if min_wall_fraction > 0:
            wall_ok = wall_q05 >= min_wall_fraction
            valid_mask = connectivity_mask & wall_ok
        else:
            wall_ok = np.ones_like(connectivity_mask, dtype=bool)
            valid_mask = connectivity_mask
        valid_rate = float(valid_mask.mean())
        sdf_valid_native = sdf_cands[valid_mask]

        vf_all, vf_targ = None, None
        if "vf" in cond_type:
            vf_all = compute_vf_batch(sdf_cands_physical)
            target_sdf_physical = sdf_inv(
                torch.as_tensor(test_sdf_norm[i])
            ).cpu().numpy()
            vf_source = float((target_sdf_physical[0] < 0).mean())
            vf_targ = vf_source - delta_vf if (is_lvf or is_source_relative) else vf_source

        if len(sdf_valid_native) == 0:
            empty = {
                "valid_rate": 0.0, "n_valid": 0,
                "connectivity_rate": float(connectivity_mask.mean()),
                "wall_candidate_success_rate": float(wall_ok.mean()),
                "best_L2": 1.0, "top5_mean_err": 1.0,
                "mean_L2": 1.0,
                "ss_candidate_success_rate": 0.0,
                "ss_target_success": False,
            }
            if vf_all is not None:
                empty.update({
                    "vf_source": vf_source,
                    "vf_target": vf_targ,
                    "vf_abs_err": 1.0,
                    "vf_bias_abs": 1.0,
                    "best_vf_abs_err": 1.0,
                    "vf_candidate_success_rate": 0.0,
                    "vf_target_success": False,
                    "joint_candidate_success_rate": 0.0,
                    "joint_target_success": False,
                    "joint_candidate_success_rate_legacy_vf5pp": 0.0,
                    "joint_target_success_legacy_vf5pp": False,
                    "best_feasible_L2": 1.0,
                })
            if wall_q05 is not None:
                empty.update({
                    "wall_min_fraction_mean": float(wall_min.mean()),
                    "wall_q05_fraction_mean": float(wall_q05.mean()),
                    "wall_median_fraction_mean": float(wall_median.mean()),
                    "wall_audit_candidate_success_rate": {
                        f"{float(threshold):.6f}": float((wall_q05 >= threshold).mean())
                        for threshold in wall_audit_fractions
                    },
                })
                empty["candidate_metrics"] = {
                    "valid": valid_mask.tolist(),
                    "connected": connectivity_mask.tolist(),
                    "wall_min_fraction": wall_min.tolist() if wall_min is not None else None,
                    "wall_q05_fraction": wall_q05.tolist() if wall_q05 is not None else None,
                    "wall_median_fraction": wall_median.tolist() if wall_median is not None else None,
                    "wall_ok": wall_ok.tolist() if wall_q05 is not None else None,
                    "ss_L2": [None] * n_samples,
                    "vf": vf_all.tolist() if vf_all is not None else None,
                    "vf_abs_err": (
                        np.abs(vf_all - vf_targ).tolist()
                        if vf_all is not None else None
                    ),                }
            all_metrics.append(empty)
            continue

        # ── NOT-SS 打分 ─────────────────────────────────────────────
        # NOT-SS 和 SDF inverse scaler 都按 120×120 训练；生成与连通性过滤
        # 保持模型原生分辨率，物理代理和 diversity 统一 resize 到 120。
        sdf_valid_eval = resize_sdf_batch(sdf_valid_native, size=120)
        ss_pred_norm = predict_ss(not_ss, sdf_valid_eval, strain)    # (n_valid, 51)

        # Local-risk proxy has its own group-train physical SDF scaler.  Never
        # feed it diffusion-normalized SDF values.
        risk_predictions = None
        risk_ok = None
        risk_limits = {}
        # 真实 VF（若含 vf 约束的模型，用于计算 VF 控制误差）
        vf_pred = vf_all[valid_mask] if vf_all is not None else None

        # ── 计算指标 ────────────────────────────────────────────────
        m, l2_errors = compute_metrics(
            ss_pred_norm, test_ss_norm[i], sdf_valid_eval, stress_inv, sdf_inv,
            vf_pred, vf_targ, n_samples_total=n_samples,
            ss_rel_tol=ss_rel_tol, vf_abs_tol=vf_abs_tol,
        )
        m["valid_rate"] = valid_rate
        m["connectivity_rate"] = float(connectivity_mask.mean())
        m["wall_candidate_success_rate"] = float(wall_ok.mean())
        if vf_all is not None:
            m["vf_source"] = vf_source
            m["vf_target"] = vf_targ
        if wall_q05 is not None:
            m.update({
                "wall_min_fraction_mean": float(wall_min.mean()),
                "wall_q05_fraction_mean": float(wall_q05.mean()),
                "wall_median_fraction_mean": float(wall_median.mean()),
                "wall_audit_candidate_success_rate": {
                    f"{float(threshold):.6f}": float((wall_q05 >= threshold).mean())
                    for threshold in wall_audit_fractions
                },
            })
        if save_candidate_metrics:
            ss_l2_all = [None] * n_samples
            for sample_idx, err in zip(np.flatnonzero(valid_mask), l2_errors):
                ss_l2_all[int(sample_idx)] = float(err)
            risk_candidate_metrics = None
            m["candidate_metrics"] = {
                "valid": valid_mask.tolist(),
                "connected": connectivity_mask.tolist(),
                "wall_min_fraction": wall_min.tolist() if wall_min is not None else None,
                "wall_q05_fraction": wall_q05.tolist() if wall_q05 is not None else None,
                "wall_median_fraction": wall_median.tolist() if wall_median is not None else None,
                "wall_ok": wall_ok.tolist() if wall_q05 is not None else None,
                "ss_L2": ss_l2_all,
                "vf": vf_all.tolist() if vf_all is not None else None,
                "vf_abs_err": (
                    np.abs(vf_all - vf_targ).tolist()
                    if vf_all is not None else None
                ),
            }
        all_metrics.append(m)

        if (i + 1) % 5 == 0 or (i + 1) == n_test:
            elapsed = time.time() - ts
            print(f"    [{i+1}/{n_test}] valid={valid_rate:.0%}  "
                  f"best_L2={m['best_L2']:.4f}  "
                  f"top5_mean_err={m['top5_mean_err']:.4f}  "
                  f"mean_L2={m['mean_L2']:.4f}  "
                  f"elapsed={elapsed:.0f}s")

    # ── 汇总 ──────────────────────────────────────────────────────────
    def agg(key):
        vals = [m[key] for m in all_metrics if key in m]
        return float(np.mean(vals)) if vals else float("nan")

    summary = {
        "metrics_schema_version": METRICS_SCHEMA_VERSION,
        "run_tag":     os.path.basename(run_dir),
        "sampling_seed": int(sampling_seed),
        "target_indices": (
            [int(x) for x in target_indices] if target_indices is not None else None
        ),
        "n_test":      n_test,
        "n_samples":   n_samples,
        "ddim_steps":  ddim_steps,
        "guidance_w":  w,
        "generation_resolution": generation_resolution,
        "physics_resolution": 120,
        "sample_chunk": resolved_sample_chunk,
        "thresholds": {
            "ss_relative_L2": float(ss_rel_tol),
            "vf_absolute_fraction": float(vf_abs_tol),
            "legacy_vf_absolute_fraction": LEGACY_VF_ABS_TOL,
            "validity": "single x-periodic connected solid component at physical SDF < 0",
            "min_wall_fraction": float(min_wall_fraction),
            "wall_metric": "5th percentile of x-periodic skeleton local diameters divided by cell width",
            "wall_audit_fractions": [float(value) for value in wall_audit_fractions],
        },
        "valid_rate":  agg("valid_rate"),
        "connectivity_rate": agg("connectivity_rate"),
        "wall_candidate_success_rate": agg("wall_candidate_success_rate"),
        "best_L2":     agg("best_L2"),
        "best_L2_mean": agg("best_L2"),
        "top5_mean_err": agg("top5_mean_err"),
        "mean_L2":     agg("mean_L2"),
        "std_L2":      agg("std_L2"),
        "pct10_L2":    agg("pct10_L2"),
        "pct90_L2":    agg("pct90_L2"),
        "diversity":   agg("diversity"),
        "ss_candidate_success_rate": agg("ss_candidate_success_rate"),
        "ss_target_success_rate": agg("ss_target_success"),
        "per_target":  all_metrics,
    }
    if any("wall_q05_fraction_mean" in metrics for metrics in all_metrics):
        summary.update({
            "wall_min_fraction_mean": agg("wall_min_fraction_mean"),
            "wall_q05_fraction_mean": agg("wall_q05_fraction_mean"),
            "wall_median_fraction_mean": agg("wall_median_fraction_mean"),
            "wall_audit_candidate_success_rate": {
                f"{float(threshold):.6f}": float(np.mean([
                    metrics["wall_audit_candidate_success_rate"][f"{float(threshold):.6f}"]
                    for metrics in all_metrics
                    if "wall_audit_candidate_success_rate" in metrics
                ]))
                for threshold in wall_audit_fractions
            },
        })
    if any("vf_abs_err" in m for m in all_metrics):
        summary.update({
            "vf_abs_err": agg("vf_abs_err"),
            "vf_bias_abs": agg("vf_bias_abs"),
            "best_vf_abs_err": agg("best_vf_abs_err"),
            "vf_candidate_success_rate": agg("vf_candidate_success_rate"),
            "vf_target_success_rate": agg("vf_target_success"),
            "joint_candidate_success_rate": agg("joint_candidate_success_rate"),
            "joint_target_success_rate": agg("joint_target_success"),
            "joint_candidate_success_rate_legacy_vf5pp":
                agg("joint_candidate_success_rate_legacy_vf5pp"),
            "joint_target_success_rate_legacy_vf5pp":
                agg("joint_target_success_legacy_vf5pp"),
            "best_feasible_L2": agg("best_feasible_L2"),
        })
    return summary


# ── 模型标签简化（用于 x 轴标签和文件名）──────────────────────────────────

def _short_tag(run_tag: str) -> str:
    """将完整 run_tag 转为简洁英文标签，供图表和文件名使用。
    例：uvit_d128_L8_ss_vf_bs512_lr...clip1_cos... → UViT-SS+VF(clip+cos)
    """
    base = run_tag.split("_bs")[0]   # 去掉 bs 及后续超参

    # 架构
    if base.startswith("uvit_d128_L8_"):
        arch = "UViT"
        rest = base[len("uvit_d128_L8_"):]
    elif base.startswith("unet_"):
        arch = "UNet"
        rest = base[len("unet_"):]
    else:
        return base    # 未知格式，原样返回

    # 条件类型
    parser.add_argument("--no_candidate_metrics", action="store_true",
                        help="不在 JSON 保存候选级 valid/SS/VF 数组")
    parser.add_argument("--output_json", default=None,
                        help="单模型评估的稳定 JSON 输出路径；用于可恢复的评估矩阵")
    parser.add_argument("--no_comparison", action="store_true",
                        help="单模型矩阵任务不额外生成 comparison JSON/PNG")
    parser.add_argument("--notss_dir", default=None,
                        help="group-split严格评估使用的NOT-SS目录；可为绝对路径或notss_group下的run_id")
    # 合并已有 JSON 并生成对比图（不重新采样）
    parser.add_argument("--compare_jsons", nargs="+", default=None,
                        help="直接传入已有的 JSON 文件路径列表，生成对比图（用于并行评估后合并）")
    args = parser.parse_args()

    if any(value <= 0 for value in args.wall_audit_fractions):
        parser.error("--wall_audit_fractions必须全部为正")
    if args.min_wall_fraction < 0:
        parser.error("--min_wall_fraction不能为负")

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    # 毫秒级时间戳避免多个并行评估在同一秒启动时覆盖 comparison 产物。
    # 单模型 JSON 虽由完整 run_tag 区分，但 comparison 过去只使用简写标签，
    # VF×N 并行任务都会落到同一个 ``UNet-SS+VF`` 文件名。
    ts = datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:-3]
    out_dir = os.path.join(THIS_DIR, "outputs", "inv_eval")
    os.makedirs(out_dir, exist_ok=True)

    # 比较图文件名中包含所有模型短标签
    model_ids = "_vs_".join(_short_tag(t) for t in args.run_tags[:4])
    suffix    = (f"ns{args.n_samples}_nt{args.n_test}_ddim{args.ddim_steps}_"
                 f"w{args.guidance_w:.0f}_seed{args.seed}_tseed{args.target_seed}_"
                 f"schema{METRICS_SCHEMA_VERSION}_{ts}")
    cmp_suffix = f"{model_ids}_{suffix}"

    # ── 仅合并已有 JSON 生成对比图 ─────────────────────────────────────
    if args.compare_jsons:
        summaries = []
        for p in args.compare_jsons:
            with open(p) as f:
                s = json.load(f)
            # 若 JSON 是列表（合并文件）则展开
            if isinstance(s, list):
                summaries.extend(s)
            else:
                summaries.append(s)
        model_ids = "_vs_".join(_short_tag(s["run_tag"]) for s in summaries[:4])
        cmp_png = os.path.join(out_dir, f"comparison__{model_ids}__{ts}.png")
        cmp_json= os.path.join(out_dir, f"comparison__{model_ids}__{ts}.json")
        plot_comparison(summaries, cmp_png)
        with open(cmp_json, "w") as f:
            json.dump(summaries, f, indent=2)
        print(f"\n汇总 JSON → {cmp_json}")
        print("── 汇总表格 ──────────────────────────────────────────")
        print(f"  {'模型':<45} {'valid%':>7} {'joint@K':>8} {'best_L2':>9} "
              f"{'top5_mean':>10} {'mean_L2':>9}")
        for s in summaries:
            tag_s = s["run_tag"].split("_bs")[0]
            top5 = s.get("top5_mean_err", float("nan"))
            joint = s.get("joint_target_success_rate", float("nan"))
            print(f"  {tag_s:<45} {s['valid_rate']:>7.1%} {joint:>8.1%} "
                  f"{s['best_L2']:>9.4f} {top5:>10.4f} {s['mean_L2']:>9.4f}")
        return

    print(f"\n{'='*60}")
    print(f"  逆向设计评估  {ts}")
    print(f"  n_test={args.n_test}  n_samples={args.n_samples}  "
          f"ddim_steps={args.ddim_steps}  w={args.guidance_w}  "
          f"sampling_seed={args.seed}  target_seed={args.target_seed}")
    print(f"  device: {device}")
    print(f"{'='*60}\n")

    # ── 加载 NOT-SS评委 ───────────────────────────────────────────────
    notss_cfg  = NOTSS_configs()
    legacy_not_ss = LoadNOTModel(notss_cfg["filebase"], notss_cfg["model_args"])
    strict_not_ss = None
    strict_notss_path = None
    if args.notss_dir:
        strict_notss_path = args.notss_dir
        if not os.path.isabs(strict_notss_path):
            strict_notss_path = os.path.join(
                WEIGHTS_BASE, "notss_group", strict_notss_path
            )
        if not os.path.isfile(os.path.join(strict_notss_path, "model.ckpt")):
            raise FileNotFoundError(
                f"group-split NOT-SS checkpoint不存在: {strict_notss_path}"
            )
        strict_not_ss = LoadNOTModel(strict_notss_path, notss_cfg["model_args"])
    strain_51  = torch.tensor(np.linspace(0, 1, 51), dtype=torch.float32)[:, None].to(device)

    # 数据按训练metadata选择历史sample split或严格group split。同一次比较
    # 不允许混合split，因为两者的测试目标集合和归一化统计不同。
    base_cache = {}
    multi_cache = {}
    def _get_base_data(split_mode):
        if split_mode not in base_cache:
            _, test_ds, sdf_inv, stress_inv = LoadDataInv(
                seed=420, split_mode=split_mode
            )
            target_rng = np.random.RandomState(args.target_seed)
            idxs = target_rng.choice(
                len(test_ds), size=min(args.n_test, len(test_ds)), replace=False
            )
            base_cache[split_mode] = {
                "idxs": idxs,
                "test_sdf_norm": test_ds.tensors[0][idxs].numpy(),
                "test_ss_norm": test_ds.tensors[1][idxs].numpy(),
                "sdf_inv": sdf_inv,
                "stress_inv": stress_inv,
                "n_avail": len(test_ds),
            }
        return base_cache[split_mode]

    # ── 逐模型评估 ────────────────────────────────────────────────────
    def _detect_cond_type(name):
        # 从目录名判断 cond_type（顺序重要：先长后短）
        if "ss_vf_ea" in name: return "ss_vf_ea"
        if "ss_vf" in name:    return "ss_vf"
        if "ss_ea" in name:    return "ss_ea"
        return "ss"

    def _detect_vf_repeat(name):
        """从目录名检测 VF×N 消融的 vf_repeat（默认 8）
        用正则提取数字，正确支持 VF4/VF8/VF16/VF24/VF32/VF40 等任意值
        （旧代码 "VF4" in name 会误匹配 "VF40"）"""
        import re
        _m = re.search(r'(?:^|_)vf(\d+)(?:_|$)', name, re.IGNORECASE)
        return int(_m.group(1)) if _m else 8

    all_summaries = []
    comparison_split_mode = None
    for tag in args.run_tags:
        print(f"── 评估: {tag} ──")
        run_dir = _resolve_dir(tag)
        print(f"   目录: {run_dir}")

        metadata = _load_run_metadata(run_dir)
        if metadata is not None:
            train_args = metadata.get("train_args", {})
            cond_type = train_args.get("cond_type", "ss")
            vf_repeat = int(train_args.get("vf_repeat", 8) or 8)
            split_mode = train_args.get("split_mode", "sample")
            print("   配置来源: run_config.json")
        else:
            cond_type = _detect_cond_type(os.path.basename(run_dir))
            vf_repeat = _detect_vf_repeat(os.path.basename(run_dir))
            split_mode = "sample"
            print("   配置来源: 旧目录名兼容解析")
        if comparison_split_mode is None:
            comparison_split_mode = split_mode
        elif comparison_split_mode != split_mode:
            raise ValueError(
                "同一次比较不能混合sample/group split；请分别评估后再明确分层汇总"
            )

        base_data = _get_base_data(split_mode)
        idxs = base_data["idxs"]
        test_sdf_norm = base_data["test_sdf_norm"]
        test_ss_norm = base_data["test_ss_norm"]
        sdf_inv = base_data["sdf_inv"]
        stress_inv = base_data["stress_inv"]
        if split_mode == "group":
            if strict_not_ss is None:
                raise ValueError(
                    "group-split模型必须通过--notss_dir指定严格NOT-SS评委，"
                    "禁止静默使用历史泄漏评委"
                )
            not_ss = strict_not_ss
            notss_used = strict_notss_path
        else:
            not_ss = legacy_not_ss
            notss_used = notss_cfg["filebase"]
        print(
            f"   split_mode={split_mode}  测试集={base_data['n_avail']} "
            f"本次目标={len(idxs)}  NOT-SS={notss_used}"
        )
        test_cond_norm = None
        if cond_type != "ss":
            # 按 vf_repeat 加载匹配维度的测试条件
            cache_key = f"{split_mode}_{cond_type}_{vf_repeat}"
            if cache_key not in multi_cache:
                _, tds, _, cinv = LoadDataInvMulti(
                    seed=420, cond_type=cond_type, vf_repeat=vf_repeat,
                    split_mode=split_mode,
                )
                multi_cache[cache_key] = (tds.tensors[1][idxs].numpy(), cinv)
            test_cond_norm, cond_inv = multi_cache[cache_key]
            print(f"   多物理条件: {cond_type} vf_repeat={vf_repeat} (dim={test_cond_norm.shape[1]})")
            vf_condition_std = float(getattr(cond_inv, "vf_std", 0.0))
            if vf_condition_std <= 0.0:
                raise ValueError("invalid VF normalization std in test condition inverse")
        else:
            vf_condition_std = None

        # 多模型同一进程评估时也为每个模型重置相同采样 RNG；旧实现只在程序
        # 开头设置一次，后续模型会接着消耗前一模型的随机流，破坏配对公平性。
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(args.seed)

        s = evaluate_one_model(
            run_dir, not_ss, strain_51,
            test_ss_norm, test_sdf_norm,
            stress_inv, sdf_inv,
            n_samples=args.n_samples,
            ddim_steps=args.ddim_steps,
            w=args.guidance_w,
            test_cond_norm=test_cond_norm,
            vf_condition_std=vf_condition_std,
            sampling_seed=args.seed,
            target_indices=idxs,
            ss_rel_tol=args.ss_rel_tol,
            vf_abs_tol=args.vf_abs_tol,
            min_wall_fraction=args.min_wall_fraction,
            record_wall_metrics=args.record_wall_metrics,
            wall_audit_fractions=args.wall_audit_fractions,
        )
        s["split_mode"] = split_mode
        s["notss_evaluator"] = notss_used
        s["target_seed"] = int(args.target_seed)
        all_summaries.append(s)

        # 保存单模型结果
        if args.output_json:
            model_out = os.path.abspath(args.output_json)
            os.makedirs(os.path.dirname(model_out), exist_ok=True)
        else:
            model_out = os.path.join(
                out_dir, f"{os.path.basename(run_dir)}__eval__{suffix}.json")
        with open(model_out, "w") as f:
            json.dump(s, f, indent=2)
        print(f"  → {model_out}")
        print(f"  valid={s['valid_rate']:.1%}  best_L2={s['best_L2']:.4f}  "
              f"top5_mean_err={s['top5_mean_err']:.4f}  "
              f"mean_L2={s['mean_L2']:.4f}  diversity={s['diversity']:.2f}\n")

    # ── 对比汇总 ─────────────────────────────────────────────────────
    cmp_json = None
    cmp_png = None
    if not args.no_comparison:
        cmp_json = os.path.join(out_dir, f"comparison__{cmp_suffix}.json")
        with open(cmp_json, "w") as f:
            json.dump(all_summaries, f, indent=2)

        cmp_png = os.path.join(out_dir, f"comparison__{cmp_suffix}.png")
        plot_comparison(all_summaries, cmp_png)

    # 打印汇总表格
    print("\n" + "="*80)
    print(f"  {'模型':<45} {'valid%':>7} {'joint@K':>8} {'best_L2':>9} "
          f"{'top5_mean':>10} {'mean_L2':>9} {'diversity':>10}")
    print("  " + "-"*80)
    for s in all_summaries:
        tag_short = s["run_tag"].split("_bs")[0]
        vf_info = f"  vf_err={s['vf_abs_err']:.4f}" if "vf_abs_err" in s else ""
        joint = s.get("joint_target_success_rate", float("nan"))
        print(f"  {tag_short:<45} {s['valid_rate']:>7.1%} {joint:>8.1%} {s['best_L2']:>9.4f} "
              f"{s['top5_mean_err']:>10.4f} {s['mean_L2']:>9.4f} "
              f"{s['diversity']:>10.3f}{vf_info}")
    print("="*80)
    if cmp_json is not None:
        print(f"\n汇总 JSON → {cmp_json}")
        print(f"对比图   → {cmp_png}")


if __name__ == "__main__":
    main()
