#!/usr/bin/env python3
"""B0-B3 inference under the frozen original-aligned protocol.

Full ancestral sampling, CFG w=1, 500 candidates, original periodic/no-island
filter, and legacy-NOT relative-L2 ranking.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch


MAIN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MAIN))

from jobs.eval_inv_design import load_diffusion_model, prepare_vf_condition_for_inference  # noqa: E402
from jobs.eval_inv_design import (  # noqa: E402
    _load_models,
    _load_scalers,
    _predict_not,
    _sample_batched,
    ramberg_osgood_target,
)
from models import NOT_SS, configs  # noqa: E402
from models.configs import LoadDataInvMulti, _open_stored_npz_member  # noqa: E402
from models.not_forward_proxy import NOTModelDefinition  # noqa: E402
from utils.sdf_geometry import filter_out_unit_cell  # noqa: E402


PROTOCOL_ID_B = "b0-b3-11-original-aligned-final-latest-v1"
PROTOCOL_ID_B_VF = "b0-b3-vf-sweep-r0-r10-r15-r20-v1"
MANIFEST = MAIN / "docs" / "a3_fixed_nine_target_manifest_v2.json"
LEGACY_NOT_DIR = MAIN / "models" / "saved_weights" / "NOTSS"

CHECKPOINTS = {
    "B0": MAIN / "models/saved_weights/b0-original-aligned-group-v1",
    "B1": MAIN / "models/saved_weights/b1-plain-vf16-group-v1",
    "B2": MAIN / "models/saved_weights/b2-crossattn-film-vf16-group-v1",
    "B3": MAIN / "models/saved_weights/b3-film-only-vf16-group-v1",
    "B0-D": MAIN / "models/saved_weights/b0-network-dropout01-v1",
    "B1-D": MAIN / "models/saved_weights/b1-network-dropout01-v1",
    "B2-D": MAIN / "models/saved_weights/b2-network-dropout01-v1",
    "B3-D": MAIN / "models/saved_weights/b3-network-dropout01-v1",
    "B1-PD": MAIN / "models/saved_weights/b1-perphysics-dropout01-v1",
    "B2-PD": MAIN / "models/saved_weights/b2-perphysics-dropout01-v1",
    "B3-PD": MAIN / "models/saved_weights/b3-perphysics-dropout01-v1",
    "B1-VFLOSS": MAIN / "models/saved_weights/b1-vfloss-group-v1",
    "B1-VFLOSS-w05": MAIN / "models/saved_weights/b1-vfloss-w05-group-v1",
    "B1-VFR4": MAIN / "models/saved_weights/vf-repeat-4-group-v1",
    "B1-VFR8": MAIN / "models/saved_weights/vf-repeat-8-group-v1",
}

SS_ONLY_ARMS = {"B0", "B0-D"}
LEGACY_SS_MODEL_ARMS = {"B0"}


# ---------------------------------------------------------------------------
# Shared condition / sampling utilities
# ---------------------------------------------------------------------------

def condition_scalers(condition: torch.Tensor, inverse) -> tuple[float, float, float, float]:
    width = int(condition.numel())
    zero = np.zeros((1, width), dtype=np.float32)
    ss_probe = zero.copy()
    ss_probe[:, :51] = 1.0
    vf_probe = zero.copy()
    vf_probe[:, 51:] = 1.0
    physical_zero = inverse(zero)
    physical_ss = inverse(ss_probe)
    physical_vf = inverse(vf_probe)
    ss_mean = float(np.asarray(physical_zero["ss"])[0, 0])
    ss_scale = float(np.asarray(physical_ss["ss"])[0, 0] - ss_mean)
    vf_mean = float(np.asarray(physical_zero["vf"]).reshape(-1)[0])
    vf_scale = float(np.asarray(physical_vf["vf"]).reshape(-1)[0] - vf_mean)
    if ss_scale <= 0 or vf_scale <= 0:
        raise ValueError("invalid condition normalization recovered from inverse")
    return ss_mean, ss_scale, vf_mean, vf_scale


def build_condition(
    template: torch.Tensor,
    inverse,
    target_curve: np.ndarray,
    vf: float,
    vf_repeat: int,
) -> torch.Tensor:
    curve = np.asarray(target_curve, dtype=np.float32)
    if curve.shape != (51,) or not np.all(np.isfinite(curve)):
        raise ValueError("target curve must contain 51 finite values")
    if template.ndim != 1 or template.numel() != 51 + vf_repeat:
        raise ValueError("template condition has unexpected width")
    ss_mean, ss_scale, vf_mean, vf_scale = condition_scalers(template, inverse)
    result = template.detach().clone().float()
    result[:51] = torch.from_numpy((curve - ss_mean) / ss_scale)
    result[51:51 + vf_repeat] = float((vf - vf_mean) / vf_scale)
    recovered = inverse(result.numpy()[None])
    if not np.allclose(np.asarray(recovered["ss"])[0], curve, atol=2e-5):
        raise RuntimeError("SS condition round-trip failed")
    if not np.isclose(float(np.asarray(recovered["vf"]).reshape(-1)[0]), vf, atol=2e-6):
        raise RuntimeError("VF condition round-trip failed")
    return result


@torch.no_grad()
def sample_batched(diffusion, model, labels, seed: int, batch_size: int) -> np.ndarray:
    torch.manual_seed(int(seed))
    np.random.seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))
    outputs = []
    for start in range(0, len(labels), batch_size):
        outputs.append(diffusion.sample(
            model,
            labels[start:start + batch_size],
            w=1,
            clip_denoised=False,
            timesteps=diffusion.timesteps,
        ))
    return np.concatenate(outputs, axis=0).astype(np.float32)


def prepare_condition(
    run_dir: Path,
    target_curve: np.ndarray,
    vf_base: float,
    device: torch.device,
):
    metadata = json.loads((run_dir / "run_config.json").read_text())
    train_args = metadata["train_args"]
    if train_args.get("cond_type") != "ss_vf" or train_args.get("split_mode") != "group":
        raise ValueError(f"run is not strict group-split SS+VF: {run_dir}")
    vf_repeat = int(train_args.get("vf_repeat", 16))
    _, test_dataset, sdf_inverse, condition_inverse = LoadDataInvMulti(
        seed=int(train_args.get("data_seed", 420)),
        cond_type="ss_vf",
        vf_repeat=vf_repeat,
        split_mode="group",
        lazy_sdf=True,
    )
    _, template = test_dataset[0]
    base = build_condition(
        template.detach().float(), condition_inverse, target_curve, vf_base, vf_repeat
    )
    _, _, _, vf_std = condition_scalers(template.detach().float(), condition_inverse)
    prepared = prepare_vf_condition_for_inference(
        base.numpy()[None], metadata, vf_repeat, vf_std
    )
    expected_width = int(metadata["eval_config"]["label_dim"])
    if prepared.shape != (1, expected_width):
        raise ValueError(
            f"condition shape {prepared.shape} does not match label_dim {expected_width}"
        )
    return torch.from_numpy(prepared[0]).to(device), metadata, sdf_inverse


# ---------------------------------------------------------------------------
# B0-B3 inference
# ---------------------------------------------------------------------------

def checkpoint_file(arm: str) -> Path:
    path = CHECKPOINTS[arm]
    if path.is_file():
        return path
    return path / "latest.ckpt"


def best_checkpoint_file(arm: str) -> Path:
    path = CHECKPOINTS[arm]
    return path if path.is_file() else path / "model.ckpt"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_sha256(value: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes(order="C")).hexdigest()


def load_manifest(path: Path = MANIFEST) -> dict:
    manifest = json.loads(path.read_text())
    allowed_protocols = {
        "b0-b3-vf-sweep-r0-r10-r15-r20-v1",
        "b0-b3-vf-stratified-sweep-r0-r10-r15-r20-v2",
    }
    if manifest.get("protocol_id") not in allowed_protocols:
        raise ValueError(f"unexpected target manifest: {path}")
    sampling = manifest["sampling"]
    num_candidates = sampling.get(
        "num_candidates_per_model_target",
        sampling.get("num_candidates"),
    )
    if num_candidates is None:
        raise ValueError(f"manifest has no candidate-count field: {path}")
    required = (
        sampling["sampler"] == "ancestral_full",
        int(sampling["timesteps"]) == 500,
        int(num_candidates) == 500,
        int(sampling["sample_batch"]) == 50,
        float(sampling["code_guidance_w"]) == 1.0,
    )
    if not all(required):
        raise ValueError("target manifest is not compatible with original-aligned-v1")
    return manifest


def find_target(manifest: dict, target_id: str) -> dict:
    rows = [row for row in manifest["targets"] if str(row["target_id"]) == str(target_id)]
    if len(rows) != 1:
        raise ValueError(f"target {target_id!r} appears {len(rows)} times")
    return dict(rows[0])


def load_target(target: dict) -> tuple[np.ndarray, np.ndarray | None, float]:
    target_id = str(target["target_id"])
    source_row = target.get("source_row")
    if source_row is None:
        parameters = {
            "E": 800.0 if target_id == "case1" else 1000.0,
            "sigma0": 30.0 if target_id == "case1" else 40.0,
            "alpha": 0.002,
            "n": 10,
            "idx_e": None if target_id == "case1" else 40,
        }
        return (
            ramberg_osgood_target(**parameters).astype(np.float32),
            None,
            float(target["vf_reference"]),
        )
    data_source = target.get("data_source", "period_unit_cell")
    if data_source == "new_test_v2":
        new_test_dir = MAIN / "outputs" / "d_base_new_test"
        ss = np.load(new_test_dir / "ss_curves_v2_merged.npy", mmap_mode="r")
        sdf_pkg = np.load(new_test_dir / "sdf_new_test_v2_merged.npz")
        curve = np.asarray(ss[int(source_row), :, 1], dtype=np.float32)
        source_geometry = np.asarray(sdf_pkg["sdf"][int(source_row)], dtype=np.float32).reshape(120, 120)
    else:
        stress = np.load(MAIN / "../PeriodUnitCell/SS_curve.npy", mmap_mode="r")
        sdf = _open_stored_npz_member(MAIN / "../PeriodUnitCell/sdf.npz", "sdf.npy")
        curve = np.asarray(stress[int(source_row)], dtype=np.float32)
        source_geometry = np.asarray(sdf[int(source_row)], dtype=np.float32)
    source_vf = float((source_geometry < 0).mean())
    if not np.isclose(source_vf, float(target["vf_source"]), atol=1e-10):
        raise ValueError(f"target {target_id} source VF mismatch")
    return curve, source_geometry, source_vf


def load_legacy_not(device: torch.device):
    not_cfg = configs.NOTSS_configs()
    model = NOT_SS.LoadNOTModel(str(LEGACY_NOT_DIR), not_cfg["model_args"])
    model.to(device).eval()
    return model


def load_arm(arm: str, device: torch.device):
    path = CHECKPOINTS[arm]
    if arm in LEGACY_SS_MODEL_ARMS:
        model, diffusion, _ = _load_models(
            device, checkpoint_path=checkpoint_file(arm)
        )
        return model, diffusion, {"backbone": "unet", "condition": "SS-only"}, checkpoint_file(arm)
    model, diffusion, model_config = load_diffusion_model(
        str(path), target_device=device, checkpoint_path=str(checkpoint_file(arm))
    )
    return model, diffusion, model_config, checkpoint_file(arm)


def build_labels(arm: str, target_curve: np.ndarray, vf_base: float, device: torch.device):
    if arm in SS_ONLY_ARMS:
        stress_shift, stress_scale, _, _ = _load_scalers()
        labels = torch.from_numpy(
            ((target_curve - stress_shift) / stress_scale).astype(np.float32)
        )[None].to(device)
        return labels, None
    condition, _, sdf_inverse = prepare_condition(
        CHECKPOINTS[arm], target_curve, vf_base, device
    )
    return condition[None], sdf_inverse


def scaler_audit(target_curve: np.ndarray, sdf_probe: np.ndarray) -> dict:
    stress_shift, stress_scale, sdf_shift, sdf_scale = _load_scalers()
    recovered_curve = ((target_curve - stress_shift) / stress_scale) * stress_scale + stress_shift
    recovered_sdf = ((sdf_probe - sdf_shift) / sdf_scale) * sdf_scale + sdf_shift
    return {
        "stress_shift": stress_shift,
        "stress_scale": stress_scale,
        "sdf_shift": sdf_shift,
        "sdf_scale": sdf_scale,
        "stress_roundtrip_max_abs": float(np.max(np.abs(recovered_curve - target_curve))),
        "sdf_roundtrip_max_abs": float(np.max(np.abs(recovered_sdf - sdf_probe))),
    }


@torch.no_grad()
def run_task(
    arm: str,
    target_id: str,
    output_prefix: Path,
    device_name: str | None = None,
    num_candidates: int = 500,
    sample_batch: int = 50,
    top_k: int = 4,
    reduction: float = 0.0,
    manifest_path: Path = MANIFEST,
) -> dict:
    if not 0.0 <= reduction <= 0.30:
        raise ValueError("reduction must be in [0, 0.30]")
    if arm not in CHECKPOINTS:
        raise ValueError(f"unsupported arm: {arm}")
    if num_candidates != 500 or sample_batch != 50 or top_k != 4:
        raise ValueError("original-aligned-v1 requires 500 candidates, batch 50, top-4")
    target = find_target(load_manifest(manifest_path), target_id)
    target_curve, source_geometry, vf_base = load_target(target)
    json_path = output_prefix.with_suffix(".json")
    npz_path = output_prefix.with_suffix(".npz")
    if json_path.exists() or npz_path.exists():
        raise FileExistsError(f"refusing to overwrite {output_prefix}")

    device = torch.device(device_name or ("cuda" if torch.cuda.is_available() else "cpu"))
    model, diffusion, model_config, checkpoint = load_arm(arm, device)
    requested_vf = float(vf_base * (1.0 - reduction))
    labels, sdf_inverse = build_labels(arm, target_curve, requested_vf, device)
    labels = labels.repeat(num_candidates, 1)
    if arm in SS_ONLY_ARMS:
        samples_normalized = _sample_batched(
            diffusion, model, labels, int(target["sampling_seed"]), device, sample_batch
        ).astype(np.float32)
        _, _, sdf_shift, sdf_scale = _load_scalers()
        samples_physical = (samples_normalized * sdf_scale + sdf_shift).astype(np.float32)
    else:
        samples_normalized = sample_batched(
            diffusion, model, labels, int(target["sampling_seed"]), sample_batch
        ).astype(np.float32)
        samples_physical = np.asarray(sdf_inverse(samples_normalized), dtype=np.float32)

    physical_2d = samples_physical[:, 0]
    _, periodic_raw = filter_out_unit_cell(physical_2d, no_isolated=True)
    periodic_ids = np.asarray(periodic_raw, dtype=np.int64)
    if len(periodic_ids) < top_k:
        raise RuntimeError(f"{arm}/{target_id}: only {len(periodic_ids)} periodic candidates")

    not_model = load_legacy_not(device)
    stress_shift, stress_scale, sdf_shift, sdf_scale = _load_scalers()
    predictions = _predict_not(
        not_model, physical_2d[periodic_ids], sdf_shift, sdf_scale, device, chunk=16
    )
    predictions_physical = predictions * stress_scale + stress_shift
    errors = np.linalg.norm(predictions_physical - target_curve[None], axis=1) / max(
        float(np.linalg.norm(target_curve)), 1e-12
    )
    local_order = np.argsort(errors, kind="stable")
    ranking_order = periodic_ids[local_order]
    candidate_hashes = [array_sha256(samples_physical[index]) for index in range(num_candidates)]
    top_rows = []
    for rank, local in enumerate(local_order[:top_k], 1):
        candidate_index = int(periodic_ids[local])
        achieved_vf = float((physical_2d[candidate_index] < 0).mean())
        top_rows.append({
            "rank": rank,
            "candidate_index": candidate_index,
            "candidate_sha256": candidate_hashes[candidate_index],
            "E_target_NOT": float(errors[local]),
            "achieved_vf": achieved_vf,
            "vf_base": vf_base,
            "vf_requested": requested_vf,
            "vf_reduction_requested": float(vf_base - requested_vf),
            "vf_delta_achieved_minus_base": achieved_vf - vf_base,
            "vf_delta_achieved_minus_requested": achieved_vf - requested_vf,
        })

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        npz_path,
        candidates=samples_normalized,
        candidates_physical=samples_physical,
        candidate_sha256=np.asarray(candidate_hashes),
        periodic_ids=periodic_ids,
        ranking_order=ranking_order,
        periodic_not_predictions=predictions_physical.astype(np.float32),
        periodic_not_errors=errors.astype(np.float32),
        target_curve=target_curve,
        source_geometry=(
            source_geometry.astype(np.float32)
            if source_geometry is not None else np.empty((0,), dtype=np.float32)
        ),
    )
    report = {
        "schema_version": 1,
        "protocol_id": PROTOCOL_ID_B_VF,
        "arm": arm,
        "target_id": str(target_id),
        "target_family": target["family"],
        "target_source_row": target.get("source_row"),
        "target_group_id": target.get("source_group_id"),
        "vf_semantics": "source-VF" if source_geometry is not None else "reference-VF",
        "vf_base": vf_base,
        "vf_requested": requested_vf,
        "vf_reduction_fraction_requested": float(reduction),
        "vf_condition_applied": bool(arm not in SS_ONLY_ARMS),
        "checkpoint": str(checkpoint.resolve()),
        "checkpoint_sha256": sha256(checkpoint),
        "checkpoint_role": "final_latest",
        "best_checkpoint": str(best_checkpoint_file(arm).resolve()),
        "best_checkpoint_sha256": sha256(best_checkpoint_file(arm)),
        "generator_config": model_config,
        "evaluator": {
            "checkpoint": str((LEGACY_NOT_DIR / "model.ckpt").resolve()),
            "checkpoint_sha256": sha256(LEGACY_NOT_DIR / "model.ckpt"),
            "scaler": scaler_audit(target_curve, samples_physical[0]),
        },
        "sampling": {
            "sampler": "ancestral_full",
            "timesteps": 500,
            "cfg_w": 1.0,
            "num_candidates": 500,
            "sample_batch": 50,
            "seed": int(target["sampling_seed"]),
            "paired_noise_key": f"{target_id}:seed-{target['sampling_seed']}:500x50",
        },
        "candidate_domain": "raw SDF; no periodic projection; no FEM-safe gate",
        "filter": "original periodic/no-island",
        "ranking_contract": "legacy NOT relative-L2 after periodic/no-island; VF not ranked",
        "periodic_no_island_count": int(len(periodic_ids)),
        "raw_periodic_yield": float(len(periodic_ids) / num_candidates),
        "candidate_pool_sha256": array_sha256(samples_physical),
        "top_k": top_rows,
        "files": {"npz": str(npz_path.resolve())},
    }
    json_path.write_text(json.dumps(report, indent=2) + "\n")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=sorted(CHECKPOINTS), required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--output_root", type=Path, required=True)
    parser.add_argument("--device")
    parser.add_argument("--manifest", type=Path, default=MANIFEST)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument("--reduction", type=float, default=0.0,
                        help="relative VF reduction r; requested VF=VF_base*(1-r)")
    args = parser.parse_args()
    reduction_tag = f"r{args.reduction:.2f}".replace(".", "p")
    prefix = args.output_root.resolve() / reduction_tag / args.arm.lower() / str(args.target)
    if args.resume and prefix.with_suffix(".json").exists() and prefix.with_suffix(".npz").exists():
        print(json.dumps({"status": "skipped_existing", "output_prefix": str(prefix)}, indent=2))
        return
    if args.dry_run:
        target = find_target(load_manifest(args.manifest), args.target)
        print(json.dumps({
            "status": "dry_run",
            "arm": args.arm,
            "target_id": args.target,
            "checkpoint": str(checkpoint_file(args.arm)),
            "target_family": target["family"],
            "sampling_seed": target["sampling_seed"],
            "reduction": args.reduction,
            "output_prefix": str(prefix),
        }, indent=2))
        return
    result = run_task(
        args.arm, args.target, prefix, args.device,
        reduction=args.reduction, manifest_path=args.manifest,
    )
    print(json.dumps({
        "arm": result["arm"],
        "target_id": result["target_id"],
        "periodic_no_island_count": result["periodic_no_island_count"],
        "top_k": result["top_k"],
    }, indent=2))


if __name__ == "__main__":
    main()
