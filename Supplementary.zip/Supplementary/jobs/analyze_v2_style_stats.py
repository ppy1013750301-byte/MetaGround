#!/usr/bin/env python3
"""V2 §11 口径统计（B0_B3_VF_SWEEP_V2_ANALYSIS.md §11 的排序与呈现方式）。

输入为 FEM light 结果的分析 CSV（analyze_b0_b3_vf_top4_fem_light.py 产物），
输出 A–H 八张表：
  A  E<=5% per-case pass rate (asym_0.02)
  B  E<=5% top4>=1 pass rate (asym_0.02)
  C  E_target-FEM mean (complete+valid)
  D  E<=10% per-case pass rate (asym_0.02)
  E  E<=10% top4>=1 pass rate (asym_0.02)
  F  VF 偏差方向 (E<=5% pass, r>0)
  G  E_NOT-FEM mean (complete+valid)
  H  总体排序 (按 E<=5% per-case 降序)

口径要点：
  - per-case 分母 = 该模型该档全部设计 case（failed/invalid 计为未通过）；
  - top4>=1 分母 = target x 档位 cell（per-cell 任一 rank 通过即计）；
  - VF 非对称容差（相对口径）：r>0 时 vf_reduction_ratio >= r - 0.02，r0 不设 VF 门；
    比率由 (vf_source - vf_achieved) / vf_source 重算，不信任 CSV 的绝对差值列；
  - E_FEM / E_NOT-FEM mean 仅在 complete+valid 子集上计算；
  - VF 方向（F 表）仅统计 E<=5% 达标且 r>0 的 case（V2 §11.6 口径）。

用法:
  python analyze_v2_style_stats.py <analysis.csv> [--clean] [--fill-skipped MANIFEST] [--title "..."]

--clean 仅保留 clean 3 targets（target 名含 q25_50 / q50_75 / q75_90）。
--fill-skipped 读取输入包 manifest.json 的 skipped cell 列表，为每个 skipped cell
  注入 4 个 not-run=not-pass 幽灵 case（分母按设计 272/target 口径统一）。
已用 panel-1 全量对拍 V2 §11 三处数值（B2 r15=79.2%、B1 TOTAL=34.7%、
B2-D VF 方向 n=44/88.6%）验证通过。
"""
import argparse
import csv
from collections import defaultdict

MODELS = ["B0", "B0-D", "B1", "B1-D", "B1-PD", "B1-VFLOSS", "B1-VFLOSS-w05",
          "B2", "B2-D", "B2-PD", "B3", "B3-D", "B3-PD"]
REDS = ["r0p00", "r0p10", "r0p15", "r0p20", "r0p25", "r0p30"]
RVAL = {"r0p00": 0.0, "r0p10": 0.10, "r0p15": 0.15, "r0p20": 0.20,
        "r0p25": 0.25, "r0p30": 0.30}
CLEAN_KEYS = ("q25_50", "q50_75", "q75_90")


def load(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def fl(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def prep(rows):
    out = []
    for r in rows:
        src, ach = fl(r['vf_source']), fl(r['vf_achieved'])
        ratio = (src - ach) / src if (src not in (None, 0) and ach is not None) else None
        out.append(dict(model=r['model'], target=r['target'], red=r['reduction'],
                        complete=(r['status'] == 'complete'),
                        valid=(r['validation_pass'] == 'True'),
                        E=fl(r['E_target_FEM']), EN=fl(r['E_NOT_FEM']), ratio=ratio))
    return out


def vf_ok(c):
    if c['red'] == 'r0p00':
        return True
    return c['ratio'] is not None and c['ratio'] >= RVAL[c['red']] - 0.02


def passes(c, thr):
    return (c['complete'] and c['valid'] and c['E'] is not None
            and c['E'] <= thr and vf_ok(c))


def fmt_rate(p, n):
    return f"{p}/{n}={p / n * 100:.1f}%" if n else "-"


def per_case_table(rows, thr, title):
    print(f"\n### {title}")
    hdr = "| model | r0 | r10 | r15 | r20 | r25 | r30 | TOTAL |"
    print(hdr)
    print("|---|" + "---|" * 7)
    for m in MODELS:
        cells, tp, tn = [], 0, 0
        for red in REDS:
            if m in ("B0", "B0-D") and red != "r0p00":
                cells.append("-")
                continue
            sub = [c for c in rows if c['model'] == m and c['red'] == red]
            if not sub:
                cells.append("-")
                continue
            p = sum(1 for c in sub if passes(c, thr))
            cells.append(fmt_rate(p, len(sub)))
            tp += p
            tn += len(sub)
        cells.append(fmt_rate(tp, tn))
        print(f"| {m} | " + " | ".join(cells) + " |")


def top4_table(rows, thr, title):
    print(f"\n### {title}")
    hdr = "| model | r0 | r10 | r15 | r20 | r25 | r30 | TOTAL |"
    print(hdr)
    print("|---|" + "---|" * 7)
    for m in MODELS:
        cells, tp, tn = [], 0, 0
        for red in REDS:
            if m in ("B0", "B0-D") and red != "r0p00":
                cells.append("-")
                continue
            g = defaultdict(list)
            for c in rows:
                if c['model'] == m and c['red'] == red:
                    g[c['target']].append(c)
            if not g:
                cells.append("-")
                continue
            p = sum(1 for t, items in g.items() if any(passes(c, thr) for c in items))
            cells.append(fmt_rate(p, len(g)))
            tp += p
            tn += len(g)
        cells.append(fmt_rate(tp, tn))
        print(f"| {m} | " + " | ".join(cells) + " |")


def mean_table(rows, key, title):
    print(f"\n### {title}")
    hdr = "| model | r0 | r10 | r15 | r20 | r25 | r30 | TOTAL |"
    print(hdr)
    print("|---|" + "---|" * 7)
    for m in MODELS:
        cells, s, n = [], 0.0, 0
        for red in REDS:
            if m in ("B0", "B0-D") and red != "r0p00":
                cells.append("-")
                continue
            es = [c[key] for c in rows if c['model'] == m and c['red'] == red
                  and c['complete'] and c['valid'] and c[key] is not None]
            if not es:
                cells.append("-")
                continue
            cells.append(f"{sum(es) / len(es):.4f}")
            s += sum(es)
            n += len(es)
        cells.append(f"{s / n:.4f}" if n else "-")
        print(f"| {m} | " + " | ".join(cells) + " |")


def vf_direction_table(rows, title):
    print(f"\n### {title}")
    print("| model | n | 变轻 (ratio>r) | 变重 (ratio<r) |")
    print("|---|---:|---:|---:|")
    for m in MODELS:
        sub = [c for c in rows if c['model'] == m and c['red'] != 'r0p00'
               and c['complete'] and c['valid'] and c['E'] is not None
               and c['E'] <= 0.05 and c['ratio'] is not None]
        if not sub:
            print(f"| {m} | 0 | - | - |")
            continue
        lt = sum(1 for c in sub if c['ratio'] > RVAL[c['red']])
        print(f"| {m} | {len(sub)} | {lt / len(sub) * 100:.1f}% | "
              f"{(len(sub) - lt) / len(sub) * 100:.1f}% |")


def ranking_table(rows, title):
    print(f"\n### {title}")
    print("| rank | model | E<=5% per-case | E<=5% top4>=1 | E_FEM mean | E_NOT-FEM mean |")
    print("|---|---|---|---|---|---|")
    rr = []
    for m in MODELS:
        if m in ("B0", "B0-D"):
            continue
        sub = [c for c in rows if c['model'] == m]
        if not sub:
            continue
        p5 = sum(1 for c in sub if passes(c, 0.05))
        n5 = len(sub)
        g = defaultdict(list)
        for c in sub:
            g[(c['target'], c['red'])].append(c)
        t4 = sum(1 for k, items in g.items() if any(passes(c, 0.05) for c in items))
        nt4 = len(g)
        ef = [c['E'] for c in sub if c['complete'] and c['valid'] and c['E'] is not None]
        en = [c['EN'] for c in sub if c['complete'] and c['valid'] and c['EN'] is not None]
        if not ef or not en:
            continue
        rr.append((m, p5 / n5 * 100, t4 / nt4 * 100, sum(ef) / len(ef), sum(en) / len(en)))
    for i, (m, p5, t4, ef, en) in enumerate(sorted(rr, key=lambda x: -x[1]), 1):
        print(f"| {i} | {m} | {p5:.1f}% | {t4:.1f}% | {ef:.4f} | {en:.4f} |")
    for m in ("B0", "B0-D"):
        sub = [c for c in rows if c['model'] == m]
        if not sub:
            continue
        p5 = sum(1 for c in sub if passes(c, 0.05))
        n5 = len(sub)
        ef = [c['E'] for c in sub if c['complete'] and c['valid'] and c['E'] is not None]
        en = [c['EN'] for c in sub if c['complete'] and c['valid'] and c['EN'] is not None]
        if not ef or not en:
            continue
        print(f"| r0-only | {m} | {p5 / n5 * 100:.1f}% | - | {sum(ef) / len(ef):.4f} | "
              f"{sum(en) / len(en):.4f} |")


def tables(rows, title):
    print("=" * 80)
    print(title)
    print("=" * 80)
    per_case_table(rows, 0.05, "A. E<=5% per-case pass rate (asym_0.02)")
    top4_table(rows, 0.05, "B. E<=5% top4>=1 pass rate (asym_0.02)")
    mean_table(rows, 'E', "C. E_target-FEM mean (complete+valid)")
    per_case_table(rows, 0.10, "D. E<=10% per-case pass rate (asym_0.02)")
    top4_table(rows, 0.10, "E. E<=10% top4>=1 pass rate (asym_0.02)")
    vf_direction_table(rows, "F. VF 偏差方向 (E<=5% pass, r>0)")
    mean_table(rows, 'EN', "G. E_NOT-FEM mean (complete+valid)")
    ranking_table(rows, "H. 总体排序 (按 E<=5% per-case 降序)")


def fill_skipped(rows, manifest_path):
    """为 manifest 中 skipped 的 cell 注入 not-run=not-pass 幽灵 case。

    skipped 条目格式为 `arm/reduction/target`（整 cell 跳过，literal top-4 合同下
    每个设计 cell 为 4 个 rank case）。not-run case 不可能成为 pass，计入分母。
    """
    import json
    with open(manifest_path) as f:
        mf = json.load(f)
    ranks = mf.get("ranks", [1, 2, 3, 4])
    added = 0
    for entry in mf.get("skipped", []):
        parts = entry.split("/")
        if len(parts) != 3:
            continue
        arm, red, target = parts
        model = {"b0": "B0", "b0-d": "B0-D", "b1": "B1", "b1-d": "B1-D",
                 "b1-pd": "B1-PD", "b2": "B2", "b2-d": "B2-D", "b2-pd": "B2-PD",
                 "b3": "B3", "b3-d": "B3-D", "b3-pd": "B3-PD",
                 "b1-vfloss": "B1-VFLOSS", "b1-vfloss-w05": "B1-VFLOSS-w05"}.get(arm)
        if model is None:
            continue
        for rank in ranks:
            rows.append(dict(model=model, target=target, red=red,
                             complete=False, valid=False, E=None, EN=None, ratio=None))
            added += 1
    print(f"[fill-skipped] manifest={manifest_path}")
    print(f"[fill-skipped] skipped cells: {mf.get('skipped', [])}")
    print(f"[fill-skipped] injected {added} not-run ghost cases")
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("csv_path")
    ap.add_argument("--clean", action="store_true",
                    help="仅保留 clean 3 targets (q25_50/q50_75/q75_90)")
    ap.add_argument("--fill-skipped", metavar="MANIFEST", default=None,
                    help="输入包 manifest.json：skipped cell 注入 not-run=not-pass 幽灵 case")
    ap.add_argument("--title", default=None)
    args = ap.parse_args()
    rows = prep(load(args.csv_path))
    if args.fill_skipped:
        rows = fill_skipped(rows, args.fill_skipped)
    if args.clean:
        rows = [c for c in rows if any(k in c['target'] for k in CLEAN_KEYS)]
    tables(rows, args.title or args.csv_path)


if __name__ == "__main__":
    main()
