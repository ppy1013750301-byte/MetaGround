#!/usr/bin/env python3
"""Build FEM validation packages from inference results.

Modes:
  top1     - completed literal top-1 cases (vf-stratified sweep)
  top4     - completed literal top-1..4 cases (vf-stratified sweep)
  rank2_4  - frozen literal rank-2..4 cases (11-run aligned package)
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path

import numpy as np


MAIN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MAIN))

from geometry_metrics import binary_fem_ready_batch  # noqa: E402
from utils.run_fem import write_geo_file  # noqa: E402
from utils.sdf_geometry import classify_contours  # noqa: E402


# ---------------------------------------------------------------------------
# Shared geometry / hashing utilities
# ---------------------------------------------------------------------------

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_not_curve(pool, candidate_index):
    periodic_ids = np.asarray(pool["periodic_ids"], dtype=np.int64)
    matches = np.flatnonzero(periodic_ids == int(candidate_index))
    if len(matches) != 1:
        raise ValueError("candidate %s is absent or duplicated in periodic pool" % candidate_index)
    return np.asarray(pool["periodic_not_predictions"][matches[0]], dtype=np.float32)


def audit_geometry(sdf):
    import tempfile
    result = {
        "periodic_classifier": False,
        "shell_count": 0,
        "hole_count": 0,
        "bbox": None,
        "bottom_contact_width": None,
        "top_contact_width": None,
        "binary_fem_ready": False,
        "geometry_exportable": False,
        "failures": [],
        "diagnostic_flags": [],
    }
    try:
        shell, holes, periodic = classify_contours(np.asarray(sdf, dtype=np.float32))
        result["periodic_classifier"] = bool(periodic)
        result["shell_count"] = len(shell)
        result["hole_count"] = len(holes)
        if shell:
            vertices = np.concatenate(shell)
            result["bbox"] = {
                "xmin": float(vertices[:, 0].min()),
                "xmax": float(vertices[:, 0].max()),
                "ymin": float(vertices[:, 1].min()),
                "ymax": float(vertices[:, 1].max()),
            }
            outer = np.asarray(shell[0], dtype=np.float32)
            for name, coordinate in (("bottom_contact_width", 0.0), ("top_contact_width", 1.0)):
                points = outer[np.isclose(outer[:, 1], coordinate, atol=5e-3)]
                result[name] = float(points[:, 0].max() - points[:, 0].min()) if len(points) >= 2 else 0.0
        result["binary_fem_ready"] = bool(
            binary_fem_ready_batch(np.asarray(sdf, dtype=np.float32)[None, None])[0]
        )
        if not periodic:
            result["failures"].append("periodic_classifier=false")
        if len(shell) != 1:
            result["failures"].append("shell_count=%d" % len(shell))
        if result["bbox"] is not None:
            bbox = result["bbox"]
            if bbox["xmin"] < -1e-6 or bbox["ymin"] < -1e-6 or bbox["xmax"] > 1.0 + 1e-6 or bbox["ymax"] > 1.0 + 1e-6:
                result["failures"].append("bbox_outside_unit_cell")
        if not result["binary_fem_ready"]:
            result["diagnostic_flags"].append("binary_fem_ready=false")
        if not result["failures"]:
            with tempfile.TemporaryDirectory(prefix="fem-geometry-audit-") as directory:
                write_geo_file((shell, holes), directory)
                sample_path = Path(directory) / "sample.json"
                result["geometry_exportable"] = sample_path.is_file() and sample_path.stat().st_size > 0
            if not result["geometry_exportable"]:
                result["failures"].append("sample_json_export_failed")
    except Exception as error:
        result["failures"].append("%s: %s" % (type(error).__name__, error))
    return result


# ---------------------------------------------------------------------------
# Mode: top1
# ---------------------------------------------------------------------------

REDUCTIONS_TOP1 = ("r0p00", "r0p10", "r0p15", "r0p20")
REDUCTION_VALUE = {"r0p00": 0.0, "r0p10": 0.10, "r0p15": 0.15, "r0p20": 0.20}
PACKAGE_ID_TOP1 = "b0-b3-vf-stratified-completed-top1-fem-v1"


def load_sources_top1(input_root, ranks=(1,)):
    sources = []
    for reduction in REDUCTIONS_TOP1:
        reduction_dir = input_root / reduction
        if not reduction_dir.is_dir():
            continue
        for arm_dir in sorted(p for p in reduction_dir.iterdir() if p.is_dir()):
            for report_path in sorted(arm_dir.glob("*.json")):
                npz_path = report_path.with_suffix(".npz")
                if not npz_path.is_file():
                    continue
                report = json.loads(report_path.read_text())
                top = sorted(report.get("top_k", []), key=lambda row: int(row["rank"]))
                if [int(row["rank"]) for row in top] != [1, 2, 3, 4]:
                    continue
                for rank in ranks:
                    rank_rows = [r for r in top if int(r["rank"]) == int(rank)]
                    if rank_rows:
                        sources.append((reduction, arm_dir.name, report_path, npz_path, report, rank_rows[0]))
    return sources


def build_case_top1(package, source, include_normalized=True):
    reduction, arm_dir, report_path, npz_path, report, rank_row = source
    target = str(report["target_id"])
    rank = int(rank_row["rank"])
    candidate_index = int(rank_row["candidate_index"])
    case_id = f"{arm_dir}__{reduction}__target-{target}__rank-{rank}__candidate-{candidate_index:03d}"
    case_dir = package / "cases" / case_id
    case_dir.mkdir(parents=True)
    with np.load(npz_path, allow_pickle=False) as data:
        pool = {name: np.asarray(data[name]) for name in data.files}
    if pool["candidates_physical"].shape != (500, 1, 120, 120):
        raise ValueError(f"unexpected candidate shape: {npz_path}")
    sdf = np.asarray(pool["candidates_physical"][candidate_index, 0], dtype=np.float32)
    sdf_normalized = np.asarray(pool["candidates"][candidate_index, 0], dtype=np.float32)
    target_curve = np.asarray(pool["target_curve"], dtype=np.float32).reshape(-1)
    not_curve = find_not_curve(pool, candidate_index)
    geometry = audit_geometry(sdf)
    if geometry["failures"]:
        raise RuntimeError(f"geometry audit failed for {case_id}: {geometry['failures']}")
    shell, holes, periodic = classify_contours(sdf)
    if not periodic or len(shell) != 1:
        raise RuntimeError(f"literal top-1 is not exportable: {case_id}")
    contact_risk = any(float(geometry[name]) < 0.10 for name in ("bottom_contact_width", "top_contact_width"))
    preflight = bool(contact_risk)
    np.save(case_dir / "sdf.npy", sdf)
    if include_normalized:
        np.save(case_dir / "sdf_normalized.npy", sdf_normalized)
    np.save(case_dir / "target_curve.npy", target_curve)
    np.save(case_dir / "notss_curve_physical.npy", not_curve)
    write_geo_file((shell, holes), str(case_dir))
    (case_dir / "abaqus_config.json").write_text(json.dumps({
        "schema_version": 1, "job_name": "MyJob", "solver": "implicit",
        "strain": -0.2, "coarseness": 0.04, "num_cpus": 4, "memory_percent": 20,
        "boundary_contract": "original_v1", "min_loading_nodes": 1, "min_loading_contact_width": 0.0,
    }, indent=2) + "\n")
    achieved_vf = float(rank_row["achieved_vf"])
    vf_source = float(report["vf_base"])
    vf_requested = float(report["vf_requested"])
    candidate = {
        "schema_version": 1, "case_id": case_id,
        "fem_split": "preflight" if preflight else "locked_validation",
        "preflight": preflight,
        "preflight_reason": ["static loading contact width < 0.10"] if preflight else [],
        "protocol_arm": report["arm"], "source_arm_dir": arm_dir,
        "reduction": reduction, "reduction_fraction": REDUCTION_VALUE[reduction],
        "target_id": target, "target_family": report["target_family"],
        "rank": rank, "proxy_rank": rank, "candidate_index": candidate_index,
        "candidate_sha256": rank_row.get("candidate_sha256"),
        "candidate_pool_sha256": report.get("candidate_pool_sha256"),
        "E_target_NOT": float(rank_row["E_target_NOT"]),
        "projected_proxy_metrics": {"ss_rel_error": float(rank_row["E_target_NOT"])},
        "target_ss_physical": target_curve.tolist(),
        "projected_notss_curve_physical": not_curve.tolist(),
        "vf_source": vf_source, "vf_base": vf_source, "vf_requested": vf_requested,
        "vf_semantics": report.get("vf_semantics"),
        "vf_condition_applied": bool(report.get("vf_condition_applied")),
        "achieved_vf": achieved_vf, "err_vf": abs(achieved_vf - vf_requested),
        "vf_reduction_source_minus_achieved": vf_source - achieved_vf,
        "reduction_gap_achieved_minus_requested": achieved_vf - vf_requested,
        "source_result": str(report_path.resolve()),
        "source_npz": str(npz_path.resolve()),
        "checkpoint": report["checkpoint"], "checkpoint_sha256": report["checkpoint_sha256"],
        "best_checkpoint": report.get("best_checkpoint"), "best_checkpoint_sha256": report.get("best_checkpoint_sha256"),
        "evaluator": report["evaluator"], "sampling": report["sampling"],
        "geometry_contract": "original_v1", "candidate_domain": report["candidate_domain"],
        "order_constraints": {
            "candidate_domain": report["candidate_domain"],
            "geometry_filter": "original periodic/no-island",
            "ranking_metric": "legacy NOT relative-L2 SS; VF not ranked",
            "literal_rank": rank, "replacement_after_failure": False,
        },
        "selection_audit": {
            "literal_top_k": 4, "selected_candidate_index": candidate_index,
            "selected_rank": rank, "silent_replacement": False,
        },
        "geometry_audit": geometry,
        "files": {
            "sdf": f"cases/{case_id}/sdf.npy",
            "target_curve": f"cases/{case_id}/target_curve.npy",
            "notss_curve": f"cases/{case_id}/notss_curve_physical.npy",
            "abaqus_geometry": f"cases/{case_id}/sample.json",
            "abaqus_config": f"cases/{case_id}/abaqus_config.json",
        },
    }
    if include_normalized:
        candidate["files"]["sdf_normalized"] = f"cases/{case_id}/sdf_normalized.npy"
    (case_dir / "candidate.json").write_text(json.dumps(candidate, indent=2) + "\n")
    return candidate, geometry


def build_top1(input_root, output):
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    (output / "cases").mkdir()
    (output / "scripts").mkdir()
    shutil.copy2(MAIN / "jobs" / "run_fem_package.py", output / "run_fem_package.py")
    shutil.copy2(MAIN / "jobs" / "validate_fem_campaign.py", output / "validate_fem_campaign.py")
    shutil.copy2(MAIN / "utils" / "abaqus_script_sim.py", output / "scripts" / "abaqus_script_sim.py")
    sources = load_sources_top1(input_root, ranks=(1,))
    cases = []
    audits = []
    source_results = []
    for source in sources:
        reduction, arm_dir, report_path, npz_path, report, rank_row = source
        candidate, geometry = build_case_top1(output, source)
        cases.append(candidate)
        audits.append({
            "case_id": candidate["case_id"], "arm": candidate["protocol_arm"],
            "arm_dir": arm_dir, "reduction": reduction,
            "target_id": candidate["target_id"], "target_family": candidate["target_family"],
            "rank": candidate["rank"], "candidate_index": candidate["candidate_index"],
            "E_target_NOT": candidate["E_target_NOT"],
            "vf_source": candidate["vf_source"], "vf_requested": candidate["vf_requested"],
            "achieved_vf": candidate["achieved_vf"], "err_vf": candidate["err_vf"],
            "preflight": candidate["preflight"],
            "bottom_contact_width": geometry["bottom_contact_width"],
            "top_contact_width": geometry["top_contact_width"],
            "source_result": str(report_path.resolve()),
        })
        source_results.append({
            "reduction": reduction, "arm": report["arm"], "arm_dir": arm_dir,
            "target_id": candidate["target_id"],
            "report": str(report_path.resolve()), "report_sha256": sha256(report_path),
            "npz": str(npz_path.resolve()),
            "candidate_pool_sha256": report.get("candidate_pool_sha256"),
        })
    if not cases:
        raise RuntimeError("no completed source results found")
    preflight = [c for c in cases if c["preflight"]]
    manifest = {
        "schema_version": 1, "package_id": PACKAGE_ID_TOP1, "protocol_id": PACKAGE_ID_TOP1,
        "source_inference_protocol_id": "b0-b3-vf-stratified-sweep-r0-r10-r15-r20-v2",
        "solver_started": False,
        "selection_basis": "all completed JSON/NPZ pairs at package build time",
        "geometry_contract": "original_v1",
        "candidate_policy": "completed literal top-1 only; no replacement or failure backfill",
        "candidate_domain": "raw SDF; no periodic projection; no FEM-safe gate",
        "ranking_contract": "legacy NOT relative-L2 after original periodic/no-island",
        "literal_ranks": [1],
        "source_task_count": len(sources), "case_count": len(cases),
        "source_results": source_results,
        "fem_design": {
            "calibration_cases": 0,
            "locked_validation_cases": len(cases) - len(preflight),
            "preflight_cases": len(preflight), "mesh_sensitivity_geometries": 0, "enforce_counts": True,
        },
        "preflight_case_ids": [c["case_id"] for c in preflight],
        "cases": cases,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (output / "fem_results.json").write_text(json.dumps({
        "schema_version": 1, "package_id": PACKAGE_ID_TOP1, "solver_started": False,
        "cases": [{"case_id": c["case_id"], "status": "pending", "failure_reason": None} for c in cases],
    }, indent=2) + "\n")
    return manifest


# ---------------------------------------------------------------------------
# Mode: top4
# ---------------------------------------------------------------------------

PACKAGE_ID_TOP4 = "b0-b3-vf-stratified-completed-top4-fem-v1"
RANKS_TOP4 = (1, 2, 3, 4)


def build_top4(input_root, output, package_id=PACKAGE_ID_TOP4):
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    (output / "cases").mkdir()
    (output / "scripts").mkdir()
    shutil.copy2(MAIN / "jobs" / "run_fem_package.py", output / "run_fem_package.py")
    shutil.copy2(MAIN / "jobs" / "validate_fem_campaign.py", output / "validate_fem_campaign.py")
    shutil.copy2(MAIN / "utils" / "abaqus_script_sim.py", output / "scripts" / "abaqus_script_sim.py")
    sources = load_sources_top1(input_root, ranks=RANKS_TOP4)
    cases = []
    audits = []
    source_results = {}
    for source in sources:
        reduction, arm_dir, report_path, npz_path, report, rank_row = source
        candidate, geometry = build_case_top1(output, source, include_normalized=False)
        cases.append(candidate)
        audits.append({
            "case_id": candidate["case_id"], "arm": candidate["protocol_arm"],
            "arm_dir": arm_dir, "reduction": reduction,
            "target_id": candidate["target_id"], "target_family": candidate["target_family"],
            "rank": candidate["rank"], "candidate_index": candidate["candidate_index"],
            "E_target_NOT": candidate["E_target_NOT"],
            "vf_source": candidate["vf_source"], "vf_requested": candidate["vf_requested"],
            "achieved_vf": candidate["achieved_vf"], "err_vf": candidate["err_vf"],
            "preflight": candidate["preflight"],
            "bottom_contact_width": geometry["bottom_contact_width"],
            "top_contact_width": geometry["top_contact_width"],
            "source_result": str(report_path.resolve()),
        })
        source_key = (reduction, arm_dir, candidate["target_id"])
        source_results[source_key] = {
            "reduction": reduction, "arm": report["arm"], "arm_dir": arm_dir,
            "target_id": candidate["target_id"],
            "report": str(report_path.resolve()), "npz": str(npz_path.resolve()),
            "candidate_pool_sha256": report.get("candidate_pool_sha256"),
        }
    if not cases:
        raise RuntimeError("no completed top-4 source results found")
    preflight = [c for c in cases if c["preflight"]]
    source_results = list(source_results.values())
    rank_counts = {str(r): sum(c["rank"] == r for c in cases) for r in RANKS_TOP4}
    manifest = {
        "schema_version": 1, "package_id": package_id, "protocol_id": package_id,
        "source_inference_protocol_id": "b0-b3-vf-stratified-sweep-r0-r10-r15-r20-v2",
        "solver_started": False,
        "selection_basis": "all completed JSON/NPZ pairs at package build time",
        "geometry_contract": "original_v1",
        "candidate_policy": "completed literal top-1--4 only; no replacement or failure backfill",
        "candidate_domain": "raw SDF; no periodic projection; no FEM-safe gate",
        "ranking_contract": "legacy NOT relative-L2 after original periodic/no-island",
        "literal_ranks": list(RANKS_TOP4),
        "source_task_count": len(source_results), "case_count": len(cases),
        "rank_counts": rank_counts, "source_results": source_results,
        "fem_design": {
            "calibration_cases": 0,
            "locked_validation_cases": len(cases) - len(preflight),
            "preflight_cases": len(preflight), "mesh_sensitivity_geometries": 0, "enforce_counts": True,
        },
        "preflight_case_ids": [c["case_id"] for c in preflight],
        "cases": cases,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (output / "fem_results.json").write_text(json.dumps({
        "schema_version": 1, "package_id": package_id, "solver_started": False,
        "cases": [{"case_id": c["case_id"], "status": "pending", "failure_reason": None} for c in cases],
    }, indent=2) + "\n")
    return manifest


# ---------------------------------------------------------------------------
# Mode: rank2_4
# ---------------------------------------------------------------------------

RANKS_R24 = (2, 3, 4)
SOURCE_PROTOCOL_ID_R24 = "b0-b3-11-original-aligned-final-latest-v1"
PACKAGE_PROTOCOL_ID_R24 = "b0-b3-11-rank2-4-fem-v1"


def load_source_r24(input_root, arm_dir, target):
    report_path = input_root / arm_dir / (target + ".json")
    npz_path = report_path.with_suffix(".npz")
    if not report_path.is_file() or not npz_path.is_file():
        raise FileNotFoundError(str(report_path))
    report = json.loads(report_path.read_text())
    if report.get("protocol_id") != SOURCE_PROTOCOL_ID_R24:
        raise ValueError("protocol mismatch: %s" % report_path)
    if str(report.get("target_id")) != target:
        raise ValueError("target mismatch: %s" % report_path)
    with np.load(npz_path, allow_pickle=False) as data:
        pool = {name: np.asarray(data[name]) for name in data.files}
    if pool["candidates_physical"].shape != (500, 1, 120, 120):
        raise ValueError("unexpected candidate shape: %s" % npz_path)
    rows = {int(row["rank"]): row for row in report.get("top_k", [])}
    missing = [r for r in RANKS_R24 if r not in rows]
    if missing:
        raise ValueError("missing literal ranks %s: %s" % (missing, report_path))
    return report, pool, report_path, rows


def build_case_r24(package, arm_dir, target, rank, report, pool, report_path, preflight):
    rank_row = {int(row["rank"]): row for row in report["top_k"]}[rank]
    candidate_index = int(rank_row["candidate_index"])
    case_id = "%s__target-%s__rank-%d__candidate-%03d" % (arm_dir, target, rank, candidate_index)
    case_directory = package / "cases" / case_id
    case_directory.mkdir(parents=True)
    sdf = np.asarray(pool["candidates_physical"][candidate_index, 0], dtype=np.float32)
    sdf_normalized = np.asarray(pool["candidates"][candidate_index, 0], dtype=np.float32)
    target_curve = np.asarray(pool["target_curve"], dtype=np.float32).reshape(-1)
    not_curve = find_not_curve(pool, candidate_index)
    shell, holes, periodic = classify_contours(sdf)
    np.save(case_directory / "sdf.npy", sdf)
    np.save(case_directory / "sdf_normalized.npy", sdf_normalized)
    np.save(case_directory / "target_curve.npy", target_curve)
    np.save(case_directory / "notss_curve_physical.npy", not_curve)
    write_geo_file((shell, holes), str(case_directory))
    (case_directory / "abaqus_config.json").write_text(json.dumps({
        "schema_version": 1, "job_name": "MyJob", "solver": "implicit",
        "strain": -0.2, "coarseness": 0.04, "num_cpus": 4, "memory_percent": 20,
        "boundary_contract": "original_v1", "min_loading_nodes": 1, "min_loading_contact_width": 0.0,
    }, indent=2) + "\n")
    candidate = {
        "schema_version": 1, "case_id": case_id,
        "fem_split": "preflight" if preflight else "locked_validation",
        "preflight": bool(preflight),
        "protocol_arm": report["arm"], "target_id": target,
        "target_family": report["target_family"],
        "rank": rank, "proxy_rank": rank, "candidate_index": candidate_index,
        "E_target_NOT": float(rank_row["E_target_NOT"]),
        "projected_proxy_metrics": {"ss_rel_error": float(rank_row["E_target_NOT"])},
        "target_ss_physical": target_curve.tolist(),
        "projected_notss_curve_physical": not_curve.tolist(),
        "vf_base": report.get("vf_base"), "vf_semantics": report.get("vf_semantics"),
        "achieved_vf": rank_row.get("achieved_vf"),
        "source_result": str(report_path.resolve()),
        "source_npz": str(report_path.with_suffix(".npz").resolve()),
        "checkpoint": report["checkpoint"], "checkpoint_sha256": report["checkpoint_sha256"],
        "best_checkpoint": report["best_checkpoint"], "best_checkpoint_sha256": report["best_checkpoint_sha256"],
        "evaluator": report["evaluator"], "sampling": report["sampling"],
        "geometry_contract": "original_v1",
        "order_constraints": {
            "candidate_domain": report["candidate_domain"],
            "geometry_filter": "periodic_no_island",
            "ranking_metric": "legacy_NOT_relative_L2_SS",
            "literal_rank": rank, "replacement_after_failure": False,
        },
        "selection_audit": {
            "literal_top_k": 4, "selected_candidate_index": candidate_index,
            "selected_rank": rank, "silent_replacement": False, "top1_fem_repeated": False,
        },
        "geometry_audit": audit_geometry(sdf),
        "files": {
            "sdf": "cases/%s/sdf.npy" % case_id,
            "sdf_normalized": "cases/%s/sdf_normalized.npy" % case_id,
            "target_curve": "cases/%s/target_curve.npy" % case_id,
            "notss_curve": "cases/%s/notss_curve_physical.npy" % case_id,
            "abaqus_geometry": "cases/%s/sample.json" % case_id,
            "abaqus_config": "cases/%s/abaqus_config.json" % case_id,
        },
    }
    if candidate["geometry_audit"]["failures"]:
        raise RuntimeError("geometry audit failed for %s: %s" % (case_id, candidate["geometry_audit"]["failures"]))
    (case_directory / "candidate.json").write_text(json.dumps(candidate, indent=2) + "\n")
    return {
        "case_id": case_id, "fem_split": candidate["fem_split"], "preflight": bool(preflight),
        "protocol_arm": report["arm"], "source_arm_dir": arm_dir,
        "target_id": target, "target_family": report["target_family"],
        "rank": rank, "candidate_index": candidate_index,
        "E_target_NOT": float(rank_row["E_target_NOT"]),
        "source_result": str(report_path.resolve()),
        "source_npz": str(report_path.with_suffix(".npz").resolve()),
    }


def build_rank2_4(input_root, output, arm_dirs, targets, prechecks, preflight_cases):
    if output.exists():
        raise FileExistsError("refusing to overwrite %s" % output)
    output.mkdir(parents=True)
    (output / "scripts").mkdir()
    shutil.copy2(MAIN / "utils" / "abaqus_script_sim.py", output / "scripts" / "abaqus_script_sim.py")
    shutil.copy2(MAIN / "jobs" / "run_fem_package.py", output / "run_fem_package.py")
    shutil.copy2(MAIN / "jobs" / "validate_fem_campaign.py", output / "validate_fem_campaign.py")
    requested = {(arm, target, rank) for arm, target, rank in prechecks}
    cases = []
    source_results = []
    audit_rows = []
    for arm_dir in arm_dirs:
        for target in targets:
            report, pool, report_path, rows = load_source_r24(input_root, arm_dir, target)
            source_results.append({
                "arm": report["arm"], "arm_dir": arm_dir, "target_id": target,
                "report": str(report_path.resolve()),
                "npz": str(report_path.with_suffix(".npz").resolve()),
            })
            for rank in RANKS_R24:
                preflight = (arm_dir, target, rank) in requested
                case = build_case_r24(output, arm_dir, target, rank, report, pool, report_path, preflight)
                cases.append(case)
                audit_rows.append({
                    "arm_dir": arm_dir, "arm": report["arm"],
                    "target_id": target, "target_family": report["target_family"],
                    "rank": rank, "candidate_index": case["candidate_index"],
                    "E_target_NOT": case["E_target_NOT"], "preflight": preflight,
                    "geometry": json.loads((output / "cases" / case["case_id"] / "candidate.json").read_text())["geometry_audit"],
                    "source_result": case["source_result"],
                })
    expected_count = len(arm_dirs) * len(targets) * len(RANKS_R24)
    if len(cases) != expected_count:
        raise RuntimeError("expected %d cases, built %d" % (expected_count, len(cases)))
    manifest = {
        "schema_version": 1, "package_id": output.name, "protocol_id": PACKAGE_PROTOCOL_ID_R24,
        "source_inference_protocol_id": SOURCE_PROTOCOL_ID_R24,
        "solver_started": False, "geometry_contract": "original_v1",
        "candidate_policy": "frozen literal rank-2--4 per checkpoint-target; rank-1 already validated; no replacement after failure",
        "candidate_domain": "raw SDF; no periodic projection; no FEM-safe gate",
        "ranking_contract": "legacy NOT relative-L2 after original periodic/no-island",
        "top1_repeated": False, "literal_ranks": list(RANKS_R24),
        "model_target_count": len(arm_dirs) * len(targets),
        "case_count": len(cases), "source_results": source_results,
        "fem_design": {
            "calibration_cases": 0,
            "locked_validation_cases": len(cases) - preflight_cases,
            "preflight_cases": preflight_cases, "mesh_sensitivity_geometries": 0, "enforce_counts": True,
        },
        "preflight_case_ids": [c["case_id"] for c in cases if c["preflight"]],
        "cases": cases,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    render_package(output)
    return manifest


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)

    p_top1 = sub.add_parser("top1", help="build top-1 FEM package")
    p_top1.add_argument("--input-root", type=Path, required=True)
    p_top1.add_argument("--output", type=Path, required=True)

    p_top4 = sub.add_parser("top4", help="build top-1..4 FEM package")
    p_top4.add_argument("--input-root", type=Path, required=True)
    p_top4.add_argument("--output", type=Path, required=True)
    p_top4.add_argument("--package-id", default=PACKAGE_ID_TOP4)

    p_r24 = sub.add_parser("rank2_4", help="build frozen rank-2..4 FEM package")
    p_r24.add_argument("--input_root", type=Path, required=True)
    p_r24.add_argument("--output", type=Path, required=True)
    p_r24.add_argument("--arm-dirs", nargs="+", required=True)
    p_r24.add_argument("--targets", nargs="+", required=True)
    p_r24.add_argument("--prechecks", nargs="*", default=[],
                       help="format: arm_dir target rank (repeatable)")
    p_r24.add_argument("--preflight-cases", type=int, required=True)

    args = parser.parse_args()

    if args.mode == "top1":
        manifest = build_top1(args.input_root.resolve(), args.output.resolve())
    elif args.mode == "top4":
        manifest = build_top4(args.input_root.resolve(), args.output.resolve(), args.package_id)
    elif args.mode == "rank2_4":
        prechecks = []
        for i in range(0, len(args.prechecks), 3):
            arm, tgt, rank = args.prechecks[i], args.prechecks[i+1], int(args.prechecks[i+2])
            prechecks.append((arm, tgt, rank))
        manifest = build_rank2_4(
            args.input_root.resolve(), args.output.resolve(),
            args.arm_dirs, args.targets, prechecks, args.preflight_cases,
        )

    print(json.dumps({
        "mode": args.mode,
        "output": str(args.output.resolve()),
        "case_count": manifest["case_count"],
        "preflight_cases": manifest["fem_design"]["preflight_cases"],
        "locked_validation_cases": manifest["fem_design"]["locked_validation_cases"],
    }, indent=2))


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# SDF gallery rendering (moved from render_fem_sdf_gallery.py)
# ---------------------------------------------------------------------------

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _safe_component(value):
    import re
    text = str(value or "unknown").strip()
    text = re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-._")
    return text or "unknown"


def _render_one_sdf(sdf, title, output):
    values = np.asarray(sdf, dtype=np.float32).squeeze()
    if values.ndim != 2:
        raise ValueError(f"expected a 2D SDF, got {values.shape}")
    limit = max(float(np.quantile(np.abs(values), 0.98)), 1e-6)
    solid = values < 0
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.5), constrained_layout=True)
    image = axes[0].imshow(
        values, origin="lower", cmap="coolwarm",
        vmin=-limit, vmax=limit, interpolation="nearest",
    )
    axes[0].contour(values, levels=[0.0], colors="black", linewidths=1.0)
    axes[0].set_title("Continuous SDF + zero contour")
    axes[1].imshow(solid, origin="lower", cmap="gray_r", vmin=0, vmax=1)
    axes[1].set_title(f"Solid mask, VF={solid.mean():.4f}")
    for axis in axes:
        axis.set_xlabel("x pixel")
        axis.set_ylabel("y pixel")
        axis.set_aspect("equal")
    fig.colorbar(image, ax=axes[0], fraction=0.046, pad=0.04, label="SDF")
    fig.suptitle(title, fontsize=10)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180)
    plt.close(fig)


def render_package(package):
    """Render SDF gallery for a FEM package (thumbnail index only)."""
    package = Path(package).resolve()
    manifest_path = package / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    gallery = package / "sdf_gallery"
    entries = []
    for index, case in enumerate(manifest["cases"]):
        case_id = str(case["case_id"])
        case_dir = package / "cases" / case_id
        candidate_index = int(case.get("candidate_index", index))
        rank = case.get("periodic_rank", case.get("proxy_rank", case.get("rank", index + 1)))
        target = _safe_component(case.get("target_id", case.get("target_index", "unknown")))
        filename = f"rank-{int(rank):02d}__candidate-{candidate_index:03d}__{_safe_component(case_id)}.png"
        relative = Path("sdf_gallery") / target / filename
        sdf_path = case_dir / "sdf.npy"
        _render_one_sdf(
            np.load(sdf_path),
            f"target={target} | rank={rank} | candidate={candidate_index}",
            package / relative,
        )
        entries.append({
            "case_id": case_id,
            "target": target,
            "rank": int(rank),
            "candidate_index": candidate_index,
            "sdf": str(sdf_path.relative_to(package)),
            "plot": str(relative),
        })
    index_payload = {
        "schema_version": 1,
        "package_id": manifest.get("package_id"),
        "case_count": len(entries),
        "entries": entries,
    }
    gallery.mkdir(parents=True, exist_ok=True)
    (gallery / "index.json").write_text(json.dumps(index_payload, indent=2) + "\n")
    return index_payload
