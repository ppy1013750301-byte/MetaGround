"""Geometry/manufacturability metrics for generated periodic SDF cells."""

from __future__ import annotations

from typing import Dict

import numpy as np
from scipy import ndimage
from skimage.morphology import skeletonize


def unit_cell_boundary_indices(size: int) -> tuple[int, int]:
    """Return grid indices for physical coordinates 0 and 1."""
    if size < 3:
        raise ValueError("SDF grid is too small")
    lower = int(round((0.1 / 1.2) * (size - 1)))
    upper = int(round((1.1 / 1.2) * (size - 1)))
    return lower, upper


def project_periodic_sdf(
    sdf_2d: np.ndarray,
    *,
    extend_padding: bool = False,
) -> np.ndarray:
    """Minimally project an SDF grid onto exact x/y periodic boundaries.

    The physical interior is preserved. Opposite boundary rows/columns on
    ``[0, 1]^2`` are averaged. When ``extend_padding`` is true, the immediately
    adjacent external halo is overwritten by wrapped physical-interior values
    so continuous zero-level contours also meet the unit-cell boundaries
    periodically without creating additional tiled copies in the padding. The
    projected geometry must be re-evaluated by all proxies.
    """
    sdf = np.asarray(sdf_2d, dtype=np.float32)
    if sdf.ndim != 2 or sdf.shape[0] != sdf.shape[1]:
        raise ValueError(f"expected square 2D SDF, got {sdf.shape}")
    size = sdf.shape[0]
    lower, upper = unit_cell_boundary_indices(size)
    projected = sdf.copy()

    x_average = 0.5 * (
        projected[lower:upper + 1, lower]
        + projected[lower:upper + 1, upper]
    )
    projected[lower:upper + 1, lower] = x_average
    projected[lower:upper + 1, upper] = x_average
    y_average = 0.5 * (
        projected[lower, lower:upper + 1]
        + projected[upper, lower:upper + 1]
    )
    projected[lower, lower:upper + 1] = y_average
    projected[upper, lower:upper + 1] = y_average

    if extend_padding:
        padding = min(lower, size - 1 - upper)
        for offset in range(1, min(padding, 1) + 1):
            projected[lower - offset, lower:upper + 1] = projected[
                upper - offset, lower:upper + 1
            ]
            projected[upper + offset, lower:upper + 1] = projected[
                lower + offset, lower:upper + 1
            ]
        for offset in range(1, min(padding, 1) + 1):
            projected[:, lower - offset] = projected[:, upper - offset]
            projected[:, upper + offset] = projected[:, lower + offset]

    return projected


def project_periodic_sdf_batch(
    sdf_batch: np.ndarray,
    *,
    extend_padding: bool = False,
) -> np.ndarray:
    """Project a batch of physical SDFs onto exact unit-cell boundaries."""
    values = np.asarray(sdf_batch, dtype=np.float32)
    if values.ndim == 3:
        values = values[:, None]
    if values.ndim != 4 or values.shape[1] != 1:
        raise ValueError(
            f"expected physical SDF batch (N,1,H,W), got {values.shape}"
        )
    if values.shape[2] != values.shape[3]:
        raise ValueError(f"expected square SDF batch, got {values.shape}")

    projected = values.copy()
    size = projected.shape[-1]
    lower, upper = unit_cell_boundary_indices(size)
    x_average = 0.5 * (
        projected[:, :, lower:upper + 1, lower]
        + projected[:, :, lower:upper + 1, upper]
    )
    projected[:, :, lower:upper + 1, lower] = x_average
    projected[:, :, lower:upper + 1, upper] = x_average
    y_average = 0.5 * (
        projected[:, :, lower, lower:upper + 1]
        + projected[:, :, upper, lower:upper + 1]
    )
    projected[:, :, lower, lower:upper + 1] = y_average
    projected[:, :, upper, lower:upper + 1] = y_average

    if extend_padding:
        padding = min(lower, size - 1 - upper)
        for offset in range(1, min(padding, 1) + 1):
            projected[:, :, lower - offset, lower:upper + 1] = projected[
                :, :, upper - offset, lower:upper + 1
            ]
            projected[:, :, upper + offset, lower:upper + 1] = projected[
                :, :, lower + offset, lower:upper + 1
            ]
        for offset in range(1, min(padding, 1) + 1):
            projected[:, :, :, lower - offset] = projected[:, :, :, upper - offset]
            projected[:, :, :, upper + offset] = projected[:, :, :, lower + offset]
    return projected


def boundary_support_metrics(
    sdf_2d: np.ndarray,
    threshold: float = 0.0,
) -> Dict[str, float | bool]:
    """Audit exact periodic matching and paper-like four-edge support.

    ``binary_fem_ready`` preserves the legacy loading requirement: opposite
    boundary masks match and the loading edges contain solid.  The stricter
    ``training_support_ready`` additionally rejects vacuous left/right matches
    where both periodic faces are entirely void, which lies outside the GRF
    geometry support used to train the forward surrogate.
    """
    sdf = np.asarray(sdf_2d, dtype=np.float32).squeeze()
    if sdf.ndim != 2 or sdf.shape[0] != sdf.shape[1]:
        raise ValueError(f"expected square 2D SDF, got {sdf.shape}")
    lower, upper = unit_cell_boundary_indices(sdf.shape[0])
    solid = sdf < threshold
    left = solid[lower:upper + 1, lower]
    right = solid[lower:upper + 1, upper]
    bottom = solid[lower, lower:upper + 1]
    top = solid[upper, lower:upper + 1]
    left_sdf = sdf[lower:upper + 1, lower]
    right_sdf = sdf[lower:upper + 1, upper]
    bottom_sdf = sdf[lower, lower:upper + 1]
    top_sdf = sdf[upper, lower:upper + 1]
    x_mismatch = float(np.mean(left != right))
    y_mismatch = float(np.mean(bottom != top))
    touches_left = bool(left.any())
    touches_right = bool(right.any())
    touches_bottom = bool(bottom.any())
    touches_top = bool(top.any())
    binary_fem_ready = bool(
        x_mismatch == 0.0
        and y_mismatch == 0.0
        and touches_bottom
        and touches_top
    )
    return {
        "x_binary_mismatch_fraction": x_mismatch,
        "y_binary_mismatch_fraction": y_mismatch,
        "x_sdf_mae": float(np.mean(np.abs(left_sdf - right_sdf))),
        "y_sdf_mae": float(np.mean(np.abs(bottom_sdf - top_sdf))),
        "x_binary_match": x_mismatch == 0.0,
        "y_binary_match": y_mismatch == 0.0,
        "touches_left": touches_left,
        "touches_right": touches_right,
        "touches_bottom": touches_bottom,
        "touches_top": touches_top,
        "binary_fem_ready": binary_fem_ready,
        "training_support_ready": bool(
            binary_fem_ready and touches_left and touches_right
        ),
        "left_solid_fraction": float(left.mean()),
        "right_solid_fraction": float(right.mean()),
        "bottom_solid_fraction": float(bottom.mean()),
        "top_solid_fraction": float(top.mean()),
    }


def binary_fem_ready_batch(
    sdf_batch: np.ndarray,
    threshold: float = 0.0,
) -> np.ndarray:
    """Return the exact binary FEM loading-boundary gate for a batch."""
    values = np.asarray(sdf_batch, dtype=np.float32)
    if values.ndim == 3:
        values = values[:, None]
    if values.ndim != 4 or values.shape[1] != 1:
        raise ValueError(
            f"expected physical SDF batch (N,1,H,W), got {values.shape}"
        )
    lower, upper = unit_cell_boundary_indices(values.shape[-1])
    solid = values[:, 0] < threshold
    left = solid[:, lower:upper + 1, lower]
    right = solid[:, lower:upper + 1, upper]
    bottom = solid[:, lower, lower:upper + 1]
    top = solid[:, upper, lower:upper + 1]
    return np.asarray(
        np.all(left == right, axis=1)
        & np.all(bottom == top, axis=1)
        & np.any(bottom, axis=1)
        & np.any(top, axis=1),
        dtype=bool,
    )


def training_support_batch(sdf_batch_physical: np.ndarray) -> np.ndarray:
    """Return strict paper-training-support decisions for an SDF batch."""
    batch = np.asarray(sdf_batch_physical)
    if batch.ndim == 3:
        batch = batch[:, None]
    if batch.ndim != 4 or batch.shape[1] != 1:
        raise ValueError(f"expected physical SDF shape (B,1,H,W), got {batch.shape}")
    return np.asarray([
        boundary_support_metrics(sdf[0])["training_support_ready"]
        for sdf in batch
    ], dtype=bool)


def periodic_wall_thickness(
    sdf_2d: np.ndarray,
    threshold: float = 0.0,
    pixel_size: float | None = None,
    robust_quantile: float = 0.05,
) -> Dict[str, float]:
    """Estimate local wall diameters on an x-periodic solid skeleton.

    The SDF convention is solid ``sdf < threshold``.  Three x-tiles are used so
    the centre cell has no artificial left/right boundary.  Skeleton endpoints
    are excluded from the robust distribution because their distance is set by
    the end cap rather than the load-bearing ligament width.
    """
    sdf_2d = np.asarray(sdf_2d)
    if sdf_2d.ndim != 2:
        raise ValueError(f"sdf_2d must be two-dimensional; got {sdf_2d.shape}")
    if not 0.0 <= robust_quantile <= 1.0:
        raise ValueError("robust_quantile must be in [0, 1]")
    solid = sdf_2d < threshold
    height, width = solid.shape
    scale = (1.0 / width) if pixel_size is None else float(pixel_size)
    if not np.any(solid):
        return {
            "min_pixels": 0.0,
            "q05_pixels": 0.0,
            "median_pixels": 0.0,
            "min_physical": 0.0,
            "q05_physical": 0.0,
            "median_physical": 0.0,
            "skeleton_points": 0,
        }

    tiled = np.tile(solid, (1, 3))
    distance = ndimage.distance_transform_edt(tiled)
    skeleton = skeletonize(tiled)
    neighbour_count = ndimage.convolve(
        skeleton.astype(np.uint8), np.ones((3, 3), dtype=np.uint8), mode="constant"
    ) - skeleton.astype(np.uint8)
    centre = np.zeros_like(skeleton, dtype=bool)
    centre[:, width:2 * width] = True
    usable = skeleton & centre & (neighbour_count >= 2)
    diameters = 2.0 * distance[usable]
    if diameters.size == 0:
        diameters = 2.0 * distance[skeleton & centre]
    if diameters.size == 0:
        diameters = np.array([0.0])

    minimum = float(np.min(diameters))
    robust = float(np.quantile(diameters, robust_quantile))
    median = float(np.median(diameters))
    return {
        "min_pixels": minimum,
        "q05_pixels": robust,
        "median_pixels": median,
        "min_physical": minimum * scale,
        "q05_physical": robust * scale,
        "median_physical": median * scale,
        "skeleton_points": int(len(diameters)),
    }


def wall_thickness_satisfied(
    sdf_2d: np.ndarray,
    min_thickness_pixels: float,
    threshold: float = 0.0,
    robust_quantile: float = 0.05,
) -> bool:
    """Hard-filter decision based on robust lower-tail wall thickness."""
    if min_thickness_pixels <= 0:
        raise ValueError("min_thickness_pixels must be positive")
    metrics = periodic_wall_thickness(
        sdf_2d, threshold=threshold, robust_quantile=robust_quantile
    )
    return metrics["q05_pixels"] >= min_thickness_pixels
